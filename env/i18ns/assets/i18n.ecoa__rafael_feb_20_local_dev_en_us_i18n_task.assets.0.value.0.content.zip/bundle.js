
const process = { env: {} };
const global = globalThis;

const __modules = {};
function require(name) {
  const module = __modules[name];
  if (module === undefined) throw new Error(`Cannot resolve module ${name}`);
  return module;
}

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.0~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"All of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.1~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Most of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.2~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"A little of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.3~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"None of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.item_stem~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"In the past week, how often did you feel energetic?";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.0~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"All of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.1~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Most of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.2~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"A little of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.3~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"None of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.item_stem~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"In the past week, how often did you feel anxious?";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.0~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"All of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.1~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Most of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.2~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"A little of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.3~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"None of the time";

    return exports;
})();

__modules['strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.item_stem~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"In the past week, how often did you feel rested after sleep?";

    return exports;
})();

__modules['strings.product.button_back~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Back";

    return exports;
})();

__modules['strings.product.button_next~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Next";

    return exports;
})();

__modules['strings.product.button_submit~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Submit";

    return exports;
})();

__modules['strings.product.cancel_dialog.content~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"This activity will still be available to come back to, but your responses will not be saved.";

    return exports;
})();

__modules['strings.product.cancel_dialog.no_label~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"No, stay in activity";

    return exports;
})();

__modules['strings.product.cancel_dialog.title~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Are you sure you want to cancel this activity?";

    return exports;
})();

__modules['strings.product.cancel_dialog.yes_label~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Yes, cancel activity";

    return exports;
})();

__modules['strings.product.hint.scroll_down~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Scroll down to see more";

    return exports;
})();

__modules['strings.product.link_cancel~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Cancel";

    return exports;
})();

__modules['strings.product.skip_dialog.content~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"You will continue without providing a response.";

    return exports;
})();

__modules['strings.product.skip_dialog.no_label~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"No, stay in question";

    return exports;
})();

__modules['strings.product.skip_dialog.title~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Are you sure you want to skip this question?";

    return exports;
})();

__modules['strings.product.skip_dialog.yes_label~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Yes, skip question";

    return exports;
})();

__modules['templates.debounce~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.debounce = debounce;
/**
 * @param fn function to call.
 * @param t time in milliseconds to wait before calling fn.
 * @returns A function that calls the given function after t milliseconds. If the returned function is called a second
 *     time before the first call triggers the given function, starts counting the time again and only results in one
 *     total call of the given function.
 */
function debounce(fn, t) {
    let timeout;
    const debouncedFn = () => {
        clearTimeout(timeout);
        timeout = setTimeout(fn, t);
    };
    debouncedFn.cancel = () => clearTimeout(timeout);
    return debouncedFn;
}

    return exports;
})();

__modules['react'] = (() => {
    const exports = {};
    const module = {exports};
    /**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
'use strict';var l=Symbol.for("react.element"),n=Symbol.for("react.portal"),p=Symbol.for("react.fragment"),q=Symbol.for("react.strict_mode"),r=Symbol.for("react.profiler"),t=Symbol.for("react.provider"),u=Symbol.for("react.context"),v=Symbol.for("react.forward_ref"),w=Symbol.for("react.suspense"),x=Symbol.for("react.memo"),y=Symbol.for("react.lazy"),z=Symbol.iterator;function A(a){if(null===a||"object"!==typeof a)return null;a=z&&a[z]||a["@@iterator"];return"function"===typeof a?a:null}
var B={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},C=Object.assign,D={};function E(a,b,e){this.props=a;this.context=b;this.refs=D;this.updater=e||B}E.prototype.isReactComponent={};
E.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,a,b,"setState")};E.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate")};function F(){}F.prototype=E.prototype;function G(a,b,e){this.props=a;this.context=b;this.refs=D;this.updater=e||B}var H=G.prototype=new F;
H.constructor=G;C(H,E.prototype);H.isPureReactComponent=!0;var I=Array.isArray,J=Object.prototype.hasOwnProperty,K={current:null},L={key:!0,ref:!0,__self:!0,__source:!0};
function M(a,b,e){var d,c={},k=null,h=null;if(null!=b)for(d in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)J.call(b,d)&&!L.hasOwnProperty(d)&&(c[d]=b[d]);var g=arguments.length-2;if(1===g)c.children=e;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];c.children=f}if(a&&a.defaultProps)for(d in g=a.defaultProps,g)void 0===c[d]&&(c[d]=g[d]);return{$$typeof:l,type:a,key:k,ref:h,props:c,_owner:K.current}}
function N(a,b){return{$$typeof:l,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function O(a){return"object"===typeof a&&null!==a&&a.$$typeof===l}function escape(a){var b={"=":"=0",":":"=2"};return"$"+a.replace(/[=:]/g,function(a){return b[a]})}var P=/\/+/g;function Q(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function R(a,b,e,d,c){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case l:case n:h=!0}}if(h)return h=a,c=c(h),a=""===d?"."+Q(h,0):d,I(c)?(e="",null!=a&&(e=a.replace(P,"$&/")+"/"),R(c,b,e,"",function(a){return a})):null!=c&&(O(c)&&(c=N(c,e+(!c.key||h&&h.key===c.key?"":(""+c.key).replace(P,"$&/")+"/")+a)),b.push(c)),1;h=0;d=""===d?".":d+":";if(I(a))for(var g=0;g<a.length;g++){k=
a[g];var f=d+Q(k,g);h+=R(k,b,e,f,c)}else if(f=A(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=d+Q(k,g++),h+=R(k,b,e,f,c);else if("object"===k)throw b=String(a),Error("Objects are not valid as a React child (found: "+("[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b)+"). If you meant to render a collection of children, use an array instead.");return h}
function S(a,b,e){if(null==a)return a;var d=[],c=0;R(a,d,"","",function(a){return b.call(e,a,c++)});return d}function T(a){if(-1===a._status){var b=a._result;b=b();b.then(function(b){if(0===a._status||-1===a._status)a._status=1,a._result=b},function(b){if(0===a._status||-1===a._status)a._status=2,a._result=b});-1===a._status&&(a._status=0,a._result=b)}if(1===a._status)return a._result.default;throw a._result;}
var U={current:null},V={transition:null},W={ReactCurrentDispatcher:U,ReactCurrentBatchConfig:V,ReactCurrentOwner:K};exports.Children={map:S,forEach:function(a,b,e){S(a,function(){b.apply(this,arguments)},e)},count:function(a){var b=0;S(a,function(){b++});return b},toArray:function(a){return S(a,function(a){return a})||[]},only:function(a){if(!O(a))throw Error("React.Children.only expected to receive a single React element child.");return a}};exports.Component=E;exports.Fragment=p;
exports.Profiler=r;exports.PureComponent=G;exports.StrictMode=q;exports.Suspense=w;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=W;
exports.cloneElement=function(a,b,e){if(null===a||void 0===a)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+a+".");var d=C({},a.props),c=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=K.current);void 0!==b.key&&(c=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)J.call(b,f)&&!L.hasOwnProperty(f)&&(d[f]=void 0===b[f]&&void 0!==g?g[f]:b[f])}var f=arguments.length-2;if(1===f)d.children=e;else if(1<f){g=Array(f);
for(var m=0;m<f;m++)g[m]=arguments[m+2];d.children=g}return{$$typeof:l,type:a.type,key:c,ref:k,props:d,_owner:h}};exports.createContext=function(a){a={$$typeof:u,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null};a.Provider={$$typeof:t,_context:a};return a.Consumer=a};exports.createElement=M;exports.createFactory=function(a){var b=M.bind(null,a);b.type=a;return b};exports.createRef=function(){return{current:null}};
exports.forwardRef=function(a){return{$$typeof:v,render:a}};exports.isValidElement=O;exports.lazy=function(a){return{$$typeof:y,_payload:{_status:-1,_result:a},_init:T}};exports.memo=function(a,b){return{$$typeof:x,type:a,compare:void 0===b?null:b}};exports.startTransition=function(a){var b=V.transition;V.transition={};try{a()}finally{V.transition=b}};exports.unstable_act=function(){throw Error("act(...) is not supported in production builds of React.");};
exports.useCallback=function(a,b){return U.current.useCallback(a,b)};exports.useContext=function(a){return U.current.useContext(a)};exports.useDebugValue=function(){};exports.useDeferredValue=function(a){return U.current.useDeferredValue(a)};exports.useEffect=function(a,b){return U.current.useEffect(a,b)};exports.useId=function(){return U.current.useId()};exports.useImperativeHandle=function(a,b,e){return U.current.useImperativeHandle(a,b,e)};
exports.useInsertionEffect=function(a,b){return U.current.useInsertionEffect(a,b)};exports.useLayoutEffect=function(a,b){return U.current.useLayoutEffect(a,b)};exports.useMemo=function(a,b){return U.current.useMemo(a,b)};exports.useReducer=function(a,b,e){return U.current.useReducer(a,b,e)};exports.useRef=function(a){return U.current.useRef(a)};exports.useState=function(a){return U.current.useState(a)};exports.useSyncExternalStore=function(a,b,e){return U.current.useSyncExternalStore(a,b,e)};
exports.useTransition=function(){return U.current.useTransition()};exports.version="18.2.0";
    return exports;
})();

__modules['scheduler'] = (() => {
    const exports = {};
    const module = {exports};
    /**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
'use strict';function f(a,b){var c=a.length;a.push(b);a:for(;0<c;){var d=c-1>>>1,e=a[d];if(0<g(e,b))a[d]=b,a[c]=e,c=d;else break a}}function h(a){return 0===a.length?null:a[0]}function k(a){if(0===a.length)return null;var b=a[0],c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length,w=e>>>1;d<w;){var m=2*(d+1)-1,C=a[m],n=m+1,x=a[n];if(0>g(C,c))n<e&&0>g(x,C)?(a[d]=x,a[n]=c,d=n):(a[d]=C,a[m]=c,d=m);else if(n<e&&0>g(x,c))a[d]=x,a[n]=c,d=n;else break a}}return b}
function g(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports.unstable_now=function(){return l.now()}}else{var p=Date,q=p.now();exports.unstable_now=function(){return p.now()-q}}var r=[],t=[],u=1,v=null,y=3,z=!1,A=!1,B=!1,D="function"===typeof setTimeout?setTimeout:null,E="function"===typeof clearTimeout?clearTimeout:null,F="undefined"!==typeof setImmediate?setImmediate:null;
"undefined"!==typeof navigator&&void 0!==navigator.scheduling&&void 0!==navigator.scheduling.isInputPending&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function G(a){for(var b=h(t);null!==b;){if(null===b.callback)k(t);else if(b.startTime<=a)k(t),b.sortIndex=b.expirationTime,f(r,b);else break;b=h(t)}}function H(a){B=!1;G(a);if(!A)if(null!==h(r))A=!0,I(J);else{var b=h(t);null!==b&&K(H,b.startTime-a)}}
function J(a,b){A=!1;B&&(B=!1,E(L),L=-1);z=!0;var c=y;try{G(b);for(v=h(r);null!==v&&(!(v.expirationTime>b)||a&&!M());){var d=v.callback;if("function"===typeof d){v.callback=null;y=v.priorityLevel;var e=d(v.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?v.callback=e:v===h(r)&&k(r);G(b)}else k(r);v=h(r)}if(null!==v)var w=!0;else{var m=h(t);null!==m&&K(H,m.startTime-b);w=!1}return w}finally{v=null,y=c,z=!1}}var N=!1,O=null,L=-1,P=5,Q=-1;
function M(){return exports.unstable_now()-Q<P?!1:!0}function R(){if(null!==O){var a=exports.unstable_now();Q=a;var b=!0;try{b=O(!0,a)}finally{b?S():(N=!1,O=null)}}else N=!1}var S;if("function"===typeof F)S=function(){F(R)};else if("undefined"!==typeof MessageChannel){var T=new MessageChannel,U=T.port2;T.port1.onmessage=R;S=function(){U.postMessage(null)}}else S=function(){D(R,0)};function I(a){O=a;N||(N=!0,S())}function K(a,b){L=D(function(){a(exports.unstable_now())},b)}
exports.unstable_IdlePriority=5;exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null};exports.unstable_continueExecution=function(){A||z||(A=!0,I(J))};
exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):P=0<a?Math.floor(1E3/a):5};exports.unstable_getCurrentPriorityLevel=function(){return y};exports.unstable_getFirstCallbackNode=function(){return h(r)};exports.unstable_next=function(a){switch(y){case 1:case 2:case 3:var b=3;break;default:b=y}var c=y;y=b;try{return a()}finally{y=c}};exports.unstable_pauseExecution=function(){};
exports.unstable_requestPaint=function(){};exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3}var c=y;y=a;try{return b()}finally{y=c}};
exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3}e=c+e;a={id:u++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,f(t,a),null===h(r)&&a===h(t)&&(B?(E(L),L=-1):B=!0,K(H,c-d))):(a.sortIndex=e,f(r,a),A||z||(A=!0,I(J)));return a};
exports.unstable_shouldYield=M;exports.unstable_wrapCallback=function(a){var b=y;return function(){var c=y;y=b;try{return a.apply(this,arguments)}finally{y=c}}};
    return exports;
})();

__modules['react-dom'] = (() => {
    const exports = {};
    const module = {exports};
    /**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/*
 Modernizr 3.0.0pre (Custom Build) | MIT
*/
'use strict';var aa=require("react"),ca=require("scheduler");function p(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var da=new Set,ea={};function fa(a,b){ha(a,b);ha(a+"Capture",b)}
function ha(a,b){ea[a]=b;for(a=0;a<b.length;a++)da.add(b[a])}
var ia=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ja=Object.prototype.hasOwnProperty,ka=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,la=
{},ma={};function oa(a){if(ja.call(ma,a))return!0;if(ja.call(la,a))return!1;if(ka.test(a))return ma[a]=!0;la[a]=!0;return!1}function pa(a,b,c,d){if(null!==c&&0===c.type)return!1;switch(typeof b){case "function":case "symbol":return!0;case "boolean":if(d)return!1;if(null!==c)return!c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return"data-"!==a&&"aria-"!==a;default:return!1}}
function qa(a,b,c,d){if(null===b||"undefined"===typeof b||pa(a,b,c,d))return!0;if(d)return!1;if(null!==c)switch(c.type){case 3:return!b;case 4:return!1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return!1}function v(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g}var z={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){z[a]=new v(a,0,!1,a,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];z[b]=new v(b,1,!1,a[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(a){z[a]=new v(a,2,!1,a.toLowerCase(),null,!1,!1)});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){z[a]=new v(a,2,!1,a,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){z[a]=new v(a,3,!1,a.toLowerCase(),null,!1,!1)});
["checked","multiple","muted","selected"].forEach(function(a){z[a]=new v(a,3,!0,a,null,!1,!1)});["capture","download"].forEach(function(a){z[a]=new v(a,4,!1,a,null,!1,!1)});["cols","rows","size","span"].forEach(function(a){z[a]=new v(a,6,!1,a,null,!1,!1)});["rowSpan","start"].forEach(function(a){z[a]=new v(a,5,!1,a.toLowerCase(),null,!1,!1)});var ra=/[\-:]([a-z])/g;function sa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(ra,
sa);z[b]=new v(b,1,!1,a,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(ra,sa);z[b]=new v(b,1,!1,a,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(ra,sa);z[b]=new v(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(a){z[a]=new v(a,1,!1,a.toLowerCase(),null,!1,!1)});
z.xlinkHref=new v("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(a){z[a]=new v(a,1,!1,a.toLowerCase(),null,!0,!0)});
function ta(a,b,c,d){var e=z.hasOwnProperty(b)?z[b]:null;if(null!==e?0!==e.type:d||!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1])qa(b,c,e,d)&&(c=null),d||null===e?oa(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c)))}
var ua=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,va=Symbol.for("react.element"),wa=Symbol.for("react.portal"),ya=Symbol.for("react.fragment"),za=Symbol.for("react.strict_mode"),Aa=Symbol.for("react.profiler"),Ba=Symbol.for("react.provider"),Ca=Symbol.for("react.context"),Da=Symbol.for("react.forward_ref"),Ea=Symbol.for("react.suspense"),Fa=Symbol.for("react.suspense_list"),Ga=Symbol.for("react.memo"),Ha=Symbol.for("react.lazy");Symbol.for("react.scope");Symbol.for("react.debug_trace_mode");
var Ia=Symbol.for("react.offscreen");Symbol.for("react.legacy_hidden");Symbol.for("react.cache");Symbol.for("react.tracing_marker");var Ja=Symbol.iterator;function Ka(a){if(null===a||"object"!==typeof a)return null;a=Ja&&a[Ja]||a["@@iterator"];return"function"===typeof a?a:null}var A=Object.assign,La;function Ma(a){if(void 0===La)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);La=b&&b[1]||""}return"\n"+La+a}var Na=!1;
function Oa(a,b){if(!a||Na)return"";Na=!0;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[])}catch(l){var d=l}Reflect.construct(a,[],b)}else{try{b.call()}catch(l){d=l}a.call(b.prototype)}else{try{throw Error();}catch(l){d=l}a()}}catch(l){if(l&&d&&"string"===typeof l.stack){for(var e=l.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h]){var k="\n"+e[g].replace(" at new "," at ");a.displayName&&k.includes("<anonymous>")&&(k=k.replace("<anonymous>",a.displayName));return k}while(1<=g&&0<=h)}break}}}finally{Na=!1,Error.prepareStackTrace=c}return(a=a?a.displayName||a.name:"")?Ma(a):""}
function Pa(a){switch(a.tag){case 5:return Ma(a.type);case 16:return Ma("Lazy");case 13:return Ma("Suspense");case 19:return Ma("SuspenseList");case 0:case 2:case 15:return a=Oa(a.type,!1),a;case 11:return a=Oa(a.type.render,!1),a;case 1:return a=Oa(a.type,!0),a;default:return""}}
function Qa(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ya:return"Fragment";case wa:return"Portal";case Aa:return"Profiler";case za:return"StrictMode";case Ea:return"Suspense";case Fa:return"SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case Ca:return(a.displayName||"Context")+".Consumer";case Ba:return(a._context.displayName||"Context")+".Provider";case Da:var b=a.render;a=a.displayName;a||(a=b.displayName||
b.name||"",a=""!==a?"ForwardRef("+a+")":"ForwardRef");return a;case Ga:return b=a.displayName||null,null!==b?b:Qa(a.type)||"Memo";case Ha:b=a._payload;a=a._init;try{return Qa(a(b))}catch(c){}}return null}
function Ra(a){var b=a.type;switch(a.tag){case 24:return"Cache";case 9:return(b.displayName||"Context")+".Consumer";case 10:return(b._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return a=b.render,a=a.displayName||a.name||"",b.displayName||(""!==a?"ForwardRef("+a+")":"ForwardRef");case 7:return"Fragment";case 5:return b;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Qa(b);case 8:return b===za?"StrictMode":"Mode";case 22:return"Offscreen";
case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if("function"===typeof b)return b.displayName||b.name||null;if("string"===typeof b)return b}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "string":case "undefined":return a;case "object":return a;default:return""}}
function Ta(a){var b=a.type;return(a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a)}});Object.defineProperty(a,b,{enumerable:c.enumerable});return{getValue:function(){return d},setValue:function(a){d=""+a},stopTracking:function(){a._valueTracker=
null;delete a[b]}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a))}function Wa(a){if(!a)return!1;var b=a._valueTracker;if(!b)return!0;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return A({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value}}function ab(a,b){b=b.checked;null!=b&&ta(a,"checked",b,!1)}
function bb(a,b){ab(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?cb(a,b.type,c):b.hasOwnProperty("defaultValue")&&cb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked)}
function db(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c)}
function cb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c)}var eb=Array.isArray;
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0)}else{c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return}null!==b||a[e].disabled||(b=a[e])}null!==b&&(b.selected=!0)}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(p(91));return A({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(p(92));if(eb(c)){if(1<c.length)throw Error(p(93));c=c[0]}b=c}null==b&&(b="");c=b}a._wrapperState={initialValue:Sa(c)}}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d)}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b)}function kb(a){switch(a){case "svg":return"http://www.w3.org/2000/svg";case "math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}
function lb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?kb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var mb,nb=function(a){return"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)})}:a}(function(a,b){if("http://www.w3.org/2000/svg"!==a.namespaceURI||"innerHTML"in a)a.innerHTML=b;else{mb=mb||document.createElement("div");mb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=mb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild)}});
function ob(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b}
var pb={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,
zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},qb=["Webkit","ms","Moz","O"];Object.keys(pb).forEach(function(a){qb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);pb[b]=pb[a]})});function rb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||pb.hasOwnProperty(a)&&pb[a]?(""+b).trim():b+"px"}
function sb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=rb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e}}var tb=A({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});
function ub(a,b){if(b){if(tb[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(p(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(p(60));if("object"!==typeof b.dangerouslySetInnerHTML||!("__html"in b.dangerouslySetInnerHTML))throw Error(p(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(p(62));}}
function vb(a,b){if(-1===a.indexOf("-"))return"string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return!1;default:return!0}}var wb=null;function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(p(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b))}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a])}}function Gb(a,b){return a(b)}function Hb(){}var Ib=!1;function Jb(a,b,c){if(Ib)return a(b,c);Ib=!0;try{return Gb(a,b,c)}finally{if(Ib=!1,null!==zb||null!==Ab)Hb(),Fb()}}
function Kb(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1}if(a)return null;if(c&&"function"!==
typeof c)throw Error(p(231,b,typeof c));return c}var Lb=!1;if(ia)try{var Mb={};Object.defineProperty(Mb,"passive",{get:function(){Lb=!0}});window.addEventListener("test",Mb,Mb);window.removeEventListener("test",Mb,Mb)}catch(a){Lb=!1}function Nb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l)}catch(m){this.onError(m)}}var Ob=!1,Pb=null,Qb=!1,Rb=null,Sb={onError:function(a){Ob=!0;Pb=a}};function Tb(a,b,c,d,e,f,g,h,k){Ob=!1;Pb=null;Nb.apply(Sb,arguments)}
function Ub(a,b,c,d,e,f,g,h,k){Tb.apply(this,arguments);if(Ob){if(Ob){var l=Pb;Ob=!1;Pb=null}else throw Error(p(198));Qb||(Qb=!0,Rb=l)}}function Vb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else{a=b;do b=a,0!==(b.flags&4098)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function Wb(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function Xb(a){if(Vb(a)!==a)throw Error(p(188));}
function Yb(a){var b=a.alternate;if(!b){b=Vb(a);if(null===b)throw Error(p(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return Xb(e),a;if(f===d)return Xb(e),b;f=f.sibling}throw Error(p(188));}if(c.return!==d.return)c=e,d=f;else{for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break}if(h===d){g=!0;d=e;c=f;break}h=h.sibling}if(!g){for(h=f.child;h;){if(h===
c){g=!0;c=f;d=e;break}if(h===d){g=!0;d=f;c=e;break}h=h.sibling}if(!g)throw Error(p(189));}}if(c.alternate!==d)throw Error(p(190));}if(3!==c.tag)throw Error(p(188));return c.stateNode.current===c?a:b}function Zb(a){a=Yb(a);return null!==a?$b(a):null}function $b(a){if(5===a.tag||6===a.tag)return a;for(a=a.child;null!==a;){var b=$b(a);if(null!==b)return b;a=a.sibling}return null}
var ac=ca.unstable_scheduleCallback,bc=ca.unstable_cancelCallback,cc=ca.unstable_shouldYield,dc=ca.unstable_requestPaint,B=ca.unstable_now,ec=ca.unstable_getCurrentPriorityLevel,fc=ca.unstable_ImmediatePriority,gc=ca.unstable_UserBlockingPriority,hc=ca.unstable_NormalPriority,ic=ca.unstable_LowPriority,jc=ca.unstable_IdlePriority,kc=null,lc=null;function mc(a){if(lc&&"function"===typeof lc.onCommitFiberRoot)try{lc.onCommitFiberRoot(kc,a,void 0,128===(a.current.flags&128))}catch(b){}}
var oc=Math.clz32?Math.clz32:nc,pc=Math.log,qc=Math.LN2;function nc(a){a>>>=0;return 0===a?32:31-(pc(a)/qc|0)|0}var rc=64,sc=4194304;
function tc(a){switch(a&-a){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return a&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;
default:return a}}function uc(a,b){var c=a.pendingLanes;if(0===c)return 0;var d=0,e=a.suspendedLanes,f=a.pingedLanes,g=c&268435455;if(0!==g){var h=g&~e;0!==h?d=tc(h):(f&=g,0!==f&&(d=tc(f)))}else g=c&~e,0!==g?d=tc(g):0!==f&&(d=tc(f));if(0===d)return 0;if(0!==b&&b!==d&&0===(b&e)&&(e=d&-d,f=b&-b,e>=f||16===e&&0!==(f&4194240)))return b;0!==(d&4)&&(d|=c&16);b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-oc(b),e=1<<c,d|=a[c],b&=~e;return d}
function vc(a,b){switch(a){case 1:case 2:case 4:return b+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return b+5E3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}
function wc(a,b){for(var c=a.suspendedLanes,d=a.pingedLanes,e=a.expirationTimes,f=a.pendingLanes;0<f;){var g=31-oc(f),h=1<<g,k=e[g];if(-1===k){if(0===(h&c)||0!==(h&d))e[g]=vc(h,b)}else k<=b&&(a.expiredLanes|=h);f&=~h}}function xc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function yc(){var a=rc;rc<<=1;0===(rc&4194240)&&(rc=64);return a}function zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function Ac(a,b,c){a.pendingLanes|=b;536870912!==b&&(a.suspendedLanes=0,a.pingedLanes=0);a=a.eventTimes;b=31-oc(b);a[b]=c}function Bc(a,b){var c=a.pendingLanes&~b;a.pendingLanes=b;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=b;a.mutableReadLanes&=b;a.entangledLanes&=b;b=a.entanglements;var d=a.eventTimes;for(a=a.expirationTimes;0<c;){var e=31-oc(c),f=1<<e;b[e]=0;d[e]=-1;a[e]=-1;c&=~f}}
function Cc(a,b){var c=a.entangledLanes|=b;for(a=a.entanglements;c;){var d=31-oc(c),e=1<<d;e&b|a[d]&b&&(a[d]|=b);c&=~e}}var C=0;function Dc(a){a&=-a;return 1<a?4<a?0!==(a&268435455)?16:536870912:4:1}var Ec,Fc,Gc,Hc,Ic,Jc=!1,Kc=[],Lc=null,Mc=null,Nc=null,Oc=new Map,Pc=new Map,Qc=[],Rc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Sc(a,b){switch(a){case "focusin":case "focusout":Lc=null;break;case "dragenter":case "dragleave":Mc=null;break;case "mouseover":case "mouseout":Nc=null;break;case "pointerover":case "pointerout":Oc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":Pc.delete(b.pointerId)}}
function Tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a={blockedOn:b,domEventName:c,eventSystemFlags:d,nativeEvent:f,targetContainers:[e]},null!==b&&(b=Cb(b),null!==b&&Fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function Uc(a,b,c,d,e){switch(b){case "focusin":return Lc=Tc(Lc,a,b,c,d,e),!0;case "dragenter":return Mc=Tc(Mc,a,b,c,d,e),!0;case "mouseover":return Nc=Tc(Nc,a,b,c,d,e),!0;case "pointerover":var f=e.pointerId;Oc.set(f,Tc(Oc.get(f)||null,a,b,c,d,e));return!0;case "gotpointercapture":return f=e.pointerId,Pc.set(f,Tc(Pc.get(f)||null,a,b,c,d,e)),!0}return!1}
function Vc(a){var b=Wc(a.target);if(null!==b){var c=Vb(b);if(null!==c)if(b=c.tag,13===b){if(b=Wb(c),null!==b){a.blockedOn=b;Ic(a.priority,function(){Gc(c)});return}}else if(3===b&&c.stateNode.current.memoizedState.isDehydrated){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null}
function Xc(a){if(null!==a.blockedOn)return!1;for(var b=a.targetContainers;0<b.length;){var c=Yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null===c){c=a.nativeEvent;var d=new c.constructor(c.type,c);wb=d;c.target.dispatchEvent(d);wb=null}else return b=Cb(c),null!==b&&Fc(b),a.blockedOn=c,!1;b.shift()}return!0}function Zc(a,b,c){Xc(a)&&c.delete(b)}function $c(){Jc=!1;null!==Lc&&Xc(Lc)&&(Lc=null);null!==Mc&&Xc(Mc)&&(Mc=null);null!==Nc&&Xc(Nc)&&(Nc=null);Oc.forEach(Zc);Pc.forEach(Zc)}
function ad(a,b){a.blockedOn===b&&(a.blockedOn=null,Jc||(Jc=!0,ca.unstable_scheduleCallback(ca.unstable_NormalPriority,$c)))}
function bd(a){function b(b){return ad(b,a)}if(0<Kc.length){ad(Kc[0],a);for(var c=1;c<Kc.length;c++){var d=Kc[c];d.blockedOn===a&&(d.blockedOn=null)}}null!==Lc&&ad(Lc,a);null!==Mc&&ad(Mc,a);null!==Nc&&ad(Nc,a);Oc.forEach(b);Pc.forEach(b);for(c=0;c<Qc.length;c++)d=Qc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<Qc.length&&(c=Qc[0],null===c.blockedOn);)Vc(c),null===c.blockedOn&&Qc.shift()}var cd=ua.ReactCurrentBatchConfig,dd=!0;
function ed(a,b,c,d){var e=C,f=cd.transition;cd.transition=null;try{C=1,fd(a,b,c,d)}finally{C=e,cd.transition=f}}function gd(a,b,c,d){var e=C,f=cd.transition;cd.transition=null;try{C=4,fd(a,b,c,d)}finally{C=e,cd.transition=f}}
function fd(a,b,c,d){if(dd){var e=Yc(a,b,c,d);if(null===e)hd(a,b,d,id,c),Sc(a,d);else if(Uc(e,a,b,c,d))d.stopPropagation();else if(Sc(a,d),b&4&&-1<Rc.indexOf(a)){for(;null!==e;){var f=Cb(e);null!==f&&Ec(f);f=Yc(a,b,c,d);null===f&&hd(a,b,d,id,c);if(f===e)break;e=f}null!==e&&d.stopPropagation()}else hd(a,b,d,null,c)}}var id=null;
function Yc(a,b,c,d){id=null;a=xb(d);a=Wc(a);if(null!==a)if(b=Vb(a),null===b)a=null;else if(c=b.tag,13===c){a=Wb(b);if(null!==a)return a;a=null}else if(3===c){if(b.stateNode.current.memoizedState.isDehydrated)return 3===b.tag?b.stateNode.containerInfo:null;a=null}else b!==a&&(a=null);id=a;return null}
function jd(a){switch(a){case "cancel":case "click":case "close":case "contextmenu":case "copy":case "cut":case "auxclick":case "dblclick":case "dragend":case "dragstart":case "drop":case "focusin":case "focusout":case "input":case "invalid":case "keydown":case "keypress":case "keyup":case "mousedown":case "mouseup":case "paste":case "pause":case "play":case "pointercancel":case "pointerdown":case "pointerup":case "ratechange":case "reset":case "resize":case "seeked":case "submit":case "touchcancel":case "touchend":case "touchstart":case "volumechange":case "change":case "selectionchange":case "textInput":case "compositionstart":case "compositionend":case "compositionupdate":case "beforeblur":case "afterblur":case "beforeinput":case "blur":case "fullscreenchange":case "focus":case "hashchange":case "popstate":case "select":case "selectstart":return 1;case "drag":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "mousemove":case "mouseout":case "mouseover":case "pointermove":case "pointerout":case "pointerover":case "scroll":case "toggle":case "touchmove":case "wheel":case "mouseenter":case "mouseleave":case "pointerenter":case "pointerleave":return 4;
case "message":switch(ec()){case fc:return 1;case gc:return 4;case hc:case ic:return 16;case jc:return 536870912;default:return 16}default:return 16}}var kd=null,ld=null,md=null;function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}
function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return!0}function qd(){return!1}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:!1===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}A(b.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=!1),this.isDefaultPrevented=pd)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=pd)},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=A({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=A({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return"movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=A({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=A({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=A({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=A({},sd,{clipboardData:function(a){return"clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=A({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:!1}function zd(){return Pd}
var Qd=A({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return"keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return"keypress"===a.type?od(a):0},keyCode:function(a){return"keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return"keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=A({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=A({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=A({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=A({},Ad,{deltaX:function(a){return"deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return"deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=ia&&"CompositionEvent"in window,be=null;ia&&"documentMode"in document&&(be=document.documentMode);var ce=ia&&"TextEvent"in window&&!be,de=ia&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=!1;
function ge(a,b){switch(a){case "keyup":return-1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return!0;default:return!1}}function he(a){a=a.detail;return"object"===typeof a&&"data"in a?a.data:null}var ie=!1;function je(a,b){switch(a){case "compositionend":return he(b);case "keypress":if(32!==b.which)return null;fe=!0;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke(a,b){if(ie)return"compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=!1,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return"input"===b?!!le[a.type]:"textarea"===b?!0:!1}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}))}var pe=null,qe=null;function re(a){se(a,0)}function te(a){var b=ue(a);if(Wa(b))return a}
function ve(a,b){if("change"===a)return b}var we=!1;if(ia){var xe;if(ia){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput}xe=ye}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode)}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null)}function Be(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));Jb(re,b)}}
function Ce(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be)):"focusout"===a&&Ae()}function De(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe(a,b){if("input"===a||"change"===a)return te(b)}function Ge(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He="function"===typeof Object.is?Object.is:Ge;
function Ie(a,b){if(He(a,b))return!0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return!1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return!1;for(d=0;d<c.length;d++){var e=c[d];if(!ja.call(b,e)||!He(a[e],b[e]))return!1}return!0}function Je(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Ke(a,b){var c=Je(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return{node:c,offset:b-a};a=d}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode}c=void 0}c=Je(c)}}function Le(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?Le(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1}
function Me(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href}catch(d){c=!1}if(c)a=b.contentWindow;else break;b=Xa(a.document)}return b}function Ne(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
function Oe(a){var b=Me(),c=a.focusedElem,d=a.selectionRange;if(b!==c&&c&&c.ownerDocument&&Le(c.ownerDocument.documentElement,c)){if(null!==d&&Ne(c))if(b=d.start,a=d.end,void 0===a&&(a=b),"selectionStart"in c)c.selectionStart=b,c.selectionEnd=Math.min(a,c.value.length);else if(a=(b=c.ownerDocument||document)&&b.defaultView||window,a.getSelection){a=a.getSelection();var e=c.textContent.length,f=Math.min(d.start,e);d=void 0===d.end?f:Math.min(d.end,e);!a.extend&&f>d&&(e=d,d=f,f=e);e=Ke(c,f);var g=Ke(c,
d);e&&g&&(1!==a.rangeCount||a.anchorNode!==e.node||a.anchorOffset!==e.offset||a.focusNode!==g.node||a.focusOffset!==g.offset)&&(b=b.createRange(),b.setStart(e.node,e.offset),a.removeAllRanges(),f>d?(a.addRange(b),a.extend(g.node,g.offset)):(b.setEnd(g.node,g.offset),a.addRange(b)))}b=[];for(a=c;a=a.parentNode;)1===a.nodeType&&b.push({element:a,left:a.scrollLeft,top:a.scrollTop});"function"===typeof c.focus&&c.focus();for(c=0;c<b.length;c++)a=b[c],a.element.scrollLeft=a.left,a.element.scrollTop=a.top}}
var Pe=ia&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;
function Ue(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Ne(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se&&Ie(Se,d)||(Se=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)))}
function Ve(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var We={animationend:Ve("Animation","AnimationEnd"),animationiteration:Ve("Animation","AnimationIteration"),animationstart:Ve("Animation","AnimationStart"),transitionend:Ve("Transition","TransitionEnd")},Xe={},Ye={};
ia&&(Ye=document.createElement("div").style,"AnimationEvent"in window||(delete We.animationend.animation,delete We.animationiteration.animation,delete We.animationstart.animation),"TransitionEvent"in window||delete We.transitionend.transition);function Ze(a){if(Xe[a])return Xe[a];if(!We[a])return a;var b=We[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Ye)return Xe[a]=b[c];return a}var $e=Ze("animationend"),af=Ze("animationiteration"),bf=Ze("animationstart"),cf=Ze("transitionend"),df=new Map,ef="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function ff(a,b){df.set(a,b);fa(b,[a])}for(var gf=0;gf<ef.length;gf++){var hf=ef[gf],jf=hf.toLowerCase(),kf=hf[0].toUpperCase()+hf.slice(1);ff(jf,"on"+kf)}ff($e,"onAnimationEnd");ff(af,"onAnimationIteration");ff(bf,"onAnimationStart");ff("dblclick","onDoubleClick");ff("focusin","onFocus");ff("focusout","onBlur");ff(cf,"onTransitionEnd");ha("onMouseEnter",["mouseout","mouseover"]);ha("onMouseLeave",["mouseout","mouseover"]);ha("onPointerEnter",["pointerout","pointerover"]);
ha("onPointerLeave",["pointerout","pointerover"]);fa("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));fa("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));fa("onBeforeInput",["compositionend","keypress","textInput","paste"]);fa("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));fa("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));
fa("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var lf="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),mf=new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
function nf(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Ub(d,b,void 0,a);a.currentTarget=null}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;nf(e,h,l);f=k}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;nf(e,h,l);f=k}}}if(Qb)throw a=Rb,Qb=!1,Rb=null,a;}
function D(a,b){var c=b[of];void 0===c&&(c=b[of]=new Set);var d=a+"__bubble";c.has(d)||(pf(b,a,2,!1),c.add(d))}function qf(a,b,c){var d=0;b&&(d|=4);pf(c,a,d,b)}var rf="_reactListening"+Math.random().toString(36).slice(2);function sf(a){if(!a[rf]){a[rf]=!0;da.forEach(function(b){"selectionchange"!==b&&(mf.has(b)||qf(b,!1,a),qf(b,!0,a))});var b=9===a.nodeType?a:a.ownerDocument;null===b||b[rf]||(b[rf]=!0,qf("selectionchange",!1,b))}}
function pf(a,b,c,d){switch(jd(b)){case 1:var e=ed;break;case 4:e=gd;break;default:e=fd}c=e.bind(null,b,c,a);e=void 0;!Lb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=!0);d?void 0!==e?a.addEventListener(b,c,{capture:!0,passive:e}):a.addEventListener(b,c,!0):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,!1)}
function hd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return}for(;null!==h;){g=Wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode}}d=d.return}Jb(function(){var d=f,e=xb(c),g=[];
a:{var h=df.get(a);if(void 0!==h){var k=td,n=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":n="focus";k=Fd;break;case "focusout":n="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case $e:case af:case bf:k=Hd;break;case cf:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td}var t=0!==(b&4),J=!t&&"scroll"===a,x=t?null!==h?h+"Capture":null:h;t=[];for(var w=d,u;null!==
w;){u=w;var F=u.stateNode;5===u.tag&&null!==F&&(u=F,null!==x&&(F=Kb(w,x),null!=F&&t.push(tf(w,F,u))));if(J)break;w=w.return}0<t.length&&(h=new k(h,n,null,c,e),g.push({event:h,listeners:t}))}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&c!==wb&&(n=c.relatedTarget||c.fromElement)&&(Wc(n)||n[uf]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(n=c.relatedTarget||c.toElement,k=d,n=n?Wc(n):null,null!==
n&&(J=Vb(n),n!==J||5!==n.tag&&6!==n.tag))n=null}else k=null,n=d;if(k!==n){t=Bd;F="onMouseLeave";x="onMouseEnter";w="mouse";if("pointerout"===a||"pointerover"===a)t=Td,F="onPointerLeave",x="onPointerEnter",w="pointer";J=null==k?h:ue(k);u=null==n?h:ue(n);h=new t(F,w+"leave",k,c,e);h.target=J;h.relatedTarget=u;F=null;Wc(e)===d&&(t=new t(x,w+"enter",n,c,e),t.target=u,t.relatedTarget=J,F=t);J=F;if(k&&n)b:{t=k;x=n;w=0;for(u=t;u;u=vf(u))w++;u=0;for(F=x;F;F=vf(F))u++;for(;0<w-u;)t=vf(t),w--;for(;0<u-w;)x=
vf(x),u--;for(;w--;){if(t===x||null!==x&&t===x.alternate)break b;t=vf(t);x=vf(x)}t=null}else t=null;null!==k&&wf(g,h,k,t,!1);null!==n&&null!==J&&wf(g,J,n,t,!0)}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var na=ve;else if(me(h))if(we)na=Fe;else{na=De;var xa=Ce}else(k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(na=Ee);if(na&&(na=na(a,d))){ne(g,na,c,e);break a}xa&&xa(a,h,d);"focusout"===a&&(xa=h._wrapperState)&&
xa.controlled&&"number"===h.type&&cb(h,"number",h.value)}xa=d?ue(d):window;switch(a){case "focusin":if(me(xa)||"true"===xa.contentEditable)Qe=xa,Re=d,Se=null;break;case "focusout":Se=Re=Qe=null;break;case "mousedown":Te=!0;break;case "contextmenu":case "mouseup":case "dragend":Te=!1;Ue(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue(g,c,e)}var $a;if(ae)b:{switch(a){case "compositionstart":var ba="onCompositionStart";break b;case "compositionend":ba="onCompositionEnd";
break b;case "compositionupdate":ba="onCompositionUpdate";break b}ba=void 0}else ie?ge(a,c)&&(ba="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(ba="onCompositionStart");ba&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==ba?"onCompositionEnd"===ba&&ie&&($a=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=!0)),xa=oe(d,ba),0<xa.length&&(ba=new Ld(ba,a,null,c,e),g.push({event:ba,listeners:xa}),$a?ba.data=$a:($a=he(c),null!==$a&&(ba.data=$a))));if($a=ce?je(a,c):ke(a,c))d=oe(d,"onBeforeInput"),
0<d.length&&(e=new Ld("onBeforeInput","beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=$a)}se(g,b)})}function tf(a,b,c){return{instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Kb(a,c),null!=f&&d.unshift(tf(a,f,e)),f=Kb(a,b),null!=f&&d.push(tf(a,f,e)));a=a.return}return d}function vf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function wf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Kb(c,f),null!=k&&g.unshift(tf(c,k,h))):e||(k=Kb(c,f),null!=k&&g.push(tf(c,k,h))));c=c.return}0!==g.length&&a.push({event:b,listeners:g})}var xf=/\r\n?/g,yf=/\u0000|\uFFFD/g;function zf(a){return("string"===typeof a?a:""+a).replace(xf,"\n").replace(yf,"")}function Af(a,b,c){b=zf(b);if(zf(a)!==b&&c)throw Error(p(425));}function Bf(){}
var Cf=null,Df=null;function Ef(a,b){return"textarea"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}
var Ff="function"===typeof setTimeout?setTimeout:void 0,Gf="function"===typeof clearTimeout?clearTimeout:void 0,Hf="function"===typeof Promise?Promise:void 0,Jf="function"===typeof queueMicrotask?queueMicrotask:"undefined"!==typeof Hf?function(a){return Hf.resolve(null).then(a).catch(If)}:Ff;function If(a){setTimeout(function(){throw a;})}
function Kf(a,b){var c=b,d=0;do{var e=c.nextSibling;a.removeChild(c);if(e&&8===e.nodeType)if(c=e.data,"/$"===c){if(0===d){a.removeChild(e);bd(b);return}d--}else"$"!==c&&"$?"!==c&&"$!"!==c||d++;c=e}while(c);bd(b)}function Lf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break;if(8===b){b=a.data;if("$"===b||"$!"===b||"$?"===b)break;if("/$"===b)return null}}return a}
function Mf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--}else"/$"===c&&b++}a=a.previousSibling}return null}var Nf=Math.random().toString(36).slice(2),Of="__reactFiber$"+Nf,Pf="__reactProps$"+Nf,uf="__reactContainer$"+Nf,of="__reactEvents$"+Nf,Qf="__reactListeners$"+Nf,Rf="__reactHandles$"+Nf;
function Wc(a){var b=a[Of];if(b)return b;for(var c=a.parentNode;c;){if(b=c[uf]||c[Of]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=Mf(a);null!==a;){if(c=a[Of])return c;a=Mf(a)}return b}a=c;c=a.parentNode}return null}function Cb(a){a=a[Of]||a[uf];return!a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(p(33));}function Db(a){return a[Pf]||null}var Sf=[],Tf=-1;function Uf(a){return{current:a}}
function E(a){0>Tf||(a.current=Sf[Tf],Sf[Tf]=null,Tf--)}function G(a,b){Tf++;Sf[Tf]=a.current;a.current=b}var Vf={},H=Uf(Vf),Wf=Uf(!1),Xf=Vf;function Yf(a,b){var c=a.type.contextTypes;if(!c)return Vf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}
function Zf(a){a=a.childContextTypes;return null!==a&&void 0!==a}function $f(){E(Wf);E(H)}function ag(a,b,c){if(H.current!==Vf)throw Error(p(168));G(H,b);G(Wf,c)}function bg(a,b,c){var d=a.stateNode;b=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in b))throw Error(p(108,Ra(a)||"Unknown",e));return A({},c,d)}
function cg(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Vf;Xf=H.current;G(H,a);G(Wf,Wf.current);return!0}function dg(a,b,c){var d=a.stateNode;if(!d)throw Error(p(169));c?(a=bg(a,b,Xf),d.__reactInternalMemoizedMergedChildContext=a,E(Wf),E(H),G(H,a)):E(Wf);G(Wf,c)}var eg=null,fg=!1,gg=!1;function hg(a){null===eg?eg=[a]:eg.push(a)}function ig(a){fg=!0;hg(a)}
function jg(){if(!gg&&null!==eg){gg=!0;var a=0,b=C;try{var c=eg;for(C=1;a<c.length;a++){var d=c[a];do d=d(!0);while(null!==d)}eg=null;fg=!1}catch(e){throw null!==eg&&(eg=eg.slice(a+1)),ac(fc,jg),e;}finally{C=b,gg=!1}}return null}var kg=[],lg=0,mg=null,ng=0,og=[],pg=0,qg=null,rg=1,sg="";function tg(a,b){kg[lg++]=ng;kg[lg++]=mg;mg=a;ng=b}
function ug(a,b,c){og[pg++]=rg;og[pg++]=sg;og[pg++]=qg;qg=a;var d=rg;a=sg;var e=32-oc(d)-1;d&=~(1<<e);c+=1;var f=32-oc(b)+e;if(30<f){var g=e-e%5;f=(d&(1<<g)-1).toString(32);d>>=g;e-=g;rg=1<<32-oc(b)+e|c<<e|d;sg=f+a}else rg=1<<f|c<<e|d,sg=a}function vg(a){null!==a.return&&(tg(a,1),ug(a,1,0))}function wg(a){for(;a===mg;)mg=kg[--lg],kg[lg]=null,ng=kg[--lg],kg[lg]=null;for(;a===qg;)qg=og[--pg],og[pg]=null,sg=og[--pg],og[pg]=null,rg=og[--pg],og[pg]=null}var xg=null,yg=null,I=!1,zg=null;
function Ag(a,b){var c=Bg(5,null,null,0);c.elementType="DELETED";c.stateNode=b;c.return=a;b=a.deletions;null===b?(a.deletions=[c],a.flags|=16):b.push(c)}
function Cg(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,xg=a,yg=Lf(b.firstChild),!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,xg=a,yg=null,!0):!1;case 13:return b=8!==b.nodeType?null:b,null!==b?(c=null!==qg?{id:rg,overflow:sg}:null,a.memoizedState={dehydrated:b,treeContext:c,retryLane:1073741824},c=Bg(18,null,null,0),c.stateNode=b,c.return=a,a.child=c,xg=a,yg=
null,!0):!1;default:return!1}}function Dg(a){return 0!==(a.mode&1)&&0===(a.flags&128)}function Eg(a){if(I){var b=yg;if(b){var c=b;if(!Cg(a,b)){if(Dg(a))throw Error(p(418));b=Lf(c.nextSibling);var d=xg;b&&Cg(a,b)?Ag(d,c):(a.flags=a.flags&-4097|2,I=!1,xg=a)}}else{if(Dg(a))throw Error(p(418));a.flags=a.flags&-4097|2;I=!1;xg=a}}}function Fg(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;xg=a}
function Gg(a){if(a!==xg)return!1;if(!I)return Fg(a),I=!0,!1;var b;(b=3!==a.tag)&&!(b=5!==a.tag)&&(b=a.type,b="head"!==b&&"body"!==b&&!Ef(a.type,a.memoizedProps));if(b&&(b=yg)){if(Dg(a))throw Hg(),Error(p(418));for(;b;)Ag(a,b),b=Lf(b.nextSibling)}Fg(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(p(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){yg=Lf(a.nextSibling);break a}b--}else"$"!==c&&"$!"!==c&&"$?"!==c||b++}a=a.nextSibling}yg=
null}}else yg=xg?Lf(a.stateNode.nextSibling):null;return!0}function Hg(){for(var a=yg;a;)a=Lf(a.nextSibling)}function Ig(){yg=xg=null;I=!1}function Jg(a){null===zg?zg=[a]:zg.push(a)}var Kg=ua.ReactCurrentBatchConfig;function Lg(a,b){if(a&&a.defaultProps){b=A({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);return b}return b}var Mg=Uf(null),Ng=null,Og=null,Pg=null;function Qg(){Pg=Og=Ng=null}function Rg(a){var b=Mg.current;E(Mg);a._currentValue=b}
function Sg(a,b,c){for(;null!==a;){var d=a.alternate;(a.childLanes&b)!==b?(a.childLanes|=b,null!==d&&(d.childLanes|=b)):null!==d&&(d.childLanes&b)!==b&&(d.childLanes|=b);if(a===c)break;a=a.return}}function Tg(a,b){Ng=a;Pg=Og=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(Ug=!0),a.firstContext=null)}
function Vg(a){var b=a._currentValue;if(Pg!==a)if(a={context:a,memoizedValue:b,next:null},null===Og){if(null===Ng)throw Error(p(308));Og=a;Ng.dependencies={lanes:0,firstContext:a}}else Og=Og.next=a;return b}var Wg=null;function Xg(a){null===Wg?Wg=[a]:Wg.push(a)}function Yg(a,b,c,d){var e=b.interleaved;null===e?(c.next=c,Xg(b)):(c.next=e.next,e.next=c);b.interleaved=c;return Zg(a,d)}
function Zg(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}var $g=!1;function ah(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}
function bh(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects})}function ch(a,b){return{eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}
function dh(a,b,c){var d=a.updateQueue;if(null===d)return null;d=d.shared;if(0!==(K&2)){var e=d.pending;null===e?b.next=b:(b.next=e.next,e.next=b);d.pending=b;return Zg(a,c)}e=d.interleaved;null===e?(b.next=b,Xg(d)):(b.next=e.next,e.next=b);d.interleaved=b;return Zg(a,c)}function eh(a,b,c){b=b.updateQueue;if(null!==b&&(b=b.shared,0!==(c&4194240))){var d=b.lanes;d&=a.pendingLanes;c|=d;b.lanes=c;Cc(a,c)}}
function fh(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next}while(null!==c);null===f?e=f=b:f=f.next=b}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b}
function gh(a,b,c,d){var e=a.updateQueue;$g=!1;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var m=a.alternate;null!==m&&(m=m.updateQueue,h=m.lastBaseUpdate,h!==g&&(null===h?m.firstBaseUpdate=l:h.next=l,m.lastBaseUpdate=k))}if(null!==f){var q=e.baseState;g=0;m=l=k=null;h=f;do{var r=h.lane,y=h.eventTime;if((d&r)===r){null!==m&&(m=m.next={eventTime:y,lane:0,tag:h.tag,payload:h.payload,callback:h.callback,
next:null});a:{var n=a,t=h;r=b;y=c;switch(t.tag){case 1:n=t.payload;if("function"===typeof n){q=n.call(y,q,r);break a}q=n;break a;case 3:n.flags=n.flags&-65537|128;case 0:n=t.payload;r="function"===typeof n?n.call(y,q,r):n;if(null===r||void 0===r)break a;q=A({},q,r);break a;case 2:$g=!0}}null!==h.callback&&0!==h.lane&&(a.flags|=64,r=e.effects,null===r?e.effects=[h]:r.push(h))}else y={eventTime:y,lane:r,tag:h.tag,payload:h.payload,callback:h.callback,next:null},null===m?(l=m=y,k=q):m=m.next=y,g|=r;
h=h.next;if(null===h)if(h=e.shared.pending,null===h)break;else r=h,h=r.next,r.next=null,e.lastBaseUpdate=r,e.shared.pending=null}while(1);null===m&&(k=q);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=m;b=e.shared.interleaved;if(null!==b){e=b;do g|=e.lane,e=e.next;while(e!==b)}else null===f&&(e.shared.lanes=0);hh|=g;a.lanes=g;a.memoizedState=q}}
function ih(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(p(191,e));e.call(d)}}}var jh=(new aa.Component).refs;function kh(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:A({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c)}
var nh={isMounted:function(a){return(a=a._reactInternals)?Vb(a)===a:!1},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=L(),e=lh(a),f=ch(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);b=dh(a,f,e);null!==b&&(mh(b,a,e,d),eh(b,a,e))},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=L(),e=lh(a),f=ch(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);b=dh(a,f,e);null!==b&&(mh(b,a,e,d),eh(b,a,e))},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=L(),d=
lh(a),e=ch(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=b);b=dh(a,e,d);null!==b&&(mh(b,a,d,c),eh(b,a,d))}};function oh(a,b,c,d,e,f,g){a=a.stateNode;return"function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Ie(c,d)||!Ie(e,f):!0}
function ph(a,b,c){var d=!1,e=Vf;var f=b.contextType;"object"===typeof f&&null!==f?f=Vg(f):(e=Zf(b)?Xf:H.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Yf(a,e):Vf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=nh;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function qh(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&nh.enqueueReplaceState(b,b.state,null)}
function rh(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=jh;ah(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=Vg(f):(f=Zf(b)?Xf:H.current,e.context=Yf(a,f));e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(kh(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||(b=e.state,
"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&nh.enqueueReplaceState(e,e.state,null),gh(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4194308)}
function sh(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(p(309));var d=c.stateNode}if(!d)throw Error(p(147,a));var e=d,f=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===f)return b.ref;b=function(a){var b=e.refs;b===jh&&(b=e.refs={});null===a?delete b[f]:b[f]=a};b._stringRef=f;return b}if("string"!==typeof a)throw Error(p(284));if(!c._owner)throw Error(p(290,a));}return a}
function th(a,b){a=Object.prototype.toString.call(b);throw Error(p(31,"[object Object]"===a?"object with keys {"+Object.keys(b).join(", ")+"}":a));}function uh(a){var b=a._init;return b(a._payload)}
function vh(a){function b(b,c){if(a){var d=b.deletions;null===d?(b.deletions=[c],b.flags|=16):d.push(c)}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=wh(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return b.flags|=1048576,c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags|=2,c):d;b.flags|=2;return c}function g(b){a&&
null===b.alternate&&(b.flags|=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=xh(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){var f=c.type;if(f===ya)return m(a,b,c.props.children,d,c.key);if(null!==b&&(b.elementType===f||"object"===typeof f&&null!==f&&f.$$typeof===Ha&&uh(f)===b.type))return d=e(b,c.props),d.ref=sh(a,b,c),d.return=a,d;d=yh(c.type,c.key,c.props,null,a.mode,d);d.ref=sh(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||
b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=zh(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function m(a,b,c,d,f){if(null===b||7!==b.tag)return b=Ah(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function q(a,b,c){if("string"===typeof b&&""!==b||"number"===typeof b)return b=xh(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case va:return c=yh(b.type,b.key,b.props,null,a.mode,c),
c.ref=sh(a,null,b),c.return=a,c;case wa:return b=zh(b,a.mode,c),b.return=a,b;case Ha:var d=b._init;return q(a,d(b._payload),c)}if(eb(b)||Ka(b))return b=Ah(b,a.mode,c,null),b.return=a,b;th(a,b)}return null}function r(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c&&""!==c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case va:return c.key===e?k(a,b,c,d):null;case wa:return c.key===e?l(a,b,c,d):null;case Ha:return e=c._init,r(a,
b,e(c._payload),d)}if(eb(c)||Ka(c))return null!==e?null:m(a,b,c,d,null);th(a,c)}return null}function y(a,b,c,d,e){if("string"===typeof d&&""!==d||"number"===typeof d)return a=a.get(c)||null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case va:return a=a.get(null===d.key?c:d.key)||null,k(b,a,d,e);case wa:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e);case Ha:var f=d._init;return y(a,b,c,f(d._payload),e)}if(eb(d)||Ka(d))return a=a.get(c)||null,m(b,a,d,e,null);th(b,d)}return null}
function n(e,g,h,k){for(var l=null,m=null,u=g,w=g=0,x=null;null!==u&&w<h.length;w++){u.index>w?(x=u,u=null):x=u.sibling;var n=r(e,u,h[w],k);if(null===n){null===u&&(u=x);break}a&&u&&null===n.alternate&&b(e,u);g=f(n,g,w);null===m?l=n:m.sibling=n;m=n;u=x}if(w===h.length)return c(e,u),I&&tg(e,w),l;if(null===u){for(;w<h.length;w++)u=q(e,h[w],k),null!==u&&(g=f(u,g,w),null===m?l=u:m.sibling=u,m=u);I&&tg(e,w);return l}for(u=d(e,u);w<h.length;w++)x=y(u,e,w,h[w],k),null!==x&&(a&&null!==x.alternate&&u.delete(null===
x.key?w:x.key),g=f(x,g,w),null===m?l=x:m.sibling=x,m=x);a&&u.forEach(function(a){return b(e,a)});I&&tg(e,w);return l}function t(e,g,h,k){var l=Ka(h);if("function"!==typeof l)throw Error(p(150));h=l.call(h);if(null==h)throw Error(p(151));for(var u=l=null,m=g,w=g=0,x=null,n=h.next();null!==m&&!n.done;w++,n=h.next()){m.index>w?(x=m,m=null):x=m.sibling;var t=r(e,m,n.value,k);if(null===t){null===m&&(m=x);break}a&&m&&null===t.alternate&&b(e,m);g=f(t,g,w);null===u?l=t:u.sibling=t;u=t;m=x}if(n.done)return c(e,
m),I&&tg(e,w),l;if(null===m){for(;!n.done;w++,n=h.next())n=q(e,n.value,k),null!==n&&(g=f(n,g,w),null===u?l=n:u.sibling=n,u=n);I&&tg(e,w);return l}for(m=d(e,m);!n.done;w++,n=h.next())n=y(m,e,w,n.value,k),null!==n&&(a&&null!==n.alternate&&m.delete(null===n.key?w:n.key),g=f(n,g,w),null===u?l=n:u.sibling=n,u=n);a&&m.forEach(function(a){return b(e,a)});I&&tg(e,w);return l}function J(a,d,f,h){"object"===typeof f&&null!==f&&f.type===ya&&null===f.key&&(f=f.props.children);if("object"===typeof f&&null!==f){switch(f.$$typeof){case va:a:{for(var k=
f.key,l=d;null!==l;){if(l.key===k){k=f.type;if(k===ya){if(7===l.tag){c(a,l.sibling);d=e(l,f.props.children);d.return=a;a=d;break a}}else if(l.elementType===k||"object"===typeof k&&null!==k&&k.$$typeof===Ha&&uh(k)===l.type){c(a,l.sibling);d=e(l,f.props);d.ref=sh(a,l,f);d.return=a;a=d;break a}c(a,l);break}else b(a,l);l=l.sibling}f.type===ya?(d=Ah(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=yh(f.type,f.key,f.props,null,a.mode,h),h.ref=sh(a,d,f),h.return=a,a=h)}return g(a);case wa:a:{for(l=f.key;null!==
d;){if(d.key===l)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else{c(a,d);break}else b(a,d);d=d.sibling}d=zh(f,a.mode,h);d.return=a;a=d}return g(a);case Ha:return l=f._init,J(a,d,l(f._payload),h)}if(eb(f))return n(a,d,f,h);if(Ka(f))return t(a,d,f,h);th(a,f)}return"string"===typeof f&&""!==f||"number"===typeof f?(f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):
(c(a,d),d=xh(f,a.mode,h),d.return=a,a=d),g(a)):c(a,d)}return J}var Bh=vh(!0),Ch=vh(!1),Dh={},Eh=Uf(Dh),Fh=Uf(Dh),Gh=Uf(Dh);function Hh(a){if(a===Dh)throw Error(p(174));return a}function Ih(a,b){G(Gh,b);G(Fh,a);G(Eh,Dh);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:lb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=lb(b,a)}E(Eh);G(Eh,b)}function Jh(){E(Eh);E(Fh);E(Gh)}
function Kh(a){Hh(Gh.current);var b=Hh(Eh.current);var c=lb(b,a.type);b!==c&&(G(Fh,a),G(Eh,c))}function Lh(a){Fh.current===a&&(E(Eh),E(Fh))}var M=Uf(0);
function Mh(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&128))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}return null}var Nh=[];
function Oh(){for(var a=0;a<Nh.length;a++)Nh[a]._workInProgressVersionPrimary=null;Nh.length=0}var Ph=ua.ReactCurrentDispatcher,Qh=ua.ReactCurrentBatchConfig,Rh=0,N=null,O=null,P=null,Sh=!1,Th=!1,Uh=0,Vh=0;function Q(){throw Error(p(321));}function Wh(a,b){if(null===b)return!1;for(var c=0;c<b.length&&c<a.length;c++)if(!He(a[c],b[c]))return!1;return!0}
function Xh(a,b,c,d,e,f){Rh=f;N=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;Ph.current=null===a||null===a.memoizedState?Yh:Zh;a=c(d,e);if(Th){f=0;do{Th=!1;Uh=0;if(25<=f)throw Error(p(301));f+=1;P=O=null;b.updateQueue=null;Ph.current=$h;a=c(d,e)}while(Th)}Ph.current=ai;b=null!==O&&null!==O.next;Rh=0;P=O=N=null;Sh=!1;if(b)throw Error(p(300));return a}function bi(){var a=0!==Uh;Uh=0;return a}
function ci(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===P?N.memoizedState=P=a:P=P.next=a;return P}function di(){if(null===O){var a=N.alternate;a=null!==a?a.memoizedState:null}else a=O.next;var b=null===P?N.memoizedState:P.next;if(null!==b)P=b,O=a;else{if(null===a)throw Error(p(310));O=a;a={memoizedState:O.memoizedState,baseState:O.baseState,baseQueue:O.baseQueue,queue:O.queue,next:null};null===P?N.memoizedState=P=a:P=P.next=a}return P}
function ei(a,b){return"function"===typeof b?b(a):b}
function fi(a){var b=di(),c=b.queue;if(null===c)throw Error(p(311));c.lastRenderedReducer=a;var d=O,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g}d.baseQueue=e=f;c.pending=null}if(null!==e){f=e.next;d=d.baseState;var h=g=null,k=null,l=f;do{var m=l.lane;if((Rh&m)===m)null!==k&&(k=k.next={lane:0,action:l.action,hasEagerState:l.hasEagerState,eagerState:l.eagerState,next:null}),d=l.hasEagerState?l.eagerState:a(d,l.action);else{var q={lane:m,action:l.action,hasEagerState:l.hasEagerState,
eagerState:l.eagerState,next:null};null===k?(h=k=q,g=d):k=k.next=q;N.lanes|=m;hh|=m}l=l.next}while(null!==l&&l!==f);null===k?g=d:k.next=h;He(d,b.memoizedState)||(Ug=!0);b.memoizedState=d;b.baseState=g;b.baseQueue=k;c.lastRenderedState=d}a=c.interleaved;if(null!==a){e=a;do f=e.lane,N.lanes|=f,hh|=f,e=e.next;while(e!==a)}else null===e&&(c.lanes=0);return[b.memoizedState,c.dispatch]}
function gi(a){var b=di(),c=b.queue;if(null===c)throw Error(p(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He(f,b.memoizedState)||(Ug=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f}return[f,d]}function hi(){}
function ii(a,b){var c=N,d=di(),e=b(),f=!He(d.memoizedState,e);f&&(d.memoizedState=e,Ug=!0);d=d.queue;ji(ki.bind(null,c,d,a),[a]);if(d.getSnapshot!==b||f||null!==P&&P.memoizedState.tag&1){c.flags|=2048;li(9,mi.bind(null,c,d,e,b),void 0,null);if(null===R)throw Error(p(349));0!==(Rh&30)||ni(c,b,e)}return e}function ni(a,b,c){a.flags|=16384;a={getSnapshot:b,value:c};b=N.updateQueue;null===b?(b={lastEffect:null,stores:null},N.updateQueue=b,b.stores=[a]):(c=b.stores,null===c?b.stores=[a]:c.push(a))}
function mi(a,b,c,d){b.value=c;b.getSnapshot=d;oi(b)&&pi(a)}function ki(a,b,c){return c(function(){oi(b)&&pi(a)})}function oi(a){var b=a.getSnapshot;a=a.value;try{var c=b();return!He(a,c)}catch(d){return!0}}function pi(a){var b=Zg(a,1);null!==b&&mh(b,a,1,-1)}
function qi(a){var b=ci();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:ei,lastRenderedState:a};b.queue=a;a=a.dispatch=ri.bind(null,N,a);return[b.memoizedState,a]}
function li(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=N.updateQueue;null===b?(b={lastEffect:null,stores:null},N.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function si(){return di().memoizedState}function ti(a,b,c,d){var e=ci();N.flags|=a;e.memoizedState=li(1|b,c,void 0,void 0===d?null:d)}
function ui(a,b,c,d){var e=di();d=void 0===d?null:d;var f=void 0;if(null!==O){var g=O.memoizedState;f=g.destroy;if(null!==d&&Wh(d,g.deps)){e.memoizedState=li(b,c,f,d);return}}N.flags|=a;e.memoizedState=li(1|b,c,f,d)}function vi(a,b){return ti(8390656,8,a,b)}function ji(a,b){return ui(2048,8,a,b)}function wi(a,b){return ui(4,2,a,b)}function xi(a,b){return ui(4,4,a,b)}
function yi(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null)};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null}}function zi(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return ui(4,4,yi.bind(null,b,a),c)}function Ai(){}function Bi(a,b){var c=di();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Wh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}
function Ci(a,b){var c=di();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Wh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}function Di(a,b,c){if(0===(Rh&21))return a.baseState&&(a.baseState=!1,Ug=!0),a.memoizedState=c;He(c,b)||(c=yc(),N.lanes|=c,hh|=c,a.baseState=!0);return b}function Ei(a,b){var c=C;C=0!==c&&4>c?c:4;a(!0);var d=Qh.transition;Qh.transition={};try{a(!1),b()}finally{C=c,Qh.transition=d}}function Fi(){return di().memoizedState}
function Gi(a,b,c){var d=lh(a);c={lane:d,action:c,hasEagerState:!1,eagerState:null,next:null};if(Hi(a))Ii(b,c);else if(c=Yg(a,b,c,d),null!==c){var e=L();mh(c,a,d,e);Ji(c,b,d)}}
function ri(a,b,c){var d=lh(a),e={lane:d,action:c,hasEagerState:!1,eagerState:null,next:null};if(Hi(a))Ii(b,e);else{var f=a.alternate;if(0===a.lanes&&(null===f||0===f.lanes)&&(f=b.lastRenderedReducer,null!==f))try{var g=b.lastRenderedState,h=f(g,c);e.hasEagerState=!0;e.eagerState=h;if(He(h,g)){var k=b.interleaved;null===k?(e.next=e,Xg(b)):(e.next=k.next,k.next=e);b.interleaved=e;return}}catch(l){}finally{}c=Yg(a,b,e,d);null!==c&&(e=L(),mh(c,a,d,e),Ji(c,b,d))}}
function Hi(a){var b=a.alternate;return a===N||null!==b&&b===N}function Ii(a,b){Th=Sh=!0;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b}function Ji(a,b,c){if(0!==(c&4194240)){var d=b.lanes;d&=a.pendingLanes;c|=d;b.lanes=c;Cc(a,c)}}
var ai={readContext:Vg,useCallback:Q,useContext:Q,useEffect:Q,useImperativeHandle:Q,useInsertionEffect:Q,useLayoutEffect:Q,useMemo:Q,useReducer:Q,useRef:Q,useState:Q,useDebugValue:Q,useDeferredValue:Q,useTransition:Q,useMutableSource:Q,useSyncExternalStore:Q,useId:Q,unstable_isNewReconciler:!1},Yh={readContext:Vg,useCallback:function(a,b){ci().memoizedState=[a,void 0===b?null:b];return a},useContext:Vg,useEffect:vi,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return ti(4194308,
4,yi.bind(null,b,a),c)},useLayoutEffect:function(a,b){return ti(4194308,4,a,b)},useInsertionEffect:function(a,b){return ti(4,2,a,b)},useMemo:function(a,b){var c=ci();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=ci();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};d.queue=a;a=a.dispatch=Gi.bind(null,N,a);return[d.memoizedState,a]},useRef:function(a){var b=
ci();a={current:a};return b.memoizedState=a},useState:qi,useDebugValue:Ai,useDeferredValue:function(a){return ci().memoizedState=a},useTransition:function(){var a=qi(!1),b=a[0];a=Ei.bind(null,a[1]);ci().memoizedState=a;return[b,a]},useMutableSource:function(){},useSyncExternalStore:function(a,b,c){var d=N,e=ci();if(I){if(void 0===c)throw Error(p(407));c=c()}else{c=b();if(null===R)throw Error(p(349));0!==(Rh&30)||ni(d,b,c)}e.memoizedState=c;var f={value:c,getSnapshot:b};e.queue=f;vi(ki.bind(null,d,
f,a),[a]);d.flags|=2048;li(9,mi.bind(null,d,f,c,b),void 0,null);return c},useId:function(){var a=ci(),b=R.identifierPrefix;if(I){var c=sg;var d=rg;c=(d&~(1<<32-oc(d)-1)).toString(32)+c;b=":"+b+"R"+c;c=Uh++;0<c&&(b+="H"+c.toString(32));b+=":"}else c=Vh++,b=":"+b+"r"+c.toString(32)+":";return a.memoizedState=b},unstable_isNewReconciler:!1},Zh={readContext:Vg,useCallback:Bi,useContext:Vg,useEffect:ji,useImperativeHandle:zi,useInsertionEffect:wi,useLayoutEffect:xi,useMemo:Ci,useReducer:fi,useRef:si,useState:function(){return fi(ei)},
useDebugValue:Ai,useDeferredValue:function(a){var b=di();return Di(b,O.memoizedState,a)},useTransition:function(){var a=fi(ei)[0],b=di().memoizedState;return[a,b]},useMutableSource:hi,useSyncExternalStore:ii,useId:Fi,unstable_isNewReconciler:!1},$h={readContext:Vg,useCallback:Bi,useContext:Vg,useEffect:ji,useImperativeHandle:zi,useInsertionEffect:wi,useLayoutEffect:xi,useMemo:Ci,useReducer:gi,useRef:si,useState:function(){return gi(ei)},useDebugValue:Ai,useDeferredValue:function(a){var b=di();return null===
O?b.memoizedState=a:Di(b,O.memoizedState,a)},useTransition:function(){var a=gi(ei)[0],b=di().memoizedState;return[a,b]},useMutableSource:hi,useSyncExternalStore:ii,useId:Fi,unstable_isNewReconciler:!1};function Ki(a,b){try{var c="",d=b;do c+=Pa(d),d=d.return;while(d);var e=c}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack}return{value:a,source:b,stack:e,digest:null}}function Li(a,b,c){return{value:a,source:null,stack:null!=c?c:null,digest:null!=b?b:null}}
function Mi(a,b){try{console.error(b.value)}catch(c){setTimeout(function(){throw c;})}}var Ni="function"===typeof WeakMap?WeakMap:Map;function Oi(a,b,c){c=ch(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Pi||(Pi=!0,Qi=d);Mi(a,b)};return c}
function Ri(a,b,c){c=ch(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){return d(e)};c.callback=function(){Mi(a,b)}}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){Mi(a,b);"function"!==typeof d&&(null===Si?Si=new Set([this]):Si.add(this));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""})});return c}
function Ti(a,b,c){var d=a.pingCache;if(null===d){d=a.pingCache=new Ni;var e=new Set;d.set(b,e)}else e=d.get(b),void 0===e&&(e=new Set,d.set(b,e));e.has(c)||(e.add(c),a=Ui.bind(null,a,b,c),b.then(a,a))}function Vi(a){do{var b;if(b=13===a.tag)b=a.memoizedState,b=null!==b?null!==b.dehydrated?!0:!1:!0;if(b)return a;a=a.return}while(null!==a);return null}
function Wi(a,b,c,d,e){if(0===(a.mode&1))return a===b?a.flags|=65536:(a.flags|=128,c.flags|=131072,c.flags&=-52805,1===c.tag&&(null===c.alternate?c.tag=17:(b=ch(-1,1),b.tag=2,dh(c,b,1))),c.lanes|=1),a;a.flags|=65536;a.lanes=e;return a}var Xi=ua.ReactCurrentOwner,Ug=!1;function Yi(a,b,c,d){b.child=null===a?Ch(b,null,c,d):Bh(b,a.child,c,d)}
function Zi(a,b,c,d,e){c=c.render;var f=b.ref;Tg(b,e);d=Xh(a,b,c,d,f,e);c=bi();if(null!==a&&!Ug)return b.updateQueue=a.updateQueue,b.flags&=-2053,a.lanes&=~e,$i(a,b,e);I&&c&&vg(b);b.flags|=1;Yi(a,b,d,e);return b.child}
function aj(a,b,c,d,e){if(null===a){var f=c.type;if("function"===typeof f&&!bj(f)&&void 0===f.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=f,cj(a,b,f,d,e);a=yh(c.type,null,d,b,b.mode,e);a.ref=b.ref;a.return=b;return b.child=a}f=a.child;if(0===(a.lanes&e)){var g=f.memoizedProps;c=c.compare;c=null!==c?c:Ie;if(c(g,d)&&a.ref===b.ref)return $i(a,b,e)}b.flags|=1;a=wh(f,d);a.ref=b.ref;a.return=b;return b.child=a}
function cj(a,b,c,d,e){if(null!==a){var f=a.memoizedProps;if(Ie(f,d)&&a.ref===b.ref)if(Ug=!1,b.pendingProps=d=f,0!==(a.lanes&e))0!==(a.flags&131072)&&(Ug=!0);else return b.lanes=a.lanes,$i(a,b,e)}return dj(a,b,c,d,e)}
function ej(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode)if(0===(b.mode&1))b.memoizedState={baseLanes:0,cachePool:null,transitions:null},G(fj,gj),gj|=c;else{if(0===(c&1073741824))return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a,cachePool:null,transitions:null},b.updateQueue=null,G(fj,gj),gj|=a,null;b.memoizedState={baseLanes:0,cachePool:null,transitions:null};d=null!==f?f.baseLanes:c;G(fj,gj);gj|=d}else null!==
f?(d=f.baseLanes|c,b.memoizedState=null):d=c,G(fj,gj),gj|=d;Yi(a,b,e,c);return b.child}function hj(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=512,b.flags|=2097152}function dj(a,b,c,d,e){var f=Zf(c)?Xf:H.current;f=Yf(b,f);Tg(b,e);c=Xh(a,b,c,d,f,e);d=bi();if(null!==a&&!Ug)return b.updateQueue=a.updateQueue,b.flags&=-2053,a.lanes&=~e,$i(a,b,e);I&&d&&vg(b);b.flags|=1;Yi(a,b,c,e);return b.child}
function ij(a,b,c,d,e){if(Zf(c)){var f=!0;cg(b)}else f=!1;Tg(b,e);if(null===b.stateNode)jj(a,b),ph(b,c,d),rh(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=Vg(l):(l=Zf(c)?Xf:H.current,l=Yf(b,l));var m=c.getDerivedStateFromProps,q="function"===typeof m||"function"===typeof g.getSnapshotBeforeUpdate;q||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||
(h!==d||k!==l)&&qh(b,g,d,l);$g=!1;var r=b.memoizedState;g.state=r;gh(b,d,g,e);k=b.memoizedState;h!==d||r!==k||Wf.current||$g?("function"===typeof m&&(kh(b,c,m,d),k=b.memoizedState),(h=$g||oh(b,c,h,d,r,k,l))?(q||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===typeof g.componentDidMount&&(b.flags|=4194308)):
("function"===typeof g.componentDidMount&&(b.flags|=4194308),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4194308),d=!1)}else{g=b.stateNode;bh(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:Lg(b.type,h);g.props=l;q=b.pendingProps;r=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=Vg(k):(k=Zf(c)?Xf:H.current,k=Yf(b,k));var y=c.getDerivedStateFromProps;(m="function"===typeof y||"function"===typeof g.getSnapshotBeforeUpdate)||
"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==q||r!==k)&&qh(b,g,d,k);$g=!1;r=b.memoizedState;g.state=r;gh(b,d,g,e);var n=b.memoizedState;h!==q||r!==n||Wf.current||$g?("function"===typeof y&&(kh(b,c,y,d),n=b.memoizedState),(l=$g||oh(b,c,l,d,r,n,k)||!1)?(m||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,n,k),"function"===typeof g.UNSAFE_componentWillUpdate&&
g.UNSAFE_componentWillUpdate(d,n,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=1024)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=1024),b.memoizedProps=d,b.memoizedState=n),g.props=d,g.state=n,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&r===
a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=1024),d=!1)}return kj(a,b,c,d,f,e)}
function kj(a,b,c,d,e,f){hj(a,b);var g=0!==(b.flags&128);if(!d&&!g)return e&&dg(b,c,!1),$i(a,b,f);d=b.stateNode;Xi.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Bh(b,a.child,null,f),b.child=Bh(b,null,h,f)):Yi(a,b,h,f);b.memoizedState=d.state;e&&dg(b,c,!0);return b.child}function lj(a){var b=a.stateNode;b.pendingContext?ag(a,b.pendingContext,b.pendingContext!==b.context):b.context&&ag(a,b.context,!1);Ih(a,b.containerInfo)}
function mj(a,b,c,d,e){Ig();Jg(e);b.flags|=256;Yi(a,b,c,d);return b.child}var nj={dehydrated:null,treeContext:null,retryLane:0};function oj(a){return{baseLanes:a,cachePool:null,transitions:null}}
function pj(a,b,c){var d=b.pendingProps,e=M.current,f=!1,g=0!==(b.flags&128),h;(h=g)||(h=null!==a&&null===a.memoizedState?!1:0!==(e&2));if(h)f=!0,b.flags&=-129;else if(null===a||null!==a.memoizedState)e|=1;G(M,e&1);if(null===a){Eg(b);a=b.memoizedState;if(null!==a&&(a=a.dehydrated,null!==a))return 0===(b.mode&1)?b.lanes=1:"$!"===a.data?b.lanes=8:b.lanes=1073741824,null;g=d.children;a=d.fallback;return f?(d=b.mode,f=b.child,g={mode:"hidden",children:g},0===(d&1)&&null!==f?(f.childLanes=0,f.pendingProps=
g):f=qj(g,d,0,null),a=Ah(a,d,c,null),f.return=b,a.return=b,f.sibling=a,b.child=f,b.child.memoizedState=oj(c),b.memoizedState=nj,a):rj(b,g)}e=a.memoizedState;if(null!==e&&(h=e.dehydrated,null!==h))return sj(a,b,g,d,h,e,c);if(f){f=d.fallback;g=b.mode;e=a.child;h=e.sibling;var k={mode:"hidden",children:d.children};0===(g&1)&&b.child!==e?(d=b.child,d.childLanes=0,d.pendingProps=k,b.deletions=null):(d=wh(e,k),d.subtreeFlags=e.subtreeFlags&14680064);null!==h?f=wh(h,f):(f=Ah(f,g,c,null),f.flags|=2);f.return=
b;d.return=b;d.sibling=f;b.child=d;d=f;f=b.child;g=a.child.memoizedState;g=null===g?oj(c):{baseLanes:g.baseLanes|c,cachePool:null,transitions:g.transitions};f.memoizedState=g;f.childLanes=a.childLanes&~c;b.memoizedState=nj;return d}f=a.child;a=f.sibling;d=wh(f,{mode:"visible",children:d.children});0===(b.mode&1)&&(d.lanes=c);d.return=b;d.sibling=null;null!==a&&(c=b.deletions,null===c?(b.deletions=[a],b.flags|=16):c.push(a));b.child=d;b.memoizedState=null;return d}
function rj(a,b){b=qj({mode:"visible",children:b},a.mode,0,null);b.return=a;return a.child=b}function tj(a,b,c,d){null!==d&&Jg(d);Bh(b,a.child,null,c);a=rj(b,b.pendingProps.children);a.flags|=2;b.memoizedState=null;return a}
function sj(a,b,c,d,e,f,g){if(c){if(b.flags&256)return b.flags&=-257,d=Li(Error(p(422))),tj(a,b,g,d);if(null!==b.memoizedState)return b.child=a.child,b.flags|=128,null;f=d.fallback;e=b.mode;d=qj({mode:"visible",children:d.children},e,0,null);f=Ah(f,e,g,null);f.flags|=2;d.return=b;f.return=b;d.sibling=f;b.child=d;0!==(b.mode&1)&&Bh(b,a.child,null,g);b.child.memoizedState=oj(g);b.memoizedState=nj;return f}if(0===(b.mode&1))return tj(a,b,g,null);if("$!"===e.data){d=e.nextSibling&&e.nextSibling.dataset;
if(d)var h=d.dgst;d=h;f=Error(p(419));d=Li(f,d,void 0);return tj(a,b,g,d)}h=0!==(g&a.childLanes);if(Ug||h){d=R;if(null!==d){switch(g&-g){case 4:e=2;break;case 16:e=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:e=32;break;case 536870912:e=268435456;break;default:e=0}e=0!==(e&(d.suspendedLanes|g))?0:e;
0!==e&&e!==f.retryLane&&(f.retryLane=e,Zg(a,e),mh(d,a,e,-1))}uj();d=Li(Error(p(421)));return tj(a,b,g,d)}if("$?"===e.data)return b.flags|=128,b.child=a.child,b=vj.bind(null,a),e._reactRetry=b,null;a=f.treeContext;yg=Lf(e.nextSibling);xg=b;I=!0;zg=null;null!==a&&(og[pg++]=rg,og[pg++]=sg,og[pg++]=qg,rg=a.id,sg=a.overflow,qg=b);b=rj(b,d.children);b.flags|=4096;return b}function wj(a,b,c){a.lanes|=b;var d=a.alternate;null!==d&&(d.lanes|=b);Sg(a.return,b,c)}
function xj(a,b,c,d,e){var f=a.memoizedState;null===f?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e}:(f.isBackwards=b,f.rendering=null,f.renderingStartTime=0,f.last=d,f.tail=c,f.tailMode=e)}
function yj(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;Yi(a,b,d.children,c);d=M.current;if(0!==(d&2))d=d&1|2,b.flags|=128;else{if(null!==a&&0!==(a.flags&128))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&wj(a,c,b);else if(19===a.tag)wj(a,c,b);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return}a.sibling.return=a.return;a=a.sibling}d&=1}G(M,d);if(0===(b.mode&1))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===Mh(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);xj(b,!1,e,c,f);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===Mh(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a}xj(b,!0,c,null,f);break;case "together":xj(b,!1,null,null,void 0);break;default:b.memoizedState=null}return b.child}
function jj(a,b){0===(b.mode&1)&&null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2)}function $i(a,b,c){null!==a&&(b.dependencies=a.dependencies);hh|=b.lanes;if(0===(c&b.childLanes))return null;if(null!==a&&b.child!==a.child)throw Error(p(153));if(null!==b.child){a=b.child;c=wh(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=wh(a,a.pendingProps),c.return=b;c.sibling=null}return b.child}
function zj(a,b,c){switch(b.tag){case 3:lj(b);Ig();break;case 5:Kh(b);break;case 1:Zf(b.type)&&cg(b);break;case 4:Ih(b,b.stateNode.containerInfo);break;case 10:var d=b.type._context,e=b.memoizedProps.value;G(Mg,d._currentValue);d._currentValue=e;break;case 13:d=b.memoizedState;if(null!==d){if(null!==d.dehydrated)return G(M,M.current&1),b.flags|=128,null;if(0!==(c&b.child.childLanes))return pj(a,b,c);G(M,M.current&1);a=$i(a,b,c);return null!==a?a.sibling:null}G(M,M.current&1);break;case 19:d=0!==(c&
b.childLanes);if(0!==(a.flags&128)){if(d)return yj(a,b,c);b.flags|=128}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);G(M,M.current);if(d)break;else return null;case 22:case 23:return b.lanes=0,ej(a,b,c)}return $i(a,b,c)}var Aj,Bj,Cj,Dj;
Aj=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return}c.sibling.return=c.return;c=c.sibling}};Bj=function(){};
Cj=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;Hh(Eh.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "select":e=A({},e,{value:void 0});d=A({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=Bf)}ub(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&
(c||(c={}),c[g]="")}else"dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ea.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||(c={}),c[g]=k[g])}else c||(f||(f=[]),f.push(l,
c)),c=k;else"dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ea.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&D("scroll",a),f||h===k||(f=[])):(f=f||[]).push(l,k))}c&&(f=f||[]).push("style",c);var l=f;if(b.updateQueue=l)b.flags|=4}};Dj=function(a,b,c,d){c!==d&&(b.flags|=4)};
function Ej(a,b){if(!I)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null}}
function S(a){var b=null!==a.alternate&&a.alternate.child===a.child,c=0,d=0;if(b)for(var e=a.child;null!==e;)c|=e.lanes|e.childLanes,d|=e.subtreeFlags&14680064,d|=e.flags&14680064,e.return=a,e=e.sibling;else for(e=a.child;null!==e;)c|=e.lanes|e.childLanes,d|=e.subtreeFlags,d|=e.flags,e.return=a,e=e.sibling;a.subtreeFlags|=d;a.childLanes=c;return b}
function Fj(a,b,c){var d=b.pendingProps;wg(b);switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return S(b),null;case 1:return Zf(b.type)&&$f(),S(b),null;case 3:d=b.stateNode;Jh();E(Wf);E(H);Oh();d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)Gg(b)?b.flags|=4:null===a||a.memoizedState.isDehydrated&&0===(b.flags&256)||(b.flags|=1024,null!==zg&&(Gj(zg),zg=null));Bj(a,b);S(b);return null;case 5:Lh(b);var e=Hh(Gh.current);
c=b.type;if(null!==a&&null!=b.stateNode)Cj(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=512,b.flags|=2097152);else{if(!d){if(null===b.stateNode)throw Error(p(166));S(b);return null}a=Hh(Eh.current);if(Gg(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[Of]=b;d[Pf]=f;a=0!==(b.mode&1);switch(c){case "dialog":D("cancel",d);D("close",d);break;case "iframe":case "object":case "embed":D("load",d);break;case "video":case "audio":for(e=0;e<lf.length;e++)D(lf[e],d);break;case "source":D("error",d);break;case "img":case "image":case "link":D("error",
d);D("load",d);break;case "details":D("toggle",d);break;case "input":Za(d,f);D("invalid",d);break;case "select":d._wrapperState={wasMultiple:!!f.multiple};D("invalid",d);break;case "textarea":hb(d,f),D("invalid",d)}ub(c,f);e=null;for(var g in f)if(f.hasOwnProperty(g)){var h=f[g];"children"===g?"string"===typeof h?d.textContent!==h&&(!0!==f.suppressHydrationWarning&&Af(d.textContent,h,a),e=["children",h]):"number"===typeof h&&d.textContent!==""+h&&(!0!==f.suppressHydrationWarning&&Af(d.textContent,
h,a),e=["children",""+h]):ea.hasOwnProperty(g)&&null!=h&&"onScroll"===g&&D("scroll",d)}switch(c){case "input":Va(d);db(d,f,!0);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=Bf)}d=e;b.updateQueue=d;null!==d&&(b.flags|=4)}else{g=9===e.nodeType?e:e.ownerDocument;"http://www.w3.org/1999/xhtml"===a&&(a=kb(c));"http://www.w3.org/1999/xhtml"===a?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):
"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[Of]=b;a[Pf]=d;Aj(a,b,!1,!1);b.stateNode=a;a:{g=vb(c,d);switch(c){case "dialog":D("cancel",a);D("close",a);e=d;break;case "iframe":case "object":case "embed":D("load",a);e=d;break;case "video":case "audio":for(e=0;e<lf.length;e++)D(lf[e],a);e=d;break;case "source":D("error",a);e=d;break;case "img":case "image":case "link":D("error",
a);D("load",a);e=d;break;case "details":D("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);D("invalid",a);break;case "option":e=d;break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=A({},d,{value:void 0});D("invalid",a);break;case "textarea":hb(a,d);e=gb(a,d);D("invalid",a);break;default:e=d}ub(c,e);h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?sb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&nb(a,k)):"children"===f?"string"===typeof k?("textarea"!==
c||""!==k)&&ob(a,k):"number"===typeof k&&ob(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ea.hasOwnProperty(f)?null!=k&&"onScroll"===f&&D("scroll",a):null!=k&&ta(a,f,k,g))}switch(c){case "input":Va(a);db(a,d,!1);break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,!1):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,
!0);break;default:"function"===typeof e.onClick&&(a.onclick=Bf)}switch(c){case "button":case "input":case "select":case "textarea":d=!!d.autoFocus;break a;case "img":d=!0;break a;default:d=!1}}d&&(b.flags|=4)}null!==b.ref&&(b.flags|=512,b.flags|=2097152)}S(b);return null;case 6:if(a&&null!=b.stateNode)Dj(a,b,a.memoizedProps,d);else{if("string"!==typeof d&&null===b.stateNode)throw Error(p(166));c=Hh(Gh.current);Hh(Eh.current);if(Gg(b)){d=b.stateNode;c=b.memoizedProps;d[Of]=b;if(f=d.nodeValue!==c)if(a=
xg,null!==a)switch(a.tag){case 3:Af(d.nodeValue,c,0!==(a.mode&1));break;case 5:!0!==a.memoizedProps.suppressHydrationWarning&&Af(d.nodeValue,c,0!==(a.mode&1))}f&&(b.flags|=4)}else d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[Of]=b,b.stateNode=d}S(b);return null;case 13:E(M);d=b.memoizedState;if(null===a||null!==a.memoizedState&&null!==a.memoizedState.dehydrated){if(I&&null!==yg&&0!==(b.mode&1)&&0===(b.flags&128))Hg(),Ig(),b.flags|=98560,f=!1;else if(f=Gg(b),null!==d&&null!==d.dehydrated){if(null===
a){if(!f)throw Error(p(318));f=b.memoizedState;f=null!==f?f.dehydrated:null;if(!f)throw Error(p(317));f[Of]=b}else Ig(),0===(b.flags&128)&&(b.memoizedState=null),b.flags|=4;S(b);f=!1}else null!==zg&&(Gj(zg),zg=null),f=!0;if(!f)return b.flags&65536?b:null}if(0!==(b.flags&128))return b.lanes=c,b;d=null!==d;d!==(null!==a&&null!==a.memoizedState)&&d&&(b.child.flags|=8192,0!==(b.mode&1)&&(null===a||0!==(M.current&1)?0===T&&(T=3):uj()));null!==b.updateQueue&&(b.flags|=4);S(b);return null;case 4:return Jh(),
Bj(a,b),null===a&&sf(b.stateNode.containerInfo),S(b),null;case 10:return Rg(b.type._context),S(b),null;case 17:return Zf(b.type)&&$f(),S(b),null;case 19:E(M);f=b.memoizedState;if(null===f)return S(b),null;d=0!==(b.flags&128);g=f.rendering;if(null===g)if(d)Ej(f,!1);else{if(0!==T||null!==a&&0!==(a.flags&128))for(a=b.child;null!==a;){g=Mh(a);if(null!==g){b.flags|=128;Ej(f,!1);d=g.updateQueue;null!==d&&(b.updateQueue=d,b.flags|=4);b.subtreeFlags=0;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=14680066,
g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.subtreeFlags=0,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.subtreeFlags=0,f.deletions=null,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;G(M,M.current&1|2);return b.child}a=
a.sibling}null!==f.tail&&B()>Hj&&(b.flags|=128,d=!0,Ej(f,!1),b.lanes=4194304)}else{if(!d)if(a=Mh(g),null!==a){if(b.flags|=128,d=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Ej(f,!0),null===f.tail&&"hidden"===f.tailMode&&!g.alternate&&!I)return S(b),null}else 2*B()-f.renderingStartTime>Hj&&1073741824!==c&&(b.flags|=128,d=!0,Ej(f,!1),b.lanes=4194304);f.isBackwards?(g.sibling=b.child,b.child=g):(c=f.last,null!==c?c.sibling=g:b.child=g,f.last=g)}if(null!==f.tail)return b=f.tail,f.rendering=
b,f.tail=b.sibling,f.renderingStartTime=B(),b.sibling=null,c=M.current,G(M,d?c&1|2:c&1),b;S(b);return null;case 22:case 23:return Ij(),d=null!==b.memoizedState,null!==a&&null!==a.memoizedState!==d&&(b.flags|=8192),d&&0!==(b.mode&1)?0!==(gj&1073741824)&&(S(b),b.subtreeFlags&6&&(b.flags|=8192)):S(b),null;case 24:return null;case 25:return null}throw Error(p(156,b.tag));}
function Jj(a,b){wg(b);switch(b.tag){case 1:return Zf(b.type)&&$f(),a=b.flags,a&65536?(b.flags=a&-65537|128,b):null;case 3:return Jh(),E(Wf),E(H),Oh(),a=b.flags,0!==(a&65536)&&0===(a&128)?(b.flags=a&-65537|128,b):null;case 5:return Lh(b),null;case 13:E(M);a=b.memoizedState;if(null!==a&&null!==a.dehydrated){if(null===b.alternate)throw Error(p(340));Ig()}a=b.flags;return a&65536?(b.flags=a&-65537|128,b):null;case 19:return E(M),null;case 4:return Jh(),null;case 10:return Rg(b.type._context),null;case 22:case 23:return Ij(),
null;case 24:return null;default:return null}}var Kj=!1,U=!1,Lj="function"===typeof WeakSet?WeakSet:Set,V=null;function Mj(a,b){var c=a.ref;if(null!==c)if("function"===typeof c)try{c(null)}catch(d){W(a,b,d)}else c.current=null}function Nj(a,b,c){try{c()}catch(d){W(a,b,d)}}var Oj=!1;
function Pj(a,b){Cf=dd;a=Me();if(Ne(a)){if("selectionStart"in a)var c={start:a.selectionStart,end:a.selectionEnd};else a:{c=(c=a.ownerDocument)&&c.defaultView||window;var d=c.getSelection&&c.getSelection();if(d&&0!==d.rangeCount){c=d.anchorNode;var e=d.anchorOffset,f=d.focusNode;d=d.focusOffset;try{c.nodeType,f.nodeType}catch(F){c=null;break a}var g=0,h=-1,k=-1,l=0,m=0,q=a,r=null;b:for(;;){for(var y;;){q!==c||0!==e&&3!==q.nodeType||(h=g+e);q!==f||0!==d&&3!==q.nodeType||(k=g+d);3===q.nodeType&&(g+=
q.nodeValue.length);if(null===(y=q.firstChild))break;r=q;q=y}for(;;){if(q===a)break b;r===c&&++l===e&&(h=g);r===f&&++m===d&&(k=g);if(null!==(y=q.nextSibling))break;q=r;r=q.parentNode}q=y}c=-1===h||-1===k?null:{start:h,end:k}}else c=null}c=c||{start:0,end:0}}else c=null;Df={focusedElem:a,selectionRange:c};dd=!1;for(V=b;null!==V;)if(b=V,a=b.child,0!==(b.subtreeFlags&1028)&&null!==a)a.return=b,V=a;else for(;null!==V;){b=V;try{var n=b.alternate;if(0!==(b.flags&1024))switch(b.tag){case 0:case 11:case 15:break;
case 1:if(null!==n){var t=n.memoizedProps,J=n.memoizedState,x=b.stateNode,w=x.getSnapshotBeforeUpdate(b.elementType===b.type?t:Lg(b.type,t),J);x.__reactInternalSnapshotBeforeUpdate=w}break;case 3:var u=b.stateNode.containerInfo;1===u.nodeType?u.textContent="":9===u.nodeType&&u.documentElement&&u.removeChild(u.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(p(163));}}catch(F){W(b,b.return,F)}a=b.sibling;if(null!==a){a.return=b.return;V=a;break}V=b.return}n=Oj;Oj=!1;return n}
function Qj(a,b,c){var d=b.updateQueue;d=null!==d?d.lastEffect:null;if(null!==d){var e=d=d.next;do{if((e.tag&a)===a){var f=e.destroy;e.destroy=void 0;void 0!==f&&Nj(b,c,f)}e=e.next}while(e!==d)}}function Rj(a,b){b=b.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){var c=b=b.next;do{if((c.tag&a)===a){var d=c.create;c.destroy=d()}c=c.next}while(c!==b)}}function Sj(a){var b=a.ref;if(null!==b){var c=a.stateNode;switch(a.tag){case 5:a=c;break;default:a=c}"function"===typeof b?b(a):b.current=a}}
function Tj(a){var b=a.alternate;null!==b&&(a.alternate=null,Tj(b));a.child=null;a.deletions=null;a.sibling=null;5===a.tag&&(b=a.stateNode,null!==b&&(delete b[Of],delete b[Pf],delete b[of],delete b[Qf],delete b[Rf]));a.stateNode=null;a.return=null;a.dependencies=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.stateNode=null;a.updateQueue=null}function Uj(a){return 5===a.tag||3===a.tag||4===a.tag}
function Vj(a){a:for(;;){for(;null===a.sibling;){if(null===a.return||Uj(a.return))return null;a=a.return}a.sibling.return=a.return;for(a=a.sibling;5!==a.tag&&6!==a.tag&&18!==a.tag;){if(a.flags&2)continue a;if(null===a.child||4===a.tag)continue a;else a.child.return=a,a=a.child}if(!(a.flags&2))return a.stateNode}}
function Wj(a,b,c){var d=a.tag;if(5===d||6===d)a=a.stateNode,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=Bf));else if(4!==d&&(a=a.child,null!==a))for(Wj(a,b,c),a=a.sibling;null!==a;)Wj(a,b,c),a=a.sibling}
function Xj(a,b,c){var d=a.tag;if(5===d||6===d)a=a.stateNode,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(Xj(a,b,c),a=a.sibling;null!==a;)Xj(a,b,c),a=a.sibling}var X=null,Yj=!1;function Zj(a,b,c){for(c=c.child;null!==c;)ak(a,b,c),c=c.sibling}
function ak(a,b,c){if(lc&&"function"===typeof lc.onCommitFiberUnmount)try{lc.onCommitFiberUnmount(kc,c)}catch(h){}switch(c.tag){case 5:U||Mj(c,b);case 6:var d=X,e=Yj;X=null;Zj(a,b,c);X=d;Yj=e;null!==X&&(Yj?(a=X,c=c.stateNode,8===a.nodeType?a.parentNode.removeChild(c):a.removeChild(c)):X.removeChild(c.stateNode));break;case 18:null!==X&&(Yj?(a=X,c=c.stateNode,8===a.nodeType?Kf(a.parentNode,c):1===a.nodeType&&Kf(a,c),bd(a)):Kf(X,c.stateNode));break;case 4:d=X;e=Yj;X=c.stateNode.containerInfo;Yj=!0;
Zj(a,b,c);X=d;Yj=e;break;case 0:case 11:case 14:case 15:if(!U&&(d=c.updateQueue,null!==d&&(d=d.lastEffect,null!==d))){e=d=d.next;do{var f=e,g=f.destroy;f=f.tag;void 0!==g&&(0!==(f&2)?Nj(c,b,g):0!==(f&4)&&Nj(c,b,g));e=e.next}while(e!==d)}Zj(a,b,c);break;case 1:if(!U&&(Mj(c,b),d=c.stateNode,"function"===typeof d.componentWillUnmount))try{d.props=c.memoizedProps,d.state=c.memoizedState,d.componentWillUnmount()}catch(h){W(c,b,h)}Zj(a,b,c);break;case 21:Zj(a,b,c);break;case 22:c.mode&1?(U=(d=U)||null!==
c.memoizedState,Zj(a,b,c),U=d):Zj(a,b,c);break;default:Zj(a,b,c)}}function bk(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Lj);b.forEach(function(b){var d=ck.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d))})}}
function dk(a,b){var c=b.deletions;if(null!==c)for(var d=0;d<c.length;d++){var e=c[d];try{var f=a,g=b,h=g;a:for(;null!==h;){switch(h.tag){case 5:X=h.stateNode;Yj=!1;break a;case 3:X=h.stateNode.containerInfo;Yj=!0;break a;case 4:X=h.stateNode.containerInfo;Yj=!0;break a}h=h.return}if(null===X)throw Error(p(160));ak(f,g,e);X=null;Yj=!1;var k=e.alternate;null!==k&&(k.return=null);e.return=null}catch(l){W(e,b,l)}}if(b.subtreeFlags&12854)for(b=b.child;null!==b;)ek(b,a),b=b.sibling}
function ek(a,b){var c=a.alternate,d=a.flags;switch(a.tag){case 0:case 11:case 14:case 15:dk(b,a);fk(a);if(d&4){try{Qj(3,a,a.return),Rj(3,a)}catch(t){W(a,a.return,t)}try{Qj(5,a,a.return)}catch(t){W(a,a.return,t)}}break;case 1:dk(b,a);fk(a);d&512&&null!==c&&Mj(c,c.return);break;case 5:dk(b,a);fk(a);d&512&&null!==c&&Mj(c,c.return);if(a.flags&32){var e=a.stateNode;try{ob(e,"")}catch(t){W(a,a.return,t)}}if(d&4&&(e=a.stateNode,null!=e)){var f=a.memoizedProps,g=null!==c?c.memoizedProps:f,h=a.type,k=a.updateQueue;
a.updateQueue=null;if(null!==k)try{"input"===h&&"radio"===f.type&&null!=f.name&&ab(e,f);vb(h,g);var l=vb(h,f);for(g=0;g<k.length;g+=2){var m=k[g],q=k[g+1];"style"===m?sb(e,q):"dangerouslySetInnerHTML"===m?nb(e,q):"children"===m?ob(e,q):ta(e,m,q,l)}switch(h){case "input":bb(e,f);break;case "textarea":ib(e,f);break;case "select":var r=e._wrapperState.wasMultiple;e._wrapperState.wasMultiple=!!f.multiple;var y=f.value;null!=y?fb(e,!!f.multiple,y,!1):r!==!!f.multiple&&(null!=f.defaultValue?fb(e,!!f.multiple,
f.defaultValue,!0):fb(e,!!f.multiple,f.multiple?[]:"",!1))}e[Pf]=f}catch(t){W(a,a.return,t)}}break;case 6:dk(b,a);fk(a);if(d&4){if(null===a.stateNode)throw Error(p(162));e=a.stateNode;f=a.memoizedProps;try{e.nodeValue=f}catch(t){W(a,a.return,t)}}break;case 3:dk(b,a);fk(a);if(d&4&&null!==c&&c.memoizedState.isDehydrated)try{bd(b.containerInfo)}catch(t){W(a,a.return,t)}break;case 4:dk(b,a);fk(a);break;case 13:dk(b,a);fk(a);e=a.child;e.flags&8192&&(f=null!==e.memoizedState,e.stateNode.isHidden=f,!f||
null!==e.alternate&&null!==e.alternate.memoizedState||(gk=B()));d&4&&bk(a);break;case 22:m=null!==c&&null!==c.memoizedState;a.mode&1?(U=(l=U)||m,dk(b,a),U=l):dk(b,a);fk(a);if(d&8192){l=null!==a.memoizedState;if((a.stateNode.isHidden=l)&&!m&&0!==(a.mode&1))for(V=a,m=a.child;null!==m;){for(q=V=m;null!==V;){r=V;y=r.child;switch(r.tag){case 0:case 11:case 14:case 15:Qj(4,r,r.return);break;case 1:Mj(r,r.return);var n=r.stateNode;if("function"===typeof n.componentWillUnmount){d=r;c=r.return;try{b=d,n.props=
b.memoizedProps,n.state=b.memoizedState,n.componentWillUnmount()}catch(t){W(d,c,t)}}break;case 5:Mj(r,r.return);break;case 22:if(null!==r.memoizedState){hk(q);continue}}null!==y?(y.return=r,V=y):hk(q)}m=m.sibling}a:for(m=null,q=a;;){if(5===q.tag){if(null===m){m=q;try{e=q.stateNode,l?(f=e.style,"function"===typeof f.setProperty?f.setProperty("display","none","important"):f.display="none"):(h=q.stateNode,k=q.memoizedProps.style,g=void 0!==k&&null!==k&&k.hasOwnProperty("display")?k.display:null,h.style.display=
rb("display",g))}catch(t){W(a,a.return,t)}}}else if(6===q.tag){if(null===m)try{q.stateNode.nodeValue=l?"":q.memoizedProps}catch(t){W(a,a.return,t)}}else if((22!==q.tag&&23!==q.tag||null===q.memoizedState||q===a)&&null!==q.child){q.child.return=q;q=q.child;continue}if(q===a)break a;for(;null===q.sibling;){if(null===q.return||q.return===a)break a;m===q&&(m=null);q=q.return}m===q&&(m=null);q.sibling.return=q.return;q=q.sibling}}break;case 19:dk(b,a);fk(a);d&4&&bk(a);break;case 21:break;default:dk(b,
a),fk(a)}}function fk(a){var b=a.flags;if(b&2){try{a:{for(var c=a.return;null!==c;){if(Uj(c)){var d=c;break a}c=c.return}throw Error(p(160));}switch(d.tag){case 5:var e=d.stateNode;d.flags&32&&(ob(e,""),d.flags&=-33);var f=Vj(a);Xj(a,f,e);break;case 3:case 4:var g=d.stateNode.containerInfo,h=Vj(a);Wj(a,h,g);break;default:throw Error(p(161));}}catch(k){W(a,a.return,k)}a.flags&=-3}b&4096&&(a.flags&=-4097)}function ik(a,b,c){V=a;jk(a,b,c)}
function jk(a,b,c){for(var d=0!==(a.mode&1);null!==V;){var e=V,f=e.child;if(22===e.tag&&d){var g=null!==e.memoizedState||Kj;if(!g){var h=e.alternate,k=null!==h&&null!==h.memoizedState||U;h=Kj;var l=U;Kj=g;if((U=k)&&!l)for(V=e;null!==V;)g=V,k=g.child,22===g.tag&&null!==g.memoizedState?kk(e):null!==k?(k.return=g,V=k):kk(e);for(;null!==f;)V=f,jk(f,b,c),f=f.sibling;V=e;Kj=h;U=l}lk(a,b,c)}else 0!==(e.subtreeFlags&8772)&&null!==f?(f.return=e,V=f):lk(a,b,c)}}
function lk(a){for(;null!==V;){var b=V;if(0!==(b.flags&8772)){var c=b.alternate;try{if(0!==(b.flags&8772))switch(b.tag){case 0:case 11:case 15:U||Rj(5,b);break;case 1:var d=b.stateNode;if(b.flags&4&&!U)if(null===c)d.componentDidMount();else{var e=b.elementType===b.type?c.memoizedProps:Lg(b.type,c.memoizedProps);d.componentDidUpdate(e,c.memoizedState,d.__reactInternalSnapshotBeforeUpdate)}var f=b.updateQueue;null!==f&&ih(b,f,d);break;case 3:var g=b.updateQueue;if(null!==g){c=null;if(null!==b.child)switch(b.child.tag){case 5:c=
b.child.stateNode;break;case 1:c=b.child.stateNode}ih(b,g,c)}break;case 5:var h=b.stateNode;if(null===c&&b.flags&4){c=h;var k=b.memoizedProps;switch(b.type){case "button":case "input":case "select":case "textarea":k.autoFocus&&c.focus();break;case "img":k.src&&(c.src=k.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(null===b.memoizedState){var l=b.alternate;if(null!==l){var m=l.memoizedState;if(null!==m){var q=m.dehydrated;null!==q&&bd(q)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;
default:throw Error(p(163));}U||b.flags&512&&Sj(b)}catch(r){W(b,b.return,r)}}if(b===a){V=null;break}c=b.sibling;if(null!==c){c.return=b.return;V=c;break}V=b.return}}function hk(a){for(;null!==V;){var b=V;if(b===a){V=null;break}var c=b.sibling;if(null!==c){c.return=b.return;V=c;break}V=b.return}}
function kk(a){for(;null!==V;){var b=V;try{switch(b.tag){case 0:case 11:case 15:var c=b.return;try{Rj(4,b)}catch(k){W(b,c,k)}break;case 1:var d=b.stateNode;if("function"===typeof d.componentDidMount){var e=b.return;try{d.componentDidMount()}catch(k){W(b,e,k)}}var f=b.return;try{Sj(b)}catch(k){W(b,f,k)}break;case 5:var g=b.return;try{Sj(b)}catch(k){W(b,g,k)}}}catch(k){W(b,b.return,k)}if(b===a){V=null;break}var h=b.sibling;if(null!==h){h.return=b.return;V=h;break}V=b.return}}
var mk=Math.ceil,nk=ua.ReactCurrentDispatcher,ok=ua.ReactCurrentOwner,pk=ua.ReactCurrentBatchConfig,K=0,R=null,Y=null,Z=0,gj=0,fj=Uf(0),T=0,qk=null,hh=0,rk=0,sk=0,tk=null,uk=null,gk=0,Hj=Infinity,vk=null,Pi=!1,Qi=null,Si=null,wk=!1,xk=null,yk=0,zk=0,Ak=null,Bk=-1,Ck=0;function L(){return 0!==(K&6)?B():-1!==Bk?Bk:Bk=B()}
function lh(a){if(0===(a.mode&1))return 1;if(0!==(K&2)&&0!==Z)return Z&-Z;if(null!==Kg.transition)return 0===Ck&&(Ck=yc()),Ck;a=C;if(0!==a)return a;a=window.event;a=void 0===a?16:jd(a.type);return a}function mh(a,b,c,d){if(50<zk)throw zk=0,Ak=null,Error(p(185));Ac(a,c,d);if(0===(K&2)||a!==R)a===R&&(0===(K&2)&&(rk|=c),4===T&&Dk(a,Z)),Ek(a,d),1===c&&0===K&&0===(b.mode&1)&&(Hj=B()+500,fg&&jg())}
function Ek(a,b){var c=a.callbackNode;wc(a,b);var d=uc(a,a===R?Z:0);if(0===d)null!==c&&bc(c),a.callbackNode=null,a.callbackPriority=0;else if(b=d&-d,a.callbackPriority!==b){null!=c&&bc(c);if(1===b)0===a.tag?ig(Fk.bind(null,a)):hg(Fk.bind(null,a)),Jf(function(){0===(K&6)&&jg()}),c=null;else{switch(Dc(d)){case 1:c=fc;break;case 4:c=gc;break;case 16:c=hc;break;case 536870912:c=jc;break;default:c=hc}c=Gk(c,Hk.bind(null,a))}a.callbackPriority=b;a.callbackNode=c}}
function Hk(a,b){Bk=-1;Ck=0;if(0!==(K&6))throw Error(p(327));var c=a.callbackNode;if(Ik()&&a.callbackNode!==c)return null;var d=uc(a,a===R?Z:0);if(0===d)return null;if(0!==(d&30)||0!==(d&a.expiredLanes)||b)b=Jk(a,d);else{b=d;var e=K;K|=2;var f=Kk();if(R!==a||Z!==b)vk=null,Hj=B()+500,Lk(a,b);do try{Mk();break}catch(h){Nk(a,h)}while(1);Qg();nk.current=f;K=e;null!==Y?b=0:(R=null,Z=0,b=T)}if(0!==b){2===b&&(e=xc(a),0!==e&&(d=e,b=Ok(a,e)));if(1===b)throw c=qk,Lk(a,0),Dk(a,d),Ek(a,B()),c;if(6===b)Dk(a,d);
else{e=a.current.alternate;if(0===(d&30)&&!Pk(e)&&(b=Jk(a,d),2===b&&(f=xc(a),0!==f&&(d=f,b=Ok(a,f))),1===b))throw c=qk,Lk(a,0),Dk(a,d),Ek(a,B()),c;a.finishedWork=e;a.finishedLanes=d;switch(b){case 0:case 1:throw Error(p(345));case 2:Qk(a,uk,vk);break;case 3:Dk(a,d);if((d&130023424)===d&&(b=gk+500-B(),10<b)){if(0!==uc(a,0))break;e=a.suspendedLanes;if((e&d)!==d){L();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=Ff(Qk.bind(null,a,uk,vk),b);break}Qk(a,uk,vk);break;case 4:Dk(a,d);if((d&4194240)===
d)break;b=a.eventTimes;for(e=-1;0<d;){var g=31-oc(d);f=1<<g;g=b[g];g>e&&(e=g);d&=~f}d=e;d=B()-d;d=(120>d?120:480>d?480:1080>d?1080:1920>d?1920:3E3>d?3E3:4320>d?4320:1960*mk(d/1960))-d;if(10<d){a.timeoutHandle=Ff(Qk.bind(null,a,uk,vk),d);break}Qk(a,uk,vk);break;case 5:Qk(a,uk,vk);break;default:throw Error(p(329));}}}Ek(a,B());return a.callbackNode===c?Hk.bind(null,a):null}
function Ok(a,b){var c=tk;a.current.memoizedState.isDehydrated&&(Lk(a,b).flags|=256);a=Jk(a,b);2!==a&&(b=uk,uk=c,null!==b&&Gj(b));return a}function Gj(a){null===uk?uk=a:uk.push.apply(uk,a)}
function Pk(a){for(var b=a;;){if(b.flags&16384){var c=b.updateQueue;if(null!==c&&(c=c.stores,null!==c))for(var d=0;d<c.length;d++){var e=c[d],f=e.getSnapshot;e=e.value;try{if(!He(f(),e))return!1}catch(g){return!1}}}c=b.child;if(b.subtreeFlags&16384&&null!==c)c.return=b,b=c;else{if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return!0;b=b.return}b.sibling.return=b.return;b=b.sibling}}return!0}
function Dk(a,b){b&=~sk;b&=~rk;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-oc(b),d=1<<c;a[c]=-1;b&=~d}}function Fk(a){if(0!==(K&6))throw Error(p(327));Ik();var b=uc(a,0);if(0===(b&1))return Ek(a,B()),null;var c=Jk(a,b);if(0!==a.tag&&2===c){var d=xc(a);0!==d&&(b=d,c=Ok(a,d))}if(1===c)throw c=qk,Lk(a,0),Dk(a,b),Ek(a,B()),c;if(6===c)throw Error(p(345));a.finishedWork=a.current.alternate;a.finishedLanes=b;Qk(a,uk,vk);Ek(a,B());return null}
function Rk(a,b){var c=K;K|=1;try{return a(b)}finally{K=c,0===K&&(Hj=B()+500,fg&&jg())}}function Sk(a){null!==xk&&0===xk.tag&&0===(K&6)&&Ik();var b=K;K|=1;var c=pk.transition,d=C;try{if(pk.transition=null,C=1,a)return a()}finally{C=d,pk.transition=c,K=b,0===(K&6)&&jg()}}function Ij(){gj=fj.current;E(fj)}
function Lk(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,Gf(c));if(null!==Y)for(c=Y.return;null!==c;){var d=c;wg(d);switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&$f();break;case 3:Jh();E(Wf);E(H);Oh();break;case 5:Lh(d);break;case 4:Jh();break;case 13:E(M);break;case 19:E(M);break;case 10:Rg(d.type._context);break;case 22:case 23:Ij()}c=c.return}R=a;Y=a=wh(a.current,null);Z=gj=b;T=0;qk=null;sk=rk=hh=0;uk=tk=null;if(null!==Wg){for(b=
0;b<Wg.length;b++)if(c=Wg[b],d=c.interleaved,null!==d){c.interleaved=null;var e=d.next,f=c.pending;if(null!==f){var g=f.next;f.next=e;d.next=g}c.pending=d}Wg=null}return a}
function Nk(a,b){do{var c=Y;try{Qg();Ph.current=ai;if(Sh){for(var d=N.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next}Sh=!1}Rh=0;P=O=N=null;Th=!1;Uh=0;ok.current=null;if(null===c||null===c.return){T=1;qk=b;Y=null;break}a:{var f=a,g=c.return,h=c,k=b;b=Z;h.flags|=32768;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k,m=h,q=m.tag;if(0===(m.mode&1)&&(0===q||11===q||15===q)){var r=m.alternate;r?(m.updateQueue=r.updateQueue,m.memoizedState=r.memoizedState,
m.lanes=r.lanes):(m.updateQueue=null,m.memoizedState=null)}var y=Vi(g);if(null!==y){y.flags&=-257;Wi(y,g,h,f,b);y.mode&1&&Ti(f,l,b);b=y;k=l;var n=b.updateQueue;if(null===n){var t=new Set;t.add(k);b.updateQueue=t}else n.add(k);break a}else{if(0===(b&1)){Ti(f,l,b);uj();break a}k=Error(p(426))}}else if(I&&h.mode&1){var J=Vi(g);if(null!==J){0===(J.flags&65536)&&(J.flags|=256);Wi(J,g,h,f,b);Jg(Ki(k,h));break a}}f=k=Ki(k,h);4!==T&&(T=2);null===tk?tk=[f]:tk.push(f);f=g;do{switch(f.tag){case 3:f.flags|=65536;
b&=-b;f.lanes|=b;var x=Oi(f,k,b);fh(f,x);break a;case 1:h=k;var w=f.type,u=f.stateNode;if(0===(f.flags&128)&&("function"===typeof w.getDerivedStateFromError||null!==u&&"function"===typeof u.componentDidCatch&&(null===Si||!Si.has(u)))){f.flags|=65536;b&=-b;f.lanes|=b;var F=Ri(f,h,b);fh(f,F);break a}}f=f.return}while(null!==f)}Tk(c)}catch(na){b=na;Y===c&&null!==c&&(Y=c=c.return);continue}break}while(1)}function Kk(){var a=nk.current;nk.current=ai;return null===a?ai:a}
function uj(){if(0===T||3===T||2===T)T=4;null===R||0===(hh&268435455)&&0===(rk&268435455)||Dk(R,Z)}function Jk(a,b){var c=K;K|=2;var d=Kk();if(R!==a||Z!==b)vk=null,Lk(a,b);do try{Uk();break}catch(e){Nk(a,e)}while(1);Qg();K=c;nk.current=d;if(null!==Y)throw Error(p(261));R=null;Z=0;return T}function Uk(){for(;null!==Y;)Vk(Y)}function Mk(){for(;null!==Y&&!cc();)Vk(Y)}function Vk(a){var b=Wk(a.alternate,a,gj);a.memoizedProps=a.pendingProps;null===b?Tk(a):Y=b;ok.current=null}
function Tk(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&32768)){if(c=Fj(c,b,gj),null!==c){Y=c;return}}else{c=Jj(c,b);if(null!==c){c.flags&=32767;Y=c;return}if(null!==a)a.flags|=32768,a.subtreeFlags=0,a.deletions=null;else{T=6;Y=null;return}}b=b.sibling;if(null!==b){Y=b;return}Y=b=a}while(null!==b);0===T&&(T=5)}function Qk(a,b,c){var d=C,e=pk.transition;try{pk.transition=null,C=1,Xk(a,b,c,d)}finally{pk.transition=e,C=d}return null}
function Xk(a,b,c,d){do Ik();while(null!==xk);if(0!==(K&6))throw Error(p(327));c=a.finishedWork;var e=a.finishedLanes;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(p(177));a.callbackNode=null;a.callbackPriority=0;var f=c.lanes|c.childLanes;Bc(a,f);a===R&&(Y=R=null,Z=0);0===(c.subtreeFlags&2064)&&0===(c.flags&2064)||wk||(wk=!0,Gk(hc,function(){Ik();return null}));f=0!==(c.flags&15990);if(0!==(c.subtreeFlags&15990)||f){f=pk.transition;pk.transition=null;
var g=C;C=1;var h=K;K|=4;ok.current=null;Pj(a,c);ek(c,a);Oe(Df);dd=!!Cf;Df=Cf=null;a.current=c;ik(c,a,e);dc();K=h;C=g;pk.transition=f}else a.current=c;wk&&(wk=!1,xk=a,yk=e);f=a.pendingLanes;0===f&&(Si=null);mc(c.stateNode,d);Ek(a,B());if(null!==b)for(d=a.onRecoverableError,c=0;c<b.length;c++)e=b[c],d(e.value,{componentStack:e.stack,digest:e.digest});if(Pi)throw Pi=!1,a=Qi,Qi=null,a;0!==(yk&1)&&0!==a.tag&&Ik();f=a.pendingLanes;0!==(f&1)?a===Ak?zk++:(zk=0,Ak=a):zk=0;jg();return null}
function Ik(){if(null!==xk){var a=Dc(yk),b=pk.transition,c=C;try{pk.transition=null;C=16>a?16:a;if(null===xk)var d=!1;else{a=xk;xk=null;yk=0;if(0!==(K&6))throw Error(p(331));var e=K;K|=4;for(V=a.current;null!==V;){var f=V,g=f.child;if(0!==(V.flags&16)){var h=f.deletions;if(null!==h){for(var k=0;k<h.length;k++){var l=h[k];for(V=l;null!==V;){var m=V;switch(m.tag){case 0:case 11:case 15:Qj(8,m,f)}var q=m.child;if(null!==q)q.return=m,V=q;else for(;null!==V;){m=V;var r=m.sibling,y=m.return;Tj(m);if(m===
l){V=null;break}if(null!==r){r.return=y;V=r;break}V=y}}}var n=f.alternate;if(null!==n){var t=n.child;if(null!==t){n.child=null;do{var J=t.sibling;t.sibling=null;t=J}while(null!==t)}}V=f}}if(0!==(f.subtreeFlags&2064)&&null!==g)g.return=f,V=g;else b:for(;null!==V;){f=V;if(0!==(f.flags&2048))switch(f.tag){case 0:case 11:case 15:Qj(9,f,f.return)}var x=f.sibling;if(null!==x){x.return=f.return;V=x;break b}V=f.return}}var w=a.current;for(V=w;null!==V;){g=V;var u=g.child;if(0!==(g.subtreeFlags&2064)&&null!==
u)u.return=g,V=u;else b:for(g=w;null!==V;){h=V;if(0!==(h.flags&2048))try{switch(h.tag){case 0:case 11:case 15:Rj(9,h)}}catch(na){W(h,h.return,na)}if(h===g){V=null;break b}var F=h.sibling;if(null!==F){F.return=h.return;V=F;break b}V=h.return}}K=e;jg();if(lc&&"function"===typeof lc.onPostCommitFiberRoot)try{lc.onPostCommitFiberRoot(kc,a)}catch(na){}d=!0}return d}finally{C=c,pk.transition=b}}return!1}function Yk(a,b,c){b=Ki(c,b);b=Oi(a,b,1);a=dh(a,b,1);b=L();null!==a&&(Ac(a,1,b),Ek(a,b))}
function W(a,b,c){if(3===a.tag)Yk(a,a,c);else for(;null!==b;){if(3===b.tag){Yk(b,a,c);break}else if(1===b.tag){var d=b.stateNode;if("function"===typeof b.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Si||!Si.has(d))){a=Ki(c,a);a=Ri(b,a,1);b=dh(b,a,1);a=L();null!==b&&(Ac(b,1,a),Ek(b,a));break}}b=b.return}}
function Ui(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=L();a.pingedLanes|=a.suspendedLanes&c;R===a&&(Z&c)===c&&(4===T||3===T&&(Z&130023424)===Z&&500>B()-gk?Lk(a,0):sk|=c);Ek(a,b)}function Zk(a,b){0===b&&(0===(a.mode&1)?b=1:(b=sc,sc<<=1,0===(sc&130023424)&&(sc=4194304)));var c=L();a=Zg(a,b);null!==a&&(Ac(a,b,c),Ek(a,c))}function vj(a){var b=a.memoizedState,c=0;null!==b&&(c=b.retryLane);Zk(a,c)}
function ck(a,b){var c=0;switch(a.tag){case 13:var d=a.stateNode;var e=a.memoizedState;null!==e&&(c=e.retryLane);break;case 19:d=a.stateNode;break;default:throw Error(p(314));}null!==d&&d.delete(b);Zk(a,c)}var Wk;
Wk=function(a,b,c){if(null!==a)if(a.memoizedProps!==b.pendingProps||Wf.current)Ug=!0;else{if(0===(a.lanes&c)&&0===(b.flags&128))return Ug=!1,zj(a,b,c);Ug=0!==(a.flags&131072)?!0:!1}else Ug=!1,I&&0!==(b.flags&1048576)&&ug(b,ng,b.index);b.lanes=0;switch(b.tag){case 2:var d=b.type;jj(a,b);a=b.pendingProps;var e=Yf(b,H.current);Tg(b,c);e=Xh(null,b,d,a,e,c);var f=bi();b.flags|=1;"object"===typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof?(b.tag=1,b.memoizedState=null,b.updateQueue=
null,Zf(d)?(f=!0,cg(b)):f=!1,b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null,ah(b),e.updater=nh,b.stateNode=e,e._reactInternals=b,rh(b,d,a,c),b=kj(null,b,d,!0,f,c)):(b.tag=0,I&&f&&vg(b),Yi(null,b,e,c),b=b.child);return b;case 16:d=b.elementType;a:{jj(a,b);a=b.pendingProps;e=d._init;d=e(d._payload);b.type=d;e=b.tag=$k(d);a=Lg(d,a);switch(e){case 0:b=dj(null,b,d,a,c);break a;case 1:b=ij(null,b,d,a,c);break a;case 11:b=Zi(null,b,d,a,c);break a;case 14:b=aj(null,b,d,Lg(d.type,a),c);break a}throw Error(p(306,
d,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Lg(d,e),dj(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Lg(d,e),ij(a,b,d,e,c);case 3:a:{lj(b);if(null===a)throw Error(p(387));d=b.pendingProps;f=b.memoizedState;e=f.element;bh(a,b);gh(b,d,null,c);var g=b.memoizedState;d=g.element;if(f.isDehydrated)if(f={element:d,isDehydrated:!1,cache:g.cache,pendingSuspenseBoundaries:g.pendingSuspenseBoundaries,transitions:g.transitions},b.updateQueue.baseState=
f,b.memoizedState=f,b.flags&256){e=Ki(Error(p(423)),b);b=mj(a,b,d,c,e);break a}else if(d!==e){e=Ki(Error(p(424)),b);b=mj(a,b,d,c,e);break a}else for(yg=Lf(b.stateNode.containerInfo.firstChild),xg=b,I=!0,zg=null,c=Ch(b,null,d,c),b.child=c;c;)c.flags=c.flags&-3|4096,c=c.sibling;else{Ig();if(d===e){b=$i(a,b,c);break a}Yi(a,b,d,c)}b=b.child}return b;case 5:return Kh(b),null===a&&Eg(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,Ef(d,e)?g=null:null!==f&&Ef(d,f)&&(b.flags|=32),
hj(a,b),Yi(a,b,g,c),b.child;case 6:return null===a&&Eg(b),null;case 13:return pj(a,b,c);case 4:return Ih(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Bh(b,null,d,c):Yi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Lg(d,e),Zi(a,b,d,e,c);case 7:return Yi(a,b,b.pendingProps,c),b.child;case 8:return Yi(a,b,b.pendingProps.children,c),b.child;case 12:return Yi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;f=b.memoizedProps;
g=e.value;G(Mg,d._currentValue);d._currentValue=g;if(null!==f)if(He(f.value,g)){if(f.children===e.children&&!Wf.current){b=$i(a,b,c);break a}}else for(f=b.child,null!==f&&(f.return=b);null!==f;){var h=f.dependencies;if(null!==h){g=f.child;for(var k=h.firstContext;null!==k;){if(k.context===d){if(1===f.tag){k=ch(-1,c&-c);k.tag=2;var l=f.updateQueue;if(null!==l){l=l.shared;var m=l.pending;null===m?k.next=k:(k.next=m.next,m.next=k);l.pending=k}}f.lanes|=c;k=f.alternate;null!==k&&(k.lanes|=c);Sg(f.return,
c,b);h.lanes|=c;break}k=k.next}}else if(10===f.tag)g=f.type===b.type?null:f.child;else if(18===f.tag){g=f.return;if(null===g)throw Error(p(341));g.lanes|=c;h=g.alternate;null!==h&&(h.lanes|=c);Sg(g,c,b);g=f.sibling}else g=f.child;if(null!==g)g.return=f;else for(g=f;null!==g;){if(g===b){g=null;break}f=g.sibling;if(null!==f){f.return=g.return;g=f;break}g=g.return}f=g}Yi(a,b,e.children,c);b=b.child}return b;case 9:return e=b.type,d=b.pendingProps.children,Tg(b,c),e=Vg(e),d=d(e),b.flags|=1,Yi(a,b,d,c),
b.child;case 14:return d=b.type,e=Lg(d,b.pendingProps),e=Lg(d.type,e),aj(a,b,d,e,c);case 15:return cj(a,b,b.type,b.pendingProps,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Lg(d,e),jj(a,b),b.tag=1,Zf(d)?(a=!0,cg(b)):a=!1,Tg(b,c),ph(b,d,e),rh(b,d,e,c),kj(null,b,d,!0,a,c);case 19:return yj(a,b,c);case 22:return ej(a,b,c)}throw Error(p(156,b.tag));};function Gk(a,b){return ac(a,b)}
function al(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.subtreeFlags=this.flags=0;this.deletions=null;this.childLanes=this.lanes=0;this.alternate=null}function Bg(a,b,c,d){return new al(a,b,c,d)}function bj(a){a=a.prototype;return!(!a||!a.isReactComponent)}
function $k(a){if("function"===typeof a)return bj(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Da)return 11;if(a===Ga)return 14}return 2}
function wh(a,b){var c=a.alternate;null===c?(c=Bg(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.subtreeFlags=0,c.deletions=null);c.flags=a.flags&14680064;c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function yh(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)bj(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ya:return Ah(c.children,e,f,b);case za:g=8;e|=8;break;case Aa:return a=Bg(12,c,b,e|2),a.elementType=Aa,a.lanes=f,a;case Ea:return a=Bg(13,c,b,e),a.elementType=Ea,a.lanes=f,a;case Fa:return a=Bg(19,c,b,e),a.elementType=Fa,a.lanes=f,a;case Ia:return qj(c,e,f,b);default:if("object"===typeof a&&null!==a)switch(a.$$typeof){case Ba:g=10;break a;case Ca:g=9;break a;case Da:g=11;
break a;case Ga:g=14;break a;case Ha:g=16;d=null;break a}throw Error(p(130,null==a?a:typeof a,""));}b=Bg(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Ah(a,b,c,d){a=Bg(7,a,d,b);a.lanes=c;return a}function qj(a,b,c,d){a=Bg(22,a,d,b);a.elementType=Ia;a.lanes=c;a.stateNode={isHidden:!1};return a}function xh(a,b,c){a=Bg(6,a,null,b);a.lanes=c;return a}
function zh(a,b,c){b=Bg(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function bl(a,b,c,d,e){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.callbackNode=this.pendingContext=this.context=null;this.callbackPriority=0;this.eventTimes=zc(0);this.expirationTimes=zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=zc(0);this.identifierPrefix=d;this.onRecoverableError=e;this.mutableSourceEagerHydrationData=
null}function cl(a,b,c,d,e,f,g,h,k){a=new bl(a,b,c,h,k);1===b?(b=1,!0===f&&(b|=8)):b=0;f=Bg(3,null,null,b);a.current=f;f.stateNode=a;f.memoizedState={element:d,isDehydrated:c,cache:null,transitions:null,pendingSuspenseBoundaries:null};ah(f);return a}function dl(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:wa,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function el(a){if(!a)return Vf;a=a._reactInternals;a:{if(Vb(a)!==a||1!==a.tag)throw Error(p(170));var b=a;do{switch(b.tag){case 3:b=b.stateNode.context;break a;case 1:if(Zf(b.type)){b=b.stateNode.__reactInternalMemoizedMergedChildContext;break a}}b=b.return}while(null!==b);throw Error(p(171));}if(1===a.tag){var c=a.type;if(Zf(c))return bg(a,c,b)}return b}
function fl(a,b,c,d,e,f,g,h,k){a=cl(c,d,!0,a,e,f,g,h,k);a.context=el(null);c=a.current;d=L();e=lh(c);f=ch(d,e);f.callback=void 0!==b&&null!==b?b:null;dh(c,f,e);a.current.lanes=e;Ac(a,e,d);Ek(a,d);return a}function gl(a,b,c,d){var e=b.current,f=L(),g=lh(e);c=el(c);null===b.context?b.context=c:b.pendingContext=c;b=ch(f,g);b.payload={element:a};d=void 0===d?null:d;null!==d&&(b.callback=d);a=dh(e,b,g);null!==a&&(mh(a,e,g,f),eh(a,e,g));return g}
function hl(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function il(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b}}function jl(a,b){il(a,b);(a=a.alternate)&&il(a,b)}function kl(){return null}var ll="function"===typeof reportError?reportError:function(a){console.error(a)};function ml(a){this._internalRoot=a}
nl.prototype.render=ml.prototype.render=function(a){var b=this._internalRoot;if(null===b)throw Error(p(409));gl(a,b,null,null)};nl.prototype.unmount=ml.prototype.unmount=function(){var a=this._internalRoot;if(null!==a){this._internalRoot=null;var b=a.containerInfo;Sk(function(){gl(null,a,null,null)});b[uf]=null}};function nl(a){this._internalRoot=a}
nl.prototype.unstable_scheduleHydration=function(a){if(a){var b=Hc();a={blockedOn:null,target:a,priority:b};for(var c=0;c<Qc.length&&0!==b&&b<Qc[c].priority;c++);Qc.splice(c,0,a);0===c&&Vc(a)}};function ol(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType)}function pl(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}function ql(){}
function rl(a,b,c,d,e){if(e){if("function"===typeof d){var f=d;d=function(){var a=hl(g);f.call(a)}}var g=fl(b,d,a,0,null,!1,!1,"",ql);a._reactRootContainer=g;a[uf]=g.current;sf(8===a.nodeType?a.parentNode:a);Sk();return g}for(;e=a.lastChild;)a.removeChild(e);if("function"===typeof d){var h=d;d=function(){var a=hl(k);h.call(a)}}var k=cl(a,0,!1,null,null,!1,!1,"",ql);a._reactRootContainer=k;a[uf]=k.current;sf(8===a.nodeType?a.parentNode:a);Sk(function(){gl(b,k,c,d)});return k}
function sl(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f;if("function"===typeof e){var h=e;e=function(){var a=hl(g);h.call(a)}}gl(b,g,a,e)}else g=rl(c,b,a,e,d);return hl(g)}Ec=function(a){switch(a.tag){case 3:var b=a.stateNode;if(b.current.memoizedState.isDehydrated){var c=tc(b.pendingLanes);0!==c&&(Cc(b,c|1),Ek(b,B()),0===(K&6)&&(Hj=B()+500,jg()))}break;case 13:Sk(function(){var b=Zg(a,1);if(null!==b){var c=L();mh(b,a,1,c)}}),jl(a,1)}};
Fc=function(a){if(13===a.tag){var b=Zg(a,134217728);if(null!==b){var c=L();mh(b,a,134217728,c)}jl(a,134217728)}};Gc=function(a){if(13===a.tag){var b=lh(a),c=Zg(a,b);if(null!==c){var d=L();mh(c,a,b,d)}jl(a,b)}};Hc=function(){return C};Ic=function(a,b){var c=C;try{return C=a,b()}finally{C=c}};
yb=function(a,b,c){switch(b){case "input":bb(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(p(90));Wa(d);bb(d,e)}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,!1)}};Gb=Rk;Hb=Sk;
var tl={usingClientEntryPoint:!1,Events:[Cb,ue,Db,Eb,Fb,Rk]},ul={findFiberByHostInstance:Wc,bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"};
var vl={bundleType:ul.bundleType,version:ul.version,rendererPackageName:ul.rendererPackageName,rendererConfig:ul.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ua.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=Zb(a);return null===a?null:a.stateNode},findFiberByHostInstance:ul.findFiberByHostInstance||
kl,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.2.0-next-9e3b772b8-20220608"};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var wl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!wl.isDisabled&&wl.supportsFiber)try{kc=wl.inject(vl),lc=wl}catch(a){}}exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=tl;
exports.createPortal=function(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!ol(b))throw Error(p(200));return dl(a,b,null,c)};exports.createRoot=function(a,b){if(!ol(a))throw Error(p(299));var c=!1,d="",e=ll;null!==b&&void 0!==b&&(!0===b.unstable_strictMode&&(c=!0),void 0!==b.identifierPrefix&&(d=b.identifierPrefix),void 0!==b.onRecoverableError&&(e=b.onRecoverableError));b=cl(a,1,!1,null,null,c,!1,d,e);a[uf]=b.current;sf(8===a.nodeType?a.parentNode:a);return new ml(b)};
exports.findDOMNode=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(p(188));a=Object.keys(a).join(",");throw Error(p(268,a));}a=Zb(b);a=null===a?null:a.stateNode;return a};exports.flushSync=function(a){return Sk(a)};exports.hydrate=function(a,b,c){if(!pl(b))throw Error(p(200));return sl(null,a,b,!0,c)};
exports.hydrateRoot=function(a,b,c){if(!ol(a))throw Error(p(405));var d=null!=c&&c.hydratedSources||null,e=!1,f="",g=ll;null!==c&&void 0!==c&&(!0===c.unstable_strictMode&&(e=!0),void 0!==c.identifierPrefix&&(f=c.identifierPrefix),void 0!==c.onRecoverableError&&(g=c.onRecoverableError));b=fl(b,null,a,1,null!=c?c:null,e,!1,f,g);a[uf]=b.current;sf(a);if(d)for(a=0;a<d.length;a++)c=d[a],e=c._getVersion,e=e(c._source),null==b.mutableSourceEagerHydrationData?b.mutableSourceEagerHydrationData=[c,e]:b.mutableSourceEagerHydrationData.push(c,
e);return new nl(b)};exports.render=function(a,b,c){if(!pl(b))throw Error(p(200));return sl(null,a,b,!1,c)};exports.unmountComponentAtNode=function(a){if(!pl(a))throw Error(p(40));return a._reactRootContainer?(Sk(function(){sl(null,null,a,!1,function(){a._reactRootContainer=null;a[uf]=null})}),!0):!1};exports.unstable_batchedUpdates=Rk;
exports.unstable_renderSubtreeIntoContainer=function(a,b,c,d){if(!pl(c))throw Error(p(200));if(null==a||void 0===a._reactInternals)throw Error(p(38));return sl(a,b,c,!1,d)};exports.version="18.2.0-next-9e3b772b8-20220608";
    return exports;
})();

__modules['react/jsx-runtime'] = (() => {
    const exports = {};
    const module = {exports};
    /**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
'use strict';var f=require("react"),k=Symbol.for("react.element"),l=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,n=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p={key:!0,ref:!0,__self:!0,__source:!0};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return{$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n.current}}exports.Fragment=l;exports.jsx=q;exports.jsxs=q;
    return exports;
})();

__modules['templates.instruments.framework.components.colors~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Colors = void 0;
exports.Colors = {
    primary: '#5F46CF',
    primary_hover: '#432E8F',
    primary_active: '#32236C',
    secondary: '#FFFFFF',
    secondary_hover: '#E5E7EB',
    secondary_active: '#D1D5DB',
    spinner_foreground: '#9685E0', // primary at 70% lightness, equivalent to original at about 67% opacity
    spinner_background: '#EDEBFA', // primary at 95% lightness, equivalent to original at about 13% opacity
    disabled: '#E5E7EB',
    text_disabled: '#9CA3AF',
    text: '#111827',
    border: '#ccc',
    error: '#B91C1C',
};

    return exports;
})();

__modules['tslib'] = (() => {
    const exports = {};
    const module = {exports};
    /******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global global, define, Symbol, Reflect, Promise, SuppressedError */
var __extends;
var __assign;
var __rest;
var __decorate;
var __param;
var __esDecorate;
var __runInitializers;
var __propKey;
var __setFunctionName;
var __metadata;
var __awaiter;
var __generator;
var __exportStar;
var __values;
var __read;
var __spread;
var __spreadArrays;
var __spreadArray;
var __await;
var __asyncGenerator;
var __asyncDelegator;
var __asyncValues;
var __makeTemplateObject;
var __importStar;
var __importDefault;
var __classPrivateFieldGet;
var __classPrivateFieldSet;
var __classPrivateFieldIn;
var __createBinding;
var __addDisposableResource;
var __disposeResources;
(function (factory) {
    var root = typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : {};
    if (typeof define === "function" && define.amd) {
        define("tslib", ["exports"], function (exports) { factory(createExporter(root, createExporter(exports))); });
    }
    else if (typeof module === "object" && typeof module.exports === "object") {
        factory(createExporter(root, createExporter(module.exports)));
    }
    else {
        factory(createExporter(root));
    }
    function createExporter(exports, previous) {
        if (exports !== root) {
            if (typeof Object.create === "function") {
                Object.defineProperty(exports, "__esModule", { value: true });
            }
            else {
                exports.__esModule = true;
            }
        }
        return function (id, v) { return exports[id] = previous ? previous(id, v) : v; };
    }
})
(function (exporter) {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };

    __extends = function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };

    __assign = Object.assign || function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };

    __rest = function (s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    };

    __decorate = function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };

    __param = function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };

    __esDecorate = function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
        function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
        var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
        var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
        var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
        var _, done = false;
        for (var i = decorators.length - 1; i >= 0; i--) {
            var context = {};
            for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
            for (var p in contextIn.access) context.access[p] = contextIn.access[p];
            context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
            var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
            if (kind === "accessor") {
                if (result === void 0) continue;
                if (result === null || typeof result !== "object") throw new TypeError("Object expected");
                if (_ = accept(result.get)) descriptor.get = _;
                if (_ = accept(result.set)) descriptor.set = _;
                if (_ = accept(result.init)) initializers.unshift(_);
            }
            else if (_ = accept(result)) {
                if (kind === "field") initializers.unshift(_);
                else descriptor[key] = _;
            }
        }
        if (target) Object.defineProperty(target, contextIn.name, descriptor);
        done = true;
    };

    __runInitializers = function (thisArg, initializers, value) {
        var useValue = arguments.length > 2;
        for (var i = 0; i < initializers.length; i++) {
            value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
        }
        return useValue ? value : void 0;
    };

    __propKey = function (x) {
        return typeof x === "symbol" ? x : "".concat(x);
    };

    __setFunctionName = function (f, name, prefix) {
        if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
        return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
    };

    __metadata = function (metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    };

    __awaiter = function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };

    __generator = function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (g && (g = 0, op[0] && (_ = 0)), _) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };

    __exportStar = function(m, o) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
    };

    __createBinding = Object.create ? (function(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
            desc = { enumerable: true, get: function() { return m[k]; } };
        }
        Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    });

    __values = function (o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    };

    __read = function (o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    };

    /** @deprecated */
    __spread = function () {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    };

    /** @deprecated */
    __spreadArrays = function () {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    __spreadArray = function (to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    };

    __await = function (v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    };

    __asyncGenerator = function (thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);  }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    };

    __asyncDelegator = function (o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
    };

    __asyncValues = function (o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    };

    __makeTemplateObject = function (cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    var __setModuleDefault = Object.create ? (function(o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
        o["default"] = v;
    };

    __importStar = function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    };

    __importDefault = function (mod) {
        return (mod && mod.__esModule) ? mod : { "default": mod };
    };

    __classPrivateFieldGet = function (receiver, state, kind, f) {
        if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    };

    __classPrivateFieldSet = function (receiver, state, value, kind, f) {
        if (kind === "m") throw new TypeError("Private method is not writable");
        if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    };

    __classPrivateFieldIn = function (state, receiver) {
        if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
        return typeof state === "function" ? receiver === state : state.has(receiver);
    };

    __addDisposableResource = function (env, value, async) {
        if (value !== null && value !== void 0) {
            if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
            var dispose;
            if (async) {
                if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
                dispose = value[Symbol.asyncDispose];
            }
            if (dispose === void 0) {
                if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
                dispose = value[Symbol.dispose];
            }
            if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
            env.stack.push({ value: value, dispose: dispose, async: async });
        }
        else if (async) {
            env.stack.push({ async: true });
        }
        return value;
    };

    var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
        var e = new Error(message);
        return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
    };

    __disposeResources = function (env) {
        function fail(e) {
            env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while (env.stack.length) {
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
                }
                catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };

    exporter("__extends", __extends);
    exporter("__assign", __assign);
    exporter("__rest", __rest);
    exporter("__decorate", __decorate);
    exporter("__param", __param);
    exporter("__esDecorate", __esDecorate);
    exporter("__runInitializers", __runInitializers);
    exporter("__propKey", __propKey);
    exporter("__setFunctionName", __setFunctionName);
    exporter("__metadata", __metadata);
    exporter("__awaiter", __awaiter);
    exporter("__generator", __generator);
    exporter("__exportStar", __exportStar);
    exporter("__createBinding", __createBinding);
    exporter("__values", __values);
    exporter("__read", __read);
    exporter("__spread", __spread);
    exporter("__spreadArrays", __spreadArrays);
    exporter("__spreadArray", __spreadArray);
    exporter("__await", __await);
    exporter("__asyncGenerator", __asyncGenerator);
    exporter("__asyncDelegator", __asyncDelegator);
    exporter("__asyncValues", __asyncValues);
    exporter("__makeTemplateObject", __makeTemplateObject);
    exporter("__importStar", __importStar);
    exporter("__importDefault", __importDefault);
    exporter("__classPrivateFieldGet", __classPrivateFieldGet);
    exporter("__classPrivateFieldSet", __classPrivateFieldSet);
    exporter("__classPrivateFieldIn", __classPrivateFieldIn);
    exporter("__addDisposableResource", __addDisposableResource);
    exporter("__disposeResources", __disposeResources);
});
    return exports;
})();

__modules['@emotion/memoize'] = (() => {
    const exports = {};
    const module = {exports};
    'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function memoize(fn) {
  var cache = Object.create(null);
  return function (arg) {
    if (cache[arg] === undefined) cache[arg] = fn(arg);
    return cache[arg];
  };
}

exports["default"] = memoize;
    return exports;
})();

__modules['@emotion/is-prop-valid'] = (() => {
    const exports = {};
    const module = {exports};
    'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var memoize = require('@emotion/memoize');

function _interopDefault (e) { return e && e.__esModule ? e : { 'default': e }; }

var memoize__default = /*#__PURE__*/_interopDefault(memoize);

var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/; // https://esbench.com/bench/5bfee68a4cd7e6009ef61d23

var isPropValid = /* #__PURE__ */memoize__default["default"](function (prop) {
  return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111
  /* o */
  && prop.charCodeAt(1) === 110
  /* n */
  && prop.charCodeAt(2) < 91;
}
/* Z+1 */
);

exports["default"] = isPropValid;
    return exports;
})();

__modules['@emotion/unitless'] = (() => {
    const exports = {};
    const module = {exports};
    'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var unitlessKeys = {
  animationIterationCount: 1,
  aspectRatio: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  // SVG-related properties
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};

exports["default"] = unitlessKeys;

    return exports;
})();

__modules['shallowequal'] = (() => {
    const exports = {};
    const module = {exports};
    //

module.exports = function shallowEqual(objA, objB, compare, compareContext) {
    var ret = compare ? compare.call(compareContext, objA, objB) : void 0;

    if (ret !== void 0) {
        return !!ret;
    }

    if (objA === objB) {
        return true;
    }

    if (typeof objA !== "object" || !objA || typeof objB !== "object" || !objB) {
        return false;
    }

    var keysA = Object.keys(objA);
    var keysB = Object.keys(objB);

    if (keysA.length !== keysB.length) {
        return false;
    }

    var bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB);

    // Test for A's keys different from B.
    for (var idx = 0; idx < keysA.length; idx++) {
        var key = keysA[idx];

        if (!bHasOwnProperty(key)) {
        return false;
        }

        var valueA = objA[key];
        var valueB = objB[key];

        ret = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;

        if (ret === false || (ret === void 0 && valueA !== valueB)) {
        return false;
        }
    }

    return true;
};
    return exports;
})();

__modules['stylis'] = (() => {
    const exports = {};
    const module = {exports};
    (function(e,r){typeof exports==="object"&&typeof module!=="undefined"?r(exports):typeof define==="function"&&define.amd?define(["exports"],r):(e=e||self,r(e.stylis={}))})(this,(function(e){"use strict";var r="-ms-";var a="-moz-";var c="-webkit-";var n="comm";var t="rule";var s="decl";var i="@page";var u="@media";var o="@import";var l="@charset";var f="@viewport";var p="@supports";var h="@document";var v="@namespace";var b="@keyframes";var d="@font-face";var w="@counter-style";var m="@font-feature-values";var g="@layer";var k=Math.abs;var $=String.fromCharCode;var x=Object.assign;function E(e,r){return M(e,0)^45?(((r<<2^M(e,0))<<2^M(e,1))<<2^M(e,2))<<2^M(e,3):0}function y(e){return e.trim()}function T(e,r){return(e=r.exec(e))?e[0]:e}function A(e,r,a){return e.replace(r,a)}function O(e,r){return e.indexOf(r)}function M(e,r){return e.charCodeAt(r)|0}function C(e,r,a){return e.slice(r,a)}function R(e){return e.length}function S(e){return e.length}function z(e,r){return r.push(e),e}function N(e,r){return e.map(r).join("")}function P(e,r){return e.filter((function(e){return!T(e,r)}))}e.line=1;e.column=1;e.length=0;e.position=0;e.character=0;e.characters="";function j(r,a,c,n,t,s,i,u){return{value:r,root:a,parent:c,type:n,props:t,children:s,line:e.line,column:e.column,length:i,return:"",siblings:u}}function U(e,r){return x(j("",null,null,"",null,null,0,e.siblings),e,{length:-e.length},r)}function _(e){while(e.root)e=U(e.root,{children:[e]});z(e,e.siblings)}function F(){return e.character}function I(){e.character=e.position>0?M(e.characters,--e.position):0;if(e.column--,e.character===10)e.column=1,e.line--;return e.character}function L(){e.character=e.position<e.length?M(e.characters,e.position++):0;if(e.column++,e.character===10)e.column=1,e.line++;return e.character}function D(){return M(e.characters,e.position)}function Y(){return e.position}function K(r,a){return C(e.characters,r,a)}function V(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function W(r){return e.line=e.column=1,e.length=R(e.characters=r),e.position=0,[]}function B(r){return e.characters="",r}function G(r){return y(K(e.position-1,Q(r===91?r+2:r===40?r+1:r)))}function H(e){return B(q(W(e)))}function Z(r){while(e.character=D())if(e.character<33)L();else break;return V(r)>2||V(e.character)>3?"":" "}function q(r){while(L())switch(V(e.character)){case 0:z(ee(e.position-1),r);break;case 2:z(G(e.character),r);break;default:z($(e.character),r)}return r}function J(r,a){while(--a&&L())if(e.character<48||e.character>102||e.character>57&&e.character<65||e.character>70&&e.character<97)break;return K(r,Y()+(a<6&&D()==32&&L()==32))}function Q(r){while(L())switch(e.character){case r:return e.position;case 34:case 39:if(r!==34&&r!==39)Q(e.character);break;case 40:if(r===41)Q(r);break;case 92:L();break}return e.position}function X(r,a){while(L())if(r+e.character===47+10)break;else if(r+e.character===42+42&&D()===47)break;return"/*"+K(a,e.position-1)+"*"+$(r===47?r:L())}function ee(r){while(!V(D()))L();return K(r,e.position)}function re(e){return B(ae("",null,null,null,[""],e=W(e),0,[0],e))}function ae(e,r,a,c,n,t,s,i,u){var o=0;var l=0;var f=s;var p=0;var h=0;var v=0;var b=1;var d=1;var w=1;var m=0;var g="";var k=n;var x=t;var E=c;var y=g;while(d)switch(v=m,m=L()){case 40:if(v!=108&&M(y,f-1)==58){if(O(y+=A(G(m),"&","&\f"),"&\f")!=-1)w=-1;break}case 34:case 39:case 91:y+=G(m);break;case 9:case 10:case 13:case 32:y+=Z(v);break;case 92:y+=J(Y()-1,7);continue;case 47:switch(D()){case 42:case 47:z(ne(X(L(),Y()),r,a,u),u);break;default:y+="/"}break;case 123*b:i[o++]=R(y)*w;case 125*b:case 59:case 0:switch(m){case 0:case 125:d=0;case 59+l:if(w==-1)y=A(y,/\f/g,"");if(h>0&&R(y)-f)z(h>32?te(y+";",c,a,f-1,u):te(A(y," ","")+";",c,a,f-2,u),u);break;case 59:y+=";";default:z(E=ce(y,r,a,o,l,n,i,g,k=[],x=[],f,t),t);if(m===123)if(l===0)ae(y,r,E,E,k,t,f,i,x);else switch(p===99&&M(y,3)===110?100:p){case 100:case 108:case 109:case 115:ae(e,E,E,c&&z(ce(e,E,E,0,0,n,i,g,n,k=[],f,x),x),n,x,f,i,c?k:x);break;default:ae(y,E,E,E,[""],x,0,i,x)}}o=l=h=0,b=w=1,g=y="",f=s;break;case 58:f=1+R(y),h=v;default:if(b<1)if(m==123)--b;else if(m==125&&b++==0&&I()==125)continue;switch(y+=$(m),m*b){case 38:w=l>0?1:(y+="\f",-1);break;case 44:i[o++]=(R(y)-1)*w,w=1;break;case 64:if(D()===45)y+=G(L());p=D(),l=f=R(g=y+=ee(Y())),m++;break;case 45:if(v===45&&R(y)==2)b=0}}return t}function ce(e,r,a,c,n,s,i,u,o,l,f,p){var h=n-1;var v=n===0?s:[""];var b=S(v);for(var d=0,w=0,m=0;d<c;++d)for(var g=0,$=C(e,h+1,h=k(w=i[d])),x=e;g<b;++g)if(x=y(w>0?v[g]+" "+$:A($,/&\f/g,v[g])))o[m++]=x;return j(e,r,a,n===0?t:u,o,l,f,p)}function ne(e,r,a,c){return j(e,r,a,n,$(F()),C(e,2,-2),0,c)}function te(e,r,a,c,n){return j(e,r,a,s,C(e,0,c),C(e,c+1,-1),c,n)}function se(e,n,t){switch(E(e,n)){case 5103:return c+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return c+e+e;case 4789:return a+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return c+e+a+e+r+e+e;case 5936:switch(M(e,n+11)){case 114:return c+e+r+A(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return c+e+r+A(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return c+e+r+A(e,/[svh]\w+-[tblr]{2}/,"lr")+e}case 6828:case 4268:case 2903:return c+e+r+e+e;case 6165:return c+e+r+"flex-"+e+e;case 5187:return c+e+A(e,/(\w+).+(:[^]+)/,c+"box-$1$2"+r+"flex-$1$2")+e;case 5443:return c+e+r+"flex-item-"+A(e,/flex-|-self/g,"")+(!T(e,/flex-|baseline/)?r+"grid-row-"+A(e,/flex-|-self/g,""):"")+e;case 4675:return c+e+r+"flex-line-pack"+A(e,/align-content|flex-|-self/g,"")+e;case 5548:return c+e+r+A(e,"shrink","negative")+e;case 5292:return c+e+r+A(e,"basis","preferred-size")+e;case 6060:return c+"box-"+A(e,"-grow","")+c+e+r+A(e,"grow","positive")+e;case 4554:return c+A(e,/([^-])(transform)/g,"$1"+c+"$2")+e;case 6187:return A(A(A(e,/(zoom-|grab)/,c+"$1"),/(image-set)/,c+"$1"),e,"")+e;case 5495:case 3959:return A(e,/(image-set\([^]*)/,c+"$1"+"$`$1");case 4968:return A(A(e,/(.+:)(flex-)?(.*)/,c+"box-pack:$3"+r+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+c+e+e;case 4200:if(!T(e,/flex-|baseline/))return r+"grid-column-align"+C(e,n)+e;break;case 2592:case 3360:return r+A(e,"template-","")+e;case 4384:case 3616:if(t&&t.some((function(e,r){return n=r,T(e.props,/grid-\w+-end/)}))){return~O(e+(t=t[n].value),"span")?e:r+A(e,"-start","")+e+r+"grid-row-span:"+(~O(t,"span")?T(t,/\d+/):+T(t,/\d+/)-+T(e,/\d+/))+";"}return r+A(e,"-start","")+e;case 4896:case 4128:return t&&t.some((function(e){return T(e.props,/grid-\w+-start/)}))?e:r+A(A(e,"-end","-span"),"span ","")+e;case 4095:case 3583:case 4068:case 2532:return A(e,/(.+)-inline(.+)/,c+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(R(e)-1-n>6)switch(M(e,n+1)){case 109:if(M(e,n+4)!==45)break;case 102:return A(e,/(.+:)(.+)-([^]+)/,"$1"+c+"$2-$3"+"$1"+a+(M(e,n+3)==108?"$3":"$2-$3"))+e;case 115:return~O(e,"stretch")?se(A(e,"stretch","fill-available"),n,t)+e:e}break;case 5152:case 5920:return A(e,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,(function(a,c,n,t,s,i,u){return r+c+":"+n+u+(t?r+c+"-span:"+(s?i:+i-+n)+u:"")+e}));case 4949:if(M(e,n+6)===121)return A(e,":",":"+c)+e;break;case 6444:switch(M(e,M(e,14)===45?18:11)){case 120:return A(e,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+c+(M(e,14)===45?"inline-":"")+"box$3"+"$1"+c+"$2$3"+"$1"+r+"$2box$3")+e;case 100:return A(e,":",":"+r)+e}break;case 5719:case 2647:case 2135:case 3927:case 2391:return A(e,"scroll-","scroll-snap-")+e}return e}function ie(e,r){var a="";for(var c=0;c<e.length;c++)a+=r(e[c],c,e,r)||"";return a}function ue(e,r,a,c){switch(e.type){case g:if(e.children.length)break;case o:case s:return e.return=e.return||e.value;case n:return"";case b:return e.return=e.value+"{"+ie(e.children,c)+"}";case t:if(!R(e.value=e.props.join(",")))return""}return R(a=ie(e.children,c))?e.return=e.value+"{"+a+"}":""}function oe(e){var r=S(e);return function(a,c,n,t){var s="";for(var i=0;i<r;i++)s+=e[i](a,c,n,t)||"";return s}}function le(e){return function(r){if(!r.root)if(r=r.return)e(r)}}function fe(e,n,i,u){if(e.length>-1)if(!e.return)switch(e.type){case s:e.return=se(e.value,e.length,i);return;case b:return ie([U(e,{value:A(e.value,"@","@"+c)})],u);case t:if(e.length)return N(i=e.props,(function(n){switch(T(n,u=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":_(U(e,{props:[A(n,/:(read-\w+)/,":"+a+"$1")]}));_(U(e,{props:[n]}));x(e,{props:P(i,u)});break;case"::placeholder":_(U(e,{props:[A(n,/:(plac\w+)/,":"+c+"input-$1")]}));_(U(e,{props:[A(n,/:(plac\w+)/,":"+a+"$1")]}));_(U(e,{props:[A(n,/:(plac\w+)/,r+"input-$1")]}));_(U(e,{props:[n]}));x(e,{props:P(i,u)});break}return""}))}}function pe(e){switch(e.type){case t:e.props=e.props.map((function(r){return N(H(r),(function(r,a,c){switch(M(r,0)){case 12:return C(r,1,R(r));case 0:case 40:case 43:case 62:case 126:return r;case 58:if(c[++a]==="global")c[a]="",c[++a]="\f"+C(c[a],a=1,-1);case 32:return a===1?"":r;default:switch(a){case 0:e=r;return S(c)>1?"":r;case a=S(c)-1:case 2:return a===2?r+e+e:r+e;default:return r}}}))}))}}e.CHARSET=l;e.COMMENT=n;e.COUNTER_STYLE=w;e.DECLARATION=s;e.DOCUMENT=h;e.FONT_FACE=d;e.FONT_FEATURE_VALUES=m;e.IMPORT=o;e.KEYFRAMES=b;e.LAYER=g;e.MEDIA=u;e.MOZ=a;e.MS=r;e.NAMESPACE=v;e.PAGE=i;e.RULESET=t;e.SUPPORTS=p;e.VIEWPORT=f;e.WEBKIT=c;e.abs=k;e.alloc=W;e.append=z;e.assign=x;e.caret=Y;e.char=F;e.charat=M;e.combine=N;e.comment=ne;e.commenter=X;e.compile=re;e.copy=U;e.dealloc=B;e.declaration=te;e.delimit=G;e.delimiter=Q;e.escaping=J;e.filter=P;e.from=$;e.hash=E;e.identifier=ee;e.indexof=O;e.lift=_;e.match=T;e.middleware=oe;e.namespace=pe;e.next=L;e.node=j;e.parse=ae;e.peek=D;e.prefix=se;e.prefixer=fe;e.prev=I;e.replace=A;e.ruleset=ce;e.rulesheet=le;e.serialize=ie;e.sizeof=S;e.slice=K;e.stringify=ue;e.strlen=R;e.substr=C;e.token=V;e.tokenize=H;e.tokenizer=q;e.trim=y;e.whitespace=Z;Object.defineProperty(e,"__esModule",{value:true})}));

    return exports;
})();

__modules['styled-components'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("tslib"),t=require("@emotion/is-prop-valid"),n=require("react"),r=require("shallowequal"),o=require("stylis"),s=require("@emotion/unitless");function i(e){return e&&e.__esModule?e:{default:e}}function a(e){if(e&&e.__esModule)return e;var t=Object.create(null);return e&&Object.keys(e).forEach(function(n){if("default"!==n){var r=Object.getOwnPropertyDescriptor(e,n);Object.defineProperty(t,n,r.get?r:{enumerable:!0,get:function(){return e[n]}})}}),t.default=e,Object.freeze(t)}var c=/*#__PURE__*/i(t),l=/*#__PURE__*/i(n),u=/*#__PURE__*/i(r),p=/*#__PURE__*/a(o),d=/*#__PURE__*/i(s),h="undefined"!=typeof process&&void 0!==process.env&&(process.env.REACT_APP_SC_ATTR||process.env.SC_ATTR)||"data-styled",f="undefined"!=typeof window&&"HTMLElement"in window,y=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==process.env&&void 0!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&""!==process.env.REACT_APP_SC_DISABLE_SPEEDY?"false"!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&process.env.REACT_APP_SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==process.env&&void 0!==process.env.SC_DISABLE_SPEEDY&&""!==process.env.SC_DISABLE_SPEEDY?"false"!==process.env.SC_DISABLE_SPEEDY&&process.env.SC_DISABLE_SPEEDY:"production"!==process.env.NODE_ENV),m={},v=/invalid hook call/i,g=new Set,S=function(t,r){if("production"!==process.env.NODE_ENV){var o=r?' with the id of "'.concat(r,'"'):"",s="The component ".concat(t).concat(o," has been created dynamically.\n")+"You may see this warning because you've called styled inside another component.\nTo resolve this only create new StyledComponents outside of any render method and function component.",i=console.error;try{var a=!0;console.error=function(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];v.test(t)?(a=!1,g.delete(s)):i.apply(void 0,e.__spreadArray([t],n,!1))},n.useRef(),a&&!g.has(s)&&(console.warn(s),g.add(s))}catch(e){v.test(e.message)&&g.delete(s)}finally{console.error=i}}},w=Object.freeze([]),_=Object.freeze({});function b(e,t,n){return void 0===n&&(n=_),e.theme!==n.theme&&e.theme||t||n.theme}var E=new Set(["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","track","u","ul","use","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"]),N=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,P=/(^-|-$)/g;function C(e){return e.replace(N,"-").replace(P,"")}var A=/(a)(d)/gi,I=function(e){return String.fromCharCode(e+(e>25?39:97))};function O(e){var t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=I(t%52)+n;return(I(t%52)+n).replace(A,"$1-$2")}var x,D=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},T=function(e){return D(5381,e)};function R(e){return O(T(e)>>>0)}function j(e){return"production"!==process.env.NODE_ENV&&"string"==typeof e&&e||e.displayName||e.name||"Component"}function k(e){return"string"==typeof e&&("production"===process.env.NODE_ENV||e.charAt(0)===e.charAt(0).toLowerCase())}var V="function"==typeof Symbol&&Symbol.for,M=V?Symbol.for("react.memo"):60115,F=V?Symbol.for("react.forward_ref"):60112,z={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},$={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},B={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},L=((x={})[F]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},x[M]=B,x);function G(e){return("type"in(t=e)&&t.type.$$typeof)===M?B:"$$typeof"in e?L[e.$$typeof]:z;var t}var q=Object.defineProperty,Y=Object.getOwnPropertyNames,W=Object.getOwnPropertySymbols,H=Object.getOwnPropertyDescriptor,U=Object.getPrototypeOf,J=Object.prototype;function X(e,t,n){if("string"!=typeof t){if(J){var r=U(t);r&&r!==J&&X(e,r,n)}var o=Y(t);W&&(o=o.concat(W(t)));for(var s=G(e),i=G(t),a=0;a<o.length;++a){var c=o[a];if(!(c in $||n&&n[c]||i&&c in i||s&&c in s)){var l=H(t,c);try{q(e,c,l)}catch(e){}}}}return e}function Z(e){return"function"==typeof e}function K(e){return"object"==typeof e&&"styledComponentId"in e}function Q(e,t){return e&&t?"".concat(e," ").concat(t):e||t||""}function ee(e,t){if(0===e.length)return"";for(var n=e[0],r=1;r<e.length;r++)n+=t?t+e[r]:e[r];return n}function te(e){return null!==e&&"object"==typeof e&&e.constructor.name===Object.name&&!("props"in e&&e.$$typeof)}function ne(e,t,n){if(void 0===n&&(n=!1),!n&&!te(e)&&!Array.isArray(e))return t;if(Array.isArray(t))for(var r=0;r<t.length;r++)e[r]=ne(e[r],t[r]);else if(te(t))for(var r in t)e[r]=ne(e[r],t[r]);return e}function re(e,t){Object.defineProperty(e,"toString",{value:t})}var oe="production"!==process.env.NODE_ENV?{1:"Cannot create styled-component for component: %s.\n\n",2:"Can't collect styles once you've consumed a `ServerStyleSheet`'s styles! `ServerStyleSheet` is a one off instance for each server-side render cycle.\n\n- Are you trying to reuse it across renders?\n- Are you accidentally calling collectStyles twice?\n\n",3:"Streaming SSR is only supported in a Node.js environment; Please do not try to call this method in the browser.\n\n",4:"The `StyleSheetManager` expects a valid target or sheet prop!\n\n- Does this error occur on the client and is your target falsy?\n- Does this error occur on the server and is the sheet falsy?\n\n",5:"The clone method cannot be used on the client!\n\n- Are you running in a client-like environment on the server?\n- Are you trying to run SSR on the client?\n\n",6:"Trying to insert a new style tag, but the given Node is unmounted!\n\n- Are you using a custom target that isn't mounted?\n- Does your document not have a valid head element?\n- Have you accidentally removed a style tag manually?\n\n",7:'ThemeProvider: Please return an object from your "theme" prop function, e.g.\n\n```js\ntheme={() => ({})}\n```\n\n',8:'ThemeProvider: Please make your "theme" prop an object.\n\n',9:"Missing document `<head>`\n\n",10:"Cannot find a StyleSheet instance. Usually this happens if there are multiple copies of styled-components loaded at once. Check out this issue for how to troubleshoot and fix the common cases where this situation can happen: https://github.com/styled-components/styled-components/issues/1941#issuecomment-417862021\n\n",11:"_This error was replaced with a dev-time warning, it will be deleted for v4 final._ [createGlobalStyle] received children which will not be rendered. Please use the component without passing children elements.\n\n",12:"It seems you are interpolating a keyframe declaration (%s) into an untagged string. This was supported in styled-components v3, but is not longer supported in v4 as keyframes are now injected on-demand. Please wrap your string in the css\\`\\` helper which ensures the styles are injected correctly. See https://www.styled-components.com/docs/api#css\n\n",13:"%s is not a styled component and cannot be referred to via component selector. See https://www.styled-components.com/docs/advanced#referring-to-other-components for more details.\n\n",14:'ThemeProvider: "theme" prop is required.\n\n',15:"A stylis plugin has been supplied that is not named. We need a name for each plugin to be able to prevent styling collisions between different stylis configurations within the same app. Before you pass your plugin to `<StyleSheetManager stylisPlugins={[]}>`, please make sure each plugin is uniquely-named, e.g.\n\n```js\nObject.defineProperty(importedPlugin, 'name', { value: 'some-unique-name' });\n```\n\n",16:"Reached the limit of how many styled components may be created at group %s.\nYou may only create up to 1,073,741,824 components. If you're creating components dynamically,\nas for instance in your render method then you may be running into this limitation.\n\n",17:"CSSStyleSheet could not be found on HTMLStyleElement.\nHas styled-components' style tag been unmounted or altered by another script?\n",18:"ThemeProvider: Please make sure your useTheme hook is within a `<ThemeProvider>`"}:{};function se(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];for(var n=e[0],r=[],o=1,s=e.length;o<s;o+=1)r.push(e[o]);return r.forEach(function(e){n=n.replace(/%[a-z]/,e)}),n}function ie(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];return"production"===process.env.NODE_ENV?new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(t," for more information.").concat(n.length>0?" Args: ".concat(n.join(", ")):"")):new Error(se.apply(void 0,e.__spreadArray([oe[t]],n,!1)).trim())}var ae=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}return e.prototype.indexOfGroup=function(e){for(var t=0,n=0;n<e;n++)t+=this.groupSizes[n];return t},e.prototype.insertRules=function(e,t){if(e>=this.groupSizes.length){for(var n=this.groupSizes,r=n.length,o=r;e>=o;)if((o<<=1)<0)throw ie(16,"".concat(e));this.groupSizes=new Uint32Array(o),this.groupSizes.set(n),this.length=o;for(var s=r;s<o;s++)this.groupSizes[s]=0}for(var i=this.indexOfGroup(e+1),a=(s=0,t.length);s<a;s++)this.tag.insertRule(i,t[s])&&(this.groupSizes[e]++,i++)},e.prototype.clearGroup=function(e){if(e<this.length){var t=this.groupSizes[e],n=this.indexOfGroup(e),r=n+t;this.groupSizes[e]=0;for(var o=n;o<r;o++)this.tag.deleteRule(n)}},e.prototype.getGroup=function(e){var t="";if(e>=this.length||0===this.groupSizes[e])return t;for(var n=this.groupSizes[e],r=this.indexOfGroup(e),o=r+n,s=r;s<o;s++)t+="".concat(this.tag.getRule(s)).concat("/*!sc*/\n");return t},e}(),ce=new Map,le=new Map,ue=1,pe=function(e){if(ce.has(e))return ce.get(e);for(;le.has(ue);)ue++;var t=ue++;if("production"!==process.env.NODE_ENV&&((0|t)<0||t>1073741824))throw ie(16,"".concat(t));return ce.set(e,t),le.set(t,e),t},de=function(e,t){ce.set(e,t),le.set(t,e)},he="style[".concat(h,"][").concat("data-styled-version",'="').concat("6.0.8",'"]'),fe=new RegExp("^".concat(h,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),ye=function(e,t,n){for(var r,o=n.split(","),s=0,i=o.length;s<i;s++)(r=o[s])&&e.registerName(t,r)},me=function(e,t){for(var n,r=(null!==(n=t.textContent)&&void 0!==n?n:"").split("/*!sc*/\n"),o=[],s=0,i=r.length;s<i;s++){var a=r[s].trim();if(a){var c=a.match(fe);if(c){var l=0|parseInt(c[1],10),u=c[2];0!==l&&(de(u,l),ye(e,u,c[3]),e.getTag().insertRules(l,o)),o.length=0}else o.push(a)}}};function ve(){return"undefined"!=typeof __webpack_nonce__?__webpack_nonce__:null}var ge=function(e){var t=document.head,n=e||t,r=document.createElement("style"),o=function(e){var t=Array.from(e.querySelectorAll("style[".concat(h,"]")));return t[t.length-1]}(n),s=void 0!==o?o.nextSibling:null;r.setAttribute(h,"active"),r.setAttribute("data-styled-version","6.0.8");var i=ve();return i&&r.setAttribute("nonce",i),n.insertBefore(r,s),r},Se=function(){function e(e){this.element=ge(e),this.element.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var t=document.styleSheets,n=0,r=t.length;n<r;n++){var o=t[n];if(o.ownerNode===e)return o}throw ie(17)}(this.element),this.length=0}return e.prototype.insertRule=function(e,t){try{return this.sheet.insertRule(t,e),this.length++,!0}catch(e){return!1}},e.prototype.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},e.prototype.getRule=function(e){var t=this.sheet.cssRules[e];return t&&t.cssText?t.cssText:""},e}(),we=function(){function e(e){this.element=ge(e),this.nodes=this.element.childNodes,this.length=0}return e.prototype.insertRule=function(e,t){if(e<=this.length&&e>=0){var n=document.createTextNode(t);return this.element.insertBefore(n,this.nodes[e]||null),this.length++,!0}return!1},e.prototype.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},e.prototype.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),_e=function(){function e(e){this.rules=[],this.length=0}return e.prototype.insertRule=function(e,t){return e<=this.length&&(this.rules.splice(e,0,t),this.length++,!0)},e.prototype.deleteRule=function(e){this.rules.splice(e,1),this.length--},e.prototype.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),be=f,Ee={isServer:!f,useCSSOMInjection:!y},Ne=function(){function t(t,n,r){void 0===t&&(t=_),void 0===n&&(n={});var o=this;this.options=e.__assign(e.__assign({},Ee),t),this.gs=n,this.names=new Map(r),this.server=!!t.isServer,!this.server&&f&&be&&(be=!1,function(e){for(var t=document.querySelectorAll(he),n=0,r=t.length;n<r;n++){var o=t[n];o&&"active"!==o.getAttribute(h)&&(me(e,o),o.parentNode&&o.parentNode.removeChild(o))}}(this)),re(this,function(){return function(e){for(var t=e.getTag(),n=t.length,r="",o=function(n){var o=function(e){return le.get(e)}(n);if(void 0===o)return"continue";var s=e.names.get(o),i=t.getGroup(n);if(void 0===s||0===i.length)return"continue";var a="".concat(h,".g").concat(n,'[id="').concat(o,'"]'),c="";void 0!==s&&s.forEach(function(e){e.length>0&&(c+="".concat(e,","))}),r+="".concat(i).concat(a,'{content:"').concat(c,'"}').concat("/*!sc*/\n")},s=0;s<n;s++)o(s);return r}(o)})}return t.registerId=function(e){return pe(e)},t.prototype.reconstructWithOptions=function(n,r){return void 0===r&&(r=!0),new t(e.__assign(e.__assign({},this.options),n),this.gs,r&&this.names||void 0)},t.prototype.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},t.prototype.getTag=function(){return this.tag||(this.tag=(e=function(e){var t=e.useCSSOMInjection,n=e.target;return e.isServer?new _e(n):t?new Se(n):new we(n)}(this.options),new ae(e)));var e},t.prototype.hasNameForId=function(e,t){return this.names.has(e)&&this.names.get(e).has(t)},t.prototype.registerName=function(e,t){if(pe(e),this.names.has(e))this.names.get(e).add(t);else{var n=new Set;n.add(t),this.names.set(e,n)}},t.prototype.insertRules=function(e,t,n){this.registerName(e,t),this.getTag().insertRules(pe(e),n)},t.prototype.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},t.prototype.clearRules=function(e){this.getTag().clearGroup(pe(e)),this.clearNames(e)},t.prototype.clearTag=function(){this.tag=void 0},t}(),Pe=/&/g,Ce=/^\s*\/\/.*$/gm;function Ae(e,t){return e.map(function(e){return"rule"===e.type&&(e.value="".concat(t," ").concat(e.value),e.value=e.value.replaceAll(",",",".concat(t," ")),e.props=e.props.map(function(e){return"".concat(t," ").concat(e)})),Array.isArray(e.children)&&"@keyframes"!==e.type&&(e.children=Ae(e.children,t)),e})}function Ie(e){var t,n,r,o=void 0===e?_:e,s=o.options,i=void 0===s?_:s,a=o.plugins,c=void 0===a?w:a,l=function(e,r,o){return o===n||o.startsWith(n)&&o.endsWith(n)&&o.replaceAll(n,"").length>0?".".concat(t):e},u=c.slice();u.push(function(e){e.type===p.RULESET&&e.value.includes("&")&&(e.props[0]=e.props[0].replace(Pe,n).replace(r,l))}),i.prefix&&u.push(p.prefixer),u.push(p.stringify);var d=function(e,o,s,a){void 0===o&&(o=""),void 0===s&&(s=""),void 0===a&&(a="&"),t=a,n=o,r=new RegExp("\\".concat(n,"\\b"),"g");var c=e.replace(Ce,""),l=p.compile(s||o?"".concat(s," ").concat(o," { ").concat(c," }"):c);i.namespace&&(l=Ae(l,i.namespace));var d=[];return p.serialize(l,p.middleware(u.concat(p.rulesheet(function(e){return d.push(e)})))),d};return d.hash=c.length?c.reduce(function(e,t){return t.name||ie(15),D(e,t.name)},5381).toString():"",d}var Oe=new Ne,xe=Ie(),De=l.default.createContext({shouldForwardProp:void 0,styleSheet:Oe,stylis:xe}),Te=De.Consumer,Re=l.default.createContext(void 0);function je(){return n.useContext(De)}function ke(e){var t=n.useState(e.stylisPlugins),r=t[0],o=t[1],s=je().styleSheet,i=n.useMemo(function(){var t=s;return e.sheet?t=e.sheet:e.target&&(t=t.reconstructWithOptions({target:e.target},!1)),e.disableCSSOMInjection&&(t=t.reconstructWithOptions({useCSSOMInjection:!1})),t},[e.disableCSSOMInjection,e.sheet,e.target,s]),a=n.useMemo(function(){return Ie({options:{namespace:e.namespace,prefix:e.enableVendorPrefixes},plugins:r})},[e.enableVendorPrefixes,e.namespace,r]);n.useEffect(function(){u.default(r,e.stylisPlugins)||o(e.stylisPlugins)},[e.stylisPlugins]);var c=n.useMemo(function(){return{shouldForwardProp:e.shouldForwardProp,styleSheet:i,stylis:a}},[e.shouldForwardProp,i,a]);return l.default.createElement(De.Provider,{value:c},l.default.createElement(Re.Provider,{value:a},e.children))}var Ve=function(){function e(e,t){var n=this;this.inject=function(e,t){void 0===t&&(t=xe);var r=n.name+t.hash;e.hasNameForId(n.id,r)||e.insertRules(n.id,r,t(n.rules,r,"@keyframes"))},this.name=e,this.id="sc-keyframes-".concat(e),this.rules=t,re(this,function(){throw ie(12,String(n.name))})}return e.prototype.getName=function(e){return void 0===e&&(e=xe),this.name+e.hash},e}(),Me=function(e){return e>="A"&&e<="Z"};function Fe(e){for(var t="",n=0;n<e.length;n++){var r=e[n];if(1===n&&"-"===r&&"-"===e[0])return e;Me(r)?t+="-"+r.toLowerCase():t+=r}return t.startsWith("ms-")?"-"+t:t}var ze=function(e){return null==e||!1===e||""===e},$e=function(t){var n,r,o=[];for(var s in t){var i=t[s];t.hasOwnProperty(s)&&!ze(i)&&(Array.isArray(i)&&i.isCss||Z(i)?o.push("".concat(Fe(s),":"),i,";"):te(i)?o.push.apply(o,e.__spreadArray(e.__spreadArray(["".concat(s," {")],$e(i),!1),["}"],!1)):o.push("".concat(Fe(s),": ").concat((n=s,null==(r=i)||"boolean"==typeof r||""===r?"":"number"!=typeof r||0===r||n in d.default||n.startsWith("--")?String(r).trim():"".concat(r,"px")),";")))}return o};function Be(e,t,n,r){if(ze(e))return[];if(K(e))return[".".concat(e.styledComponentId)];if(Z(e)){if(!Z(s=e)||s.prototype&&s.prototype.isReactComponent||!t)return[e];var o=e(t);return"production"===process.env.NODE_ENV||"object"!=typeof o||Array.isArray(o)||o instanceof Ve||te(o)||null===o||console.error("".concat(j(e)," is not a styled component and cannot be referred to via component selector. See https://www.styled-components.com/docs/advanced#referring-to-other-components for more details.")),Be(o,t,n,r)}var s;return e instanceof Ve?n?(e.inject(n,r),[e.getName(r)]):[e]:te(e)?$e(e):Array.isArray(e)?Array.prototype.concat.apply(w,e.map(function(e){return Be(e,t,n,r)})):[e.toString()]}function Le(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(Z(n)&&!K(n))return!1}return!0}var Ge=T("6.0.8"),qe=function(){function e(e,t,n){this.rules=e,this.staticRulesId="",this.isStatic="production"===process.env.NODE_ENV&&(void 0===n||n.isStatic)&&Le(e),this.componentId=t,this.baseHash=D(Ge,t),this.baseStyle=n,Ne.registerId(t)}return e.prototype.generateAndInjectStyles=function(e,t,n){var r=this.baseStyle?this.baseStyle.generateAndInjectStyles(e,t,n):"";if(this.isStatic&&!n.hash)if(this.staticRulesId&&t.hasNameForId(this.componentId,this.staticRulesId))r=Q(r,this.staticRulesId);else{var o=ee(Be(this.rules,e,t,n)),s=O(D(this.baseHash,o)>>>0);if(!t.hasNameForId(this.componentId,s)){var i=n(o,".".concat(s),void 0,this.componentId);t.insertRules(this.componentId,s,i)}r=Q(r,s),this.staticRulesId=s}else{for(var a=D(this.baseHash,n.hash),c="",l=0;l<this.rules.length;l++){var u=this.rules[l];if("string"==typeof u)c+=u,"production"!==process.env.NODE_ENV&&(a=D(a,u));else if(u){var p=ee(Be(u,e,t,n));a=D(a,p+l),c+=p}}if(c){var d=O(a>>>0);t.hasNameForId(this.componentId,d)||t.insertRules(this.componentId,d,n(c,".".concat(d),void 0,this.componentId)),r=Q(r,d)}}return r},e}(),Ye=l.default.createContext(void 0),We=Ye.Consumer,He={},Ue=new Set;function Je(t,r,o){var s=K(t),i=t,a=!k(t),u=r.attrs,p=void 0===u?w:u,d=r.componentId,h=void 0===d?function(e,t){var n="string"!=typeof e?"sc":C(e);He[n]=(He[n]||0)+1;var r="".concat(n,"-").concat(R("6.0.8"+n+He[n]));return t?"".concat(t,"-").concat(r):r}(r.displayName,r.parentComponentId):d,f=r.displayName,y=void 0===f?function(e){return k(e)?"styled.".concat(e):"Styled(".concat(j(e),")")}(t):f,m=r.displayName&&r.componentId?"".concat(C(r.displayName),"-").concat(r.componentId):r.componentId||h,v=s&&i.attrs?i.attrs.concat(p).filter(Boolean):p,g=r.shouldForwardProp;if(s&&i.shouldForwardProp){var N=i.shouldForwardProp;if(r.shouldForwardProp){var P=r.shouldForwardProp;g=function(e,t){return N(e,t)&&P(e,t)}}else g=N}var A=new qe(o,m,s?i.componentStyle:void 0);function I(t,r){return function(t,r,o){var s=t.attrs,i=t.componentStyle,a=t.defaultProps,u=t.foldedComponentIds,p=t.styledComponentId,d=t.target,h=l.default.useContext(Ye),f=je(),y=t.shouldForwardProp||f.shouldForwardProp;"production"!==process.env.NODE_ENV&&n.useDebugValue(p);var m=function(t,n,r){for(var o,s=e.__assign(e.__assign({},n),{className:void 0,theme:r}),i=0;i<t.length;i+=1){var a=Z(o=t[i])?o(s):o;for(var c in a)s[c]="className"===c?Q(s[c],a[c]):"style"===c?e.__assign(e.__assign({},s[c]),a[c]):a[c]}return n.className&&(s.className=Q(s.className,n.className)),s}(s,r,b(r,h,a)||_),v=m.as||d,g={};for(var S in m)void 0===m[S]||"$"===S[0]||"as"===S||"theme"===S||("forwardedAs"===S?g.as=m.forwardedAs:y&&!y(S,v)||(g[S]=m[S],y||"development"!==process.env.NODE_ENV||c.default(S)||Ue.has(S)||!E.has(v)||(Ue.add(S),console.warn('styled-components: it looks like an unknown prop "'.concat(S,'" is being sent through to the DOM, which will likely trigger a React console error. If you would like automatic filtering of unknown props, you can opt-into that behavior via `<StyleSheetManager shouldForwardProp={...}>` (connect an API like `@emotion/is-prop-valid`) or consider using transient props (`$` prefix for automatic filtering.)')))));var w=function(e,t){var r=je(),o=e.generateAndInjectStyles(t,r.styleSheet,r.stylis);return"production"!==process.env.NODE_ENV&&n.useDebugValue(o),o}(i,m);"production"!==process.env.NODE_ENV&&t.warnTooManyClasses&&t.warnTooManyClasses(w);var N=Q(u,p);return w&&(N+=" "+w),m.className&&(N+=" "+m.className),g[k(v)&&!E.has(v)?"class":"className"]=N,g.ref=o,n.createElement(v,g)}(O,t,r)}"production"!==process.env.NODE_ENV&&(I.displayName=y);var O=l.default.forwardRef(I);return O.attrs=v,O.componentStyle=A,O.shouldForwardProp=g,"production"!==process.env.NODE_ENV&&(O.displayName=y),O.foldedComponentIds=s?Q(i.foldedComponentIds,i.styledComponentId):"",O.styledComponentId=m,O.target=s?i.target:t,Object.defineProperty(O,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(e){this._foldedDefaultProps=s?function(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];for(var r=0,o=t;r<o.length;r++)ne(e,o[r],!0);return e}({},i.defaultProps,e):e}}),"production"!==process.env.NODE_ENV&&(S(y,m),O.warnTooManyClasses=function(e,t){var n={},r=!1;return function(o){if(!r&&(n[o]=!0,Object.keys(n).length>=200)){var s=t?' with the id of "'.concat(t,'"'):"";console.warn("Over ".concat(200," classes were generated for component ").concat(e).concat(s,".\n")+"Consider using the attrs method, together with a style object for frequently changed styles.\nExample:\n  const Component = styled.div.attrs(props => ({\n    style: {\n      background: props.background,\n    },\n  }))`width: 100%;`\n\n  <Component />"),r=!0,n={}}}}(y,m)),re(O,function(){return".".concat(O.styledComponentId)}),a&&X(O,t,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),O}function Xe(e,t){for(var n=[e[0]],r=0,o=t.length;r<o;r+=1)n.push(t[r],e[r+1]);return n}var Ze=function(e){return Object.assign(e,{isCss:!0})};function Ke(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];if(Z(t)||te(t)){var o=t;return Ze(Be(Xe(w,e.__spreadArray([o],n,!0))))}var s=t;return 0===n.length&&1===s.length&&"string"==typeof s[0]?Be(s):Ze(Be(Xe(s,n)))}function Qe(t,n,r){if(void 0===r&&(r=_),!n)throw ie(1,n);var o=function(o){for(var s=[],i=1;i<arguments.length;i++)s[i-1]=arguments[i];return t(n,r,Ke.apply(void 0,e.__spreadArray([o],s,!1)))};return o.attrs=function(o){return Qe(t,n,e.__assign(e.__assign({},r),{attrs:Array.prototype.concat(r.attrs,o).filter(Boolean)}))},o.withConfig=function(o){return Qe(t,n,e.__assign(e.__assign({},r),o))},o}var et=function(e){return Qe(Je,e)},tt=et;E.forEach(function(e){tt[e]=et(e)});var nt=function(){function e(e,t){this.rules=e,this.componentId=t,this.isStatic=Le(e),Ne.registerId(this.componentId+1)}return e.prototype.createStyles=function(e,t,n,r){var o=r(ee(Be(this.rules,t,n,r)),""),s=this.componentId+e;n.insertRules(s,s,o)},e.prototype.removeStyles=function(e,t){t.clearRules(this.componentId+e)},e.prototype.renderStyles=function(e,t,n,r){e>2&&Ne.registerId(this.componentId+e),this.removeStyles(e,n),this.createStyles(e,t,n,r)},e}(),rt=function(){function t(){var t=this;this._emitSheetCSS=function(){var e=t.instance.toString(),n=ve(),r=ee([n&&'nonce="'.concat(n,'"'),"".concat(h,'="true"'),"".concat("data-styled-version",'="').concat("6.0.8",'"')].filter(Boolean)," ");return"<style ".concat(r,">").concat(e,"</style>")},this.getStyleTags=function(){if(t.sealed)throw ie(2);return t._emitSheetCSS()},this.getStyleElement=function(){var n;if(t.sealed)throw ie(2);var r=((n={})[h]="",n["data-styled-version"]="6.0.8",n.dangerouslySetInnerHTML={__html:t.instance.toString()},n),o=ve();return o&&(r.nonce=o),[l.default.createElement("style",e.__assign({},r,{key:"sc-0-0"}))]},this.seal=function(){t.sealed=!0},this.instance=new Ne({isServer:!0}),this.sealed=!1}return t.prototype.collectStyles=function(e){if(this.sealed)throw ie(2);return l.default.createElement(ke,{sheet:this.instance},e)},t.prototype.interleaveWithNodeStream=function(e){throw ie(3)},t}(),ot={StyleSheet:Ne,mainSheet:Oe};"production"!==process.env.NODE_ENV&&"undefined"!=typeof navigator&&"ReactNative"===navigator.product&&console.warn("It looks like you've imported 'styled-components' on React Native.\nPerhaps you're looking to import 'styled-components/native'?\nRead more about this at https://www.styled-components.com/docs/basics#react-native");var st="__sc-".concat(h,"__");"production"!==process.env.NODE_ENV&&"test"!==process.env.NODE_ENV&&"undefined"!=typeof window&&(window[st]||(window[st]=0),1===window[st]&&console.warn("It looks like there are several instances of 'styled-components' initialized in this application. This may cause dynamic styles to not render properly, errors during the rehydration process, a missing theme prop, and makes your application bigger without good reason.\n\nSee https://s-c.sh/2BAXzed for more info."),window[st]+=1),exports.ServerStyleSheet=rt,exports.StyleSheetConsumer=Te,exports.StyleSheetContext=De,exports.StyleSheetManager=ke,exports.ThemeConsumer=We,exports.ThemeContext=Ye,exports.ThemeProvider=function(t){var r=l.default.useContext(Ye),o=n.useMemo(function(){return function(t,n){if(!t)throw ie(14);if(Z(t)){var r=t(n);if("production"!==process.env.NODE_ENV&&(null===r||Array.isArray(r)||"object"!=typeof r))throw ie(7);return r}if(Array.isArray(t)||"object"!=typeof t)throw ie(8);return n?e.__assign(e.__assign({},n),t):t}(t.theme,r)},[t.theme,r]);return t.children?l.default.createElement(Ye.Provider,{value:o},t.children):null},exports.__PRIVATE__=ot,exports.createGlobalStyle=function(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];var o=Ke.apply(void 0,e.__spreadArray([t],n,!1)),s="sc-global-".concat(R(JSON.stringify(o))),i=new nt(o,s);"production"!==process.env.NODE_ENV&&S(s);var a=function(e){var t=je(),n=l.default.useContext(Ye),r=l.default.useRef(t.styleSheet.allocateGSInstance(s)).current;return"production"!==process.env.NODE_ENV&&l.default.Children.count(e.children)&&console.warn("The global style component ".concat(s," was given child JSX. createGlobalStyle does not render children.")),"production"!==process.env.NODE_ENV&&o.some(function(e){return"string"==typeof e&&-1!==e.indexOf("@import")})&&console.warn("Please do not use @import CSS syntax in createGlobalStyle at this time, as the CSSOM APIs we use in production do not handle it well. Instead, we recommend using a library such as react-helmet to inject a typical <link> meta tag to the stylesheet, or simply embedding it manually in your index.html <head> section for a simpler app."),t.styleSheet.server&&c(r,e,t.styleSheet,n,t.stylis),l.default.useLayoutEffect(function(){if(!t.styleSheet.server)return c(r,e,t.styleSheet,n,t.stylis),function(){return i.removeStyles(r,t.styleSheet)}},[r,e,t.styleSheet,n,t.stylis]),null};function c(t,n,r,o,s){if(i.isStatic)i.renderStyles(t,m,r,s);else{var c=e.__assign(e.__assign({},n),{theme:b(n,o,a.defaultProps)});i.renderStyles(t,c,r,s)}}return l.default.memo(a)},exports.css=Ke,exports.default=tt,exports.isStyledComponent=K,exports.keyframes=function(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];"production"!==process.env.NODE_ENV&&"undefined"!=typeof navigator&&"ReactNative"===navigator.product&&console.warn("`keyframes` cannot be used on ReactNative, only on the web. To do animation in ReactNative please use Animated.");var o=ee(Ke.apply(void 0,e.__spreadArray([t],n,!1))),s=R(o);return new Ve(s,o)},exports.styled=tt,exports.useTheme=function(){var e=n.useContext(Ye);if(!e)throw ie(18);return e},exports.version="6.0.8",exports.withTheme=function(t){var n=l.default.forwardRef(function(n,r){var o=b(n,l.default.useContext(Ye),t.defaultProps);return"production"!==process.env.NODE_ENV&&void 0===o&&console.warn('[withTheme] You are not using a ThemeProvider nor passing a theme prop or a theme in defaultProps in component class "'.concat(j(t),'"')),l.default.createElement(t,e.__assign({},n,{theme:o,ref:r}))});return"production"!==process.env.NODE_ENV&&(n.displayName="WithTheme(".concat(j(t),")")),X(n,t)};

    return exports;
})();

__modules['templates.instruments.framework.components.link~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
require("react");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_colors_1_0_1 = require("templates.instruments.framework.components.colors~1_0");
const ActiveContainer = styled_components_1.default.button `
  color: ${templates_instruments_framework_components_colors_1_0_1.Colors.primary};
  text-decoration: underline;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  margin: 0;
  text-align: left;
  font-size: 0.833333rem;
  position: relative;

  &:hover {
    color: ${templates_instruments_framework_components_colors_1_0_1.Colors.primary_hover};
    text-decoration: underline;
  }
`;
const TapTarget = styled_components_1.default.span `
  position: absolute;
  width: 100%;
  height: 100%;
  min-height: 44px;
  min-width: 44px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;
const Link = ({ label, tabindex = 0, onClick }) => {
    return ((0, jsx_runtime_1.jsxs)(ActiveContainer, { tabIndex: tabindex, onClick: onClick, children: [(0, jsx_runtime_1.jsx)(TapTarget, {}), label] }));
};
exports.default = Link;

    return exports;
})();

__modules['templates.instruments.framework.step_api~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isQuestionStep = isQuestionStep;
function isQuestionStep(stepDefinition) {
    return stepDefinition.item_stem !== undefined;
}

    return exports;
})();

__modules['templates.instruments.framework.components.button~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Variant = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
require("react");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_colors_1_0_1 = require("templates.instruments.framework.components.colors~1_0");
var Variant;
(function (Variant) {
    Variant["primary"] = "primary";
    Variant["secondary"] = "secondary";
})(Variant || (exports.Variant = Variant = {}));
const Wrapper = styled_components_1.default.div `
  display: flex;
  flex: 1;
`;
/** If function to make the code below more readable */
function _if(condition, trueCase, falseCase = '') {
    return condition ? trueCase : falseCase;
}
/* eslint-disable */
const ButtonStyled = styled_components_1.default.button `${({ $primary: primary, disabled }) => `
  display: flex;
  flex: 1;
  color: ${disabled ? templates_instruments_framework_components_colors_1_0_1.Colors.text_disabled : primary ? 'white' : templates_instruments_framework_components_colors_1_0_1.Colors.text};
  background-color: ${disabled ? templates_instruments_framework_components_colors_1_0_1.Colors.disabled : primary ? templates_instruments_framework_components_colors_1_0_1.Colors.primary : templates_instruments_framework_components_colors_1_0_1.Colors.secondary};
  border: ${primary ? 'none' : `1px solid ${templates_instruments_framework_components_colors_1_0_1.Colors.border}`};
  cursor: ${disabled ? 'not-allowed' : 'pointer'};
  padding: 0px;
  align-items: center;
  justify-content: center;
  margin: 8px;
  height: 48px;
  border-radius: 6px;
  font-size: 1rem;

  ${_if(!disabled, `
  &:hover {
    background-color: ${primary ? templates_instruments_framework_components_colors_1_0_1.Colors.primary_hover : templates_instruments_framework_components_colors_1_0_1.Colors.secondary_hover};
  }

  &:active {
    background-color: ${primary ? templates_instruments_framework_components_colors_1_0_1.Colors.primary_active : templates_instruments_framework_components_colors_1_0_1.Colors.secondary_active};
  }
  `)};
`}`;
function Button({ label, variant = Variant.primary, disabled = false, tabindex = 0, onClick }) {
    return ((0, jsx_runtime_1.jsx)(Wrapper, { children: (0, jsx_runtime_1.jsx)(ButtonStyled, { tabIndex: tabindex, onClick: onClick, disabled: disabled, "$primary": variant === Variant.primary, children: label }) }));
}
Button.primary = (props) => Button(Object.assign(Object.assign({}, props), { variant: Variant.primary }));
Button.secondary = (props) => Button(Object.assign(Object.assign({}, props), { variant: Variant.secondary }));
exports.default = Button;

    return exports;
})();

__modules['templates.instruments.framework.step_api~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAnswered = isAnswered;
exports.isNumericAnswer = isNumericAnswer;
exports.isQuestionStep = isQuestionStep;
function isAnswered(answer) {
    return answer !== undefined && typeof answer !== 'string';
}
function isNumericAnswer(answer) {
    return typeof answer.value === 'number';
}
function isQuestionStep(stepDefinition) {
    return stepDefinition.item_stem !== undefined;
}

    return exports;
})();

__modules['templates.instruments.framework.components.confirm_dialog~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const react_dom_1 = require("react-dom");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_button_1_0_1 = __importDefault(require("templates.instruments.framework.components.button~1_0"));
const Backdrop = styled_components_1.default.div `
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const Overlay = styled_components_1.default.div `
  position: absolute;
  z-index: -1;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  opacity: 0.7;
  background-color: #d1d5db;
`;
const Dialog = styled_components_1.default.div `
  display: flex;
  flex-direction: column;
  row-gap: 12px;
  box-sizing: border-box;
  min-width: 300px;
  max-width: ${({ $fullWidth }) => ($fullWidth ? '608px' : 'calc(100% - 48px)')};
  max-height: calc(100% - 48px);
  border-radius: 16px;
  padding: 32px 24px 16px;
  background-color: white;
  box-shadow:
    0px 20px 25px -5px rgba(0, 0, 0, 0.1),
    0px 10px 10px -5px rgba(0, 0, 0, 0.04);
`;
const TextContainer = styled_components_1.default.div `
  flex-grow: 1;
  overflow-y: auto;
`;
const Title = styled_components_1.default.div `
  font-size: 20px;
  font-weight: 600;
  line-height: 24px;
  margin-bottom: 8px;
`;
const Content = styled_components_1.default.div ``;
const ButtonsContainer = styled_components_1.default.div `
  ${({ $fullWidth }) => $fullWidth
    ? `
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
        & > * {
          flex: 0 1 auto;
        }
        & button {
          padding: 0 16px;
    }
      `
    : ''}
`;
const ConfirmDialog = ({ isOpen, title, content, yesLabel, noLabel, onClose, closeDialog, containerRef, fullWidth = false, }) => {
    var _a;
    function handleClickYes() {
        onClose(true);
        closeDialog();
    }
    function handleClickNo() {
        onClose(false);
        closeDialog();
    }
    return (isOpen &&
        (0, react_dom_1.createPortal)((0, jsx_runtime_1.jsxs)(Backdrop, { children: [(0, jsx_runtime_1.jsx)(Overlay, {}), (0, jsx_runtime_1.jsxs)(Dialog, { "$fullWidth": fullWidth, children: [(0, jsx_runtime_1.jsxs)(TextContainer, { children: [(0, jsx_runtime_1.jsx)(Title, { children: title }), (0, jsx_runtime_1.jsx)(Content, { children: content })] }), (0, jsx_runtime_1.jsx)(ButtonsContainer, { "$fullWidth": fullWidth, children: fullWidth ? ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [noLabel && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.secondary, { label: noLabel, onClick: handleClickNo }), yesLabel && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.primary, { label: yesLabel, onClick: handleClickYes })] })) : ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [yesLabel && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.primary, { label: yesLabel, onClick: handleClickYes }), noLabel && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.secondary, { label: noLabel, onClick: handleClickNo })] })) })] })] }), (_a = containerRef === null || containerRef === void 0 ? void 0 : containerRef.current) !== null && _a !== void 0 ? _a : document.body));
};
exports.default = ConfirmDialog;

    return exports;
})();

__modules['templates.instruments.framework.components.spinner~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
require("react");
const styled_components_1 = __importStar(require("styled-components"));
const templates_instruments_framework_components_colors_1_0_1 = require("templates.instruments.framework.components.colors~1_0");
const SpinnerOverlay = styled_components_1.default.div `
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: #fffd;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const SpinnerDiv = styled_components_1.default.div `
  width: 100px;
  height: 100px;
  background-color: transparent;
`;
const spinAnimation = (0, styled_components_1.keyframes) `
  to {
    transform: rotate(360deg)
  }
`;
const SpinnerSvg = styled_components_1.default.svg `
  animation: ${spinAnimation} 1s linear infinite;
  color: ${templates_instruments_framework_components_colors_1_0_1.Colors.spinner_background};
  fill: ${templates_instruments_framework_components_colors_1_0_1.Colors.spinner_foreground};
`;
const Spinner = () => {
    return ((0, jsx_runtime_1.jsx)(SpinnerOverlay, { children: (0, jsx_runtime_1.jsx)(SpinnerDiv, { children: (0, jsx_runtime_1.jsxs)(SpinnerSvg, { viewBox: '0 0 100 101', fill: 'none', xmlns: 'http://www.w3.org/2000/svg', children: [(0, jsx_runtime_1.jsx)("path", { d: 'M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z', fill: 'currentColor' }), (0, jsx_runtime_1.jsx)("path", { d: 'M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z', fill: 'currentFill' })] }) }) }));
};
exports.default = Spinner;

    return exports;
})();

__modules['templates.time~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setTemplateTime = setTemplateTime;
exports.getTemplateTime = getTemplateTime;
exports.resetTemplateTime = resetTemplateTime;
let initialRealTime;
let initialAppTime;
/**
 * Sets the time to be used by the instrument template framework. Any time fetched using `getTemplateTime()` will return
 * the current time relative to the time set here.
 * @param time Time in milliseconds since the epoch (January 1, 1970, 00:00:00 UTC), or `undefined` to use system time.
 */
function setTemplateTime(time) {
    initialRealTime = time ? new Date().getTime() : undefined;
    initialAppTime = time;
}
/**
 * @returns the current time relative to the time set by `setTemplateTime()`. If no time has been set, it returns the
 * current system time.
 */
function getTemplateTime() {
    return initialRealTime === undefined || initialAppTime === undefined
        ? new Date()
        : new Date(new Date().getTime() - initialRealTime + initialAppTime);
}
/**
 * Resets the template time to use the current system time.
 */
function resetTemplateTime() {
    initialRealTime = undefined;
    initialAppTime = undefined;
}

    return exports;
})();

__modules['templates.instruments.framework.client_api~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable no-undef */
const templates_time_1_0_1 = require("templates.time~1_0");
/** Defines stubs for APIs for testing */
if (global.submit === undefined) {
    global.submit = () => { };
}
if (global.track === undefined) {
    console.log('track stubbed');
    global.track = () => { };
}
if (global.cancel === undefined) {
    global.cancel = () => { };
}
if (global.callApi === undefined) {
    global.callApi = () => Promise.resolve({});
}
if (global.getMetadata === undefined) {
    global.getMetadata = () => ({});
}
/** Api to communicate with the client. */
class Api {
    constructor() {
        this.events = [];
        // Sets a different time for the framework when specified by the client via getMetadata (e.g. for Time Travel).
        // Do this in a try/catch block because Site App had a bug in their getMetadata implementation which only occured
        // when it was called immediately after the page loaded (as is done here). If an error is caught here, the specified
        // template time will not be applied, but the instrument will still load and function properly (assuming subsequent
        // calls to getMetadata do not throw an error).
        // See https://gitlab.medable.com/product/web/mfw/monorepo/-/merge_requests/4971 .
        try {
            const { currentAppTime } = getMetadata();
            const millisSinceEpoch = currentAppTime !== undefined ? parseInt(currentAppTime) : undefined;
            (0, templates_time_1_0_1.setTemplateTime)(millisSinceEpoch !== undefined && !isNaN(millisSinceEpoch) ? millisSinceEpoch : undefined);
        }
        catch (error) {
            console.error('Error getting metadata and setting template time:', error);
        }
        this.trackTaskEvent('loaded');
        window.onerror = (error) => {
            this.trackEvent({ name: 'error', detail: error.toString(), timestamp: (0, templates_time_1_0_1.getTemplateTime)() });
        };
    }
    cancel(reason = 'user') {
        this.trackEvent({ name: 'cancel', timestamp: (0, templates_time_1_0_1.getTemplateTime)(), reason });
        cancel();
    }
    submit(responses) {
        this.trackTaskEvent('completion');
        submit({ responses, events: this.events });
    }
    trackStepEvent(event, stepId, data) {
        this.trackEvent({ name: event, stepId, timestamp: (0, templates_time_1_0_1.getTemplateTime)(), data });
    }
    trackTaskEvent(event) {
        this.trackEvent({ name: event, timestamp: (0, templates_time_1_0_1.getTemplateTime)() });
    }
    trackEvent(event) {
        this.events.push(event);
        track(event);
    }
    callApi(path, options) {
        return callApi(path, options);
    }
    getMetadata() {
        return getMetadata();
    }
}
exports.default = Api;

    return exports;
})();

__modules['strings.product.list_separator~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>", ";

    return exports;
})();

__modules['json-logic-js'] = (() => {
    const exports = {};
    const module = {exports};
    /* globals define,module */

Object.defineProperty(exports, '__esModule', { value: true });

const logic = function () {
  'use strict';
  /* globals console:false */

  if (!Array.isArray) {
    Array.isArray = function (arg) {
      return Object.prototype.toString.call(arg) === '[object Array]';
    };
  }

  /**
   * Return an array that contains no duplicates (original not modified)
   * @param  {array} array   Original reference array
   * @return {array}         New array with no duplicates
   */
  function arrayUnique(array) {
    var a = [];
    for (var i = 0, l = array.length; i < l; i++) {
      if (a.indexOf(array[i]) === -1) {
        a.push(array[i]);
      }
    }
    return a;
  }

  var jsonLogic = {};
  var operations = {
    '==': function (a, b) {
      return a == b;
    },
    '===': function (a, b) {
      return a === b;
    },
    '!=': function (a, b) {
      return a != b;
    },
    '!==': function (a, b) {
      return a !== b;
    },
    '>': function (a, b) {
      return a > b;
    },
    '>=': function (a, b) {
      return a >= b;
    },
    '<': function (a, b, c) {
      return c === undefined ? a < b : a < b && b < c;
    },
    '<=': function (a, b, c) {
      return c === undefined ? a <= b : a <= b && b <= c;
    },
    '!!': function (a) {
      return jsonLogic.truthy(a);
    },
    '!': function (a) {
      return !jsonLogic.truthy(a);
    },
    '%': function (a, b) {
      return a % b;
    },
    'log': function (a) {
      console.log(a);
      return a;
    },
    'in': function (a, b) {
      if (!b || typeof b.indexOf === 'undefined') return false;
      return b.indexOf(a) !== -1;
    },
    'cat': function () {
      return Array.prototype.join.call(arguments, '');
    },
    'substr': function (source, start, end) {
      if (end < 0) {
        // JavaScript doesn't support negative end, this emulates PHP behavior
        var temp = String(source).substr(start);
        return temp.substr(0, temp.length + end);
      }
      return String(source).substr(start, end);
    },
    '+': function () {
      return Array.prototype.reduce.call(
        arguments,
        function (a, b) {
          return parseFloat(a, 10) + parseFloat(b, 10);
        },
        0
      );
    },
    '*': function () {
      return Array.prototype.reduce.call(arguments, function (a, b) {
        return parseFloat(a, 10) * parseFloat(b, 10);
      });
    },
    '-': function (a, b) {
      if (b === undefined) {
        return -a;
      } else {
        return a - b;
      }
    },
    '/': function (a, b) {
      return a / b;
    },
    'min': function () {
      return Math.min.apply(this, arguments);
    },
    'max': function () {
      return Math.max.apply(this, arguments);
    },
    'merge': function () {
      return Array.prototype.reduce.call(
        arguments,
        function (a, b) {
          return a.concat(b);
        },
        []
      );
    },
    'var': function (a, b) {
      var not_found = b === undefined ? null : b;
      var data = this;
      if (typeof a === 'undefined' || a === '' || a === null) {
        return data;
      }
      var sub_props = String(a).split('.');
      for (var i = 0; i < sub_props.length; i++) {
        if (data === null || data === undefined) {
          return not_found;
        }
        // Descending into data
        data = data[sub_props[i]];
        if (data === undefined) {
          return not_found;
        }
      }
      return data;
    },
    'missing': function () {
      /*
        Missing can receive many keys as many arguments, like {"missing:[1,2]}
        Missing can also receive *one* argument that is an array of keys,
        which typically happens if it's actually acting on the output of another command
        (like 'if' or 'merge')
        */

      var missing = [];
      var keys = Array.isArray(arguments[0]) ? arguments[0] : arguments;

      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        var value = jsonLogic.apply({ var: key }, this);
        if (value === null || value === '') {
          missing.push(key);
        }
      }

      return missing;
    },
    'missing_some': function (need_count, options) {
      // missing_some takes two arguments, how many (minimum) items must be present, and an array of keys (just like 'missing') to check for presence.
      var are_missing = jsonLogic.apply({ missing: options }, this);

      if (options.length - are_missing.length >= need_count) {
        return [];
      } else {
        return are_missing;
      }
    },
  };

  jsonLogic.is_logic = function (logic) {
    return (
      typeof logic === 'object' && // An object
      logic !== null && // but not null
      !Array.isArray(logic) && // and not an array
      Object.keys(logic).length === 1 // with exactly one key
    );
  };

  /*
    This helper will defer to the JsonLogic spec as a tie-breaker when different language interpreters define different behavior for the truthiness of primitives.  E.g., PHP considers empty arrays to be falsy, but Javascript considers them to be truthy. JsonLogic, as an ecosystem, needs one consistent answer.
  
    Spec and rationale here: http://jsonlogic.com/truthy
    */
  jsonLogic.truthy = function (value) {
    if (Array.isArray(value) && value.length === 0) {
      return false;
    }
    return !!value;
  };

  jsonLogic.get_operator = function (logic) {
    return Object.keys(logic)[0];
  };

  jsonLogic.get_values = function (logic) {
    return logic[jsonLogic.get_operator(logic)];
  };

  jsonLogic.apply = function (logic, data) {
    // Does this array contain logic? Only one way to find out.
    if (Array.isArray(logic)) {
      return logic.map(function (l) {
        return jsonLogic.apply(l, data);
      });
    }
    // You've recursed to a primitive, stop!
    if (!jsonLogic.is_logic(logic)) {
      return logic;
    }

    var op = jsonLogic.get_operator(logic);
    var values = logic[op];
    var i;
    var current;
    var scopedLogic;
    var scopedData;
    var initial;

    // easy syntax for unary operators, like {"var" : "x"} instead of strict {"var" : ["x"]}
    if (!Array.isArray(values)) {
      values = [values];
    }

    // 'if', 'and', and 'or' violate the normal rule of depth-first calculating consequents, let each manage recursion as needed.
    if (op === 'if' || op == '?:') {
      /* 'if' should be called with a odd number of parameters, 3 or greater
        This works on the pattern:
        if( 0 ){ 1 }else{ 2 };
        if( 0 ){ 1 }else if( 2 ){ 3 }else{ 4 };
        if( 0 ){ 1 }else if( 2 ){ 3 }else if( 4 ){ 5 }else{ 6 };
  
        The implementation is:
        For pairs of values (0,1 then 2,3 then 4,5 etc)
        If the first evaluates truthy, evaluate and return the second
        If the first evaluates falsy, jump to the next pair (e.g, 0,1 to 2,3)
        given one parameter, evaluate and return it. (it's an Else and all the If/ElseIf were false)
        given 0 parameters, return NULL (not great practice, but there was no Else)
        */
      for (i = 0; i < values.length - 1; i += 2) {
        if (jsonLogic.truthy(jsonLogic.apply(values[i], data))) {
          return jsonLogic.apply(values[i + 1], data);
        }
      }
      if (values.length === i + 1) {
        return jsonLogic.apply(values[i], data);
      }
      return null;
    } else if (op === 'and') {
      // Return first falsy, or last
      for (i = 0; i < values.length; i += 1) {
        current = jsonLogic.apply(values[i], data);
        if (!jsonLogic.truthy(current)) {
          return current;
        }
      }
      return current; // Last
    } else if (op === 'or') {
      // Return first truthy, or last
      for (i = 0; i < values.length; i += 1) {
        current = jsonLogic.apply(values[i], data);
        if (jsonLogic.truthy(current)) {
          return current;
        }
      }
      return current; // Last
    } else if (op === 'filter') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];

      if (!Array.isArray(scopedData)) {
        return [];
      }
      // Return only the elements from the array in the first argument,
      // that return truthy when passed to the logic in the second argument.
      // For parity with JavaScript, reindex the returned array
      return scopedData.filter(function (datum) {
        return jsonLogic.truthy(jsonLogic.apply(scopedLogic, datum));
      });
    } else if (op === 'map') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];

      if (!Array.isArray(scopedData)) {
        return [];
      }

      return scopedData.map(function (datum) {
        return jsonLogic.apply(scopedLogic, datum);
      });
    } else if (op === 'reduce') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];
      initial = typeof values[2] !== 'undefined' ? values[2] : null;

      if (!Array.isArray(scopedData)) {
        return initial;
      }

      return scopedData.reduce(function (accumulator, current) {
        return jsonLogic.apply(scopedLogic, { current: current, accumulator: accumulator });
      }, initial);
    } else if (op === 'all') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];
      // All of an empty set is false. Note, some and none have correct fallback after the for loop
      if (!Array.isArray(scopedData) || !scopedData.length) {
        return false;
      }
      for (i = 0; i < scopedData.length; i += 1) {
        if (!jsonLogic.truthy(jsonLogic.apply(scopedLogic, scopedData[i]))) {
          return false; // First falsy, short circuit
        }
      }
      return true; // All were truthy
    } else if (op === 'none') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];

      if (!Array.isArray(scopedData) || !scopedData.length) {
        return true;
      }
      for (i = 0; i < scopedData.length; i += 1) {
        if (jsonLogic.truthy(jsonLogic.apply(scopedLogic, scopedData[i]))) {
          return false; // First truthy, short circuit
        }
      }
      return true; // None were truthy
    } else if (op === 'some') {
      scopedData = jsonLogic.apply(values[0], data);
      scopedLogic = values[1];

      if (!Array.isArray(scopedData) || !scopedData.length) {
        return false;
      }
      for (i = 0; i < scopedData.length; i += 1) {
        if (jsonLogic.truthy(jsonLogic.apply(scopedLogic, scopedData[i]))) {
          return true; // First truthy, short circuit
        }
      }
      return false; // None were truthy
    }

    // Everyone else gets immediate depth-first recursion
    values = values.map(function (val) {
      return jsonLogic.apply(val, data);
    });

    // The operation is called with "data" bound to its "this" and "values" passed as arguments.
    // Structured commands like % or > can name formal arguments while flexible commands (like missing or merge) can operate on the pseudo-array arguments
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/arguments
    if (operations.hasOwnProperty(op) && typeof operations[op] === 'function') {
      return operations[op].apply(data, values);
    } else if (op.indexOf('.') > 0) {
      // Contains a dot, and not in the 0th position
      var sub_ops = String(op).split('.');
      var operation = operations;
      for (i = 0; i < sub_ops.length; i++) {
        if (!operation.hasOwnProperty(sub_ops[i])) {
          throw new Error('Unrecognized operation ' + op + ' (failed at ' + sub_ops.slice(0, i + 1).join('.') + ')');
        }
        // Descending into operations
        operation = operation[sub_ops[i]];
      }

      return operation.apply(data, values);
    }

    throw new Error('Unrecognized operation ' + op);
  };

  jsonLogic.uses_data = function (logic) {
    var collection = [];

    if (jsonLogic.is_logic(logic)) {
      var op = jsonLogic.get_operator(logic);
      var values = logic[op];

      if (!Array.isArray(values)) {
        values = [values];
      }

      if (op === 'var') {
        // This doesn't cover the case where the arg to var is itself a rule.
        collection.push(values[0]);
      } else {
        // Recursion!
        values.forEach(function (val) {
          collection.push.apply(collection, jsonLogic.uses_data(val));
        });
      }
    }

    return arrayUnique(collection);
  };

  jsonLogic.add_operation = function (name, code) {
    operations[name] = code;
  };

  jsonLogic.rm_operation = function (name) {
    delete operations[name];
  };

  jsonLogic.rule_like = function (rule, pattern) {
    // console.log("Is ". JSON.stringify(rule) . " like " . JSON.stringify(pattern) . "?");
    if (pattern === rule) {
      return true;
    } // TODO : Deep object equivalency?
    if (pattern === '@') {
      return true;
    } // Wildcard!
    if (pattern === 'number') {
      return typeof rule === 'number';
    }
    if (pattern === 'string') {
      return typeof rule === 'string';
    }
    if (pattern === 'array') {
      // !logic test might be superfluous in JavaScript
      return Array.isArray(rule) && !jsonLogic.is_logic(rule);
    }

    if (jsonLogic.is_logic(pattern)) {
      if (jsonLogic.is_logic(rule)) {
        var pattern_op = jsonLogic.get_operator(pattern);
        var rule_op = jsonLogic.get_operator(rule);

        if (pattern_op === '@' || pattern_op === rule_op) {
          // echo "\nOperators match, go deeper\n";
          return jsonLogic.rule_like(jsonLogic.get_values(rule, false), jsonLogic.get_values(pattern, false));
        }
      }
      return false; // pattern is logic, rule isn't, can't be eq
    }

    if (Array.isArray(pattern)) {
      if (Array.isArray(rule)) {
        if (pattern.length !== rule.length) {
          return false;
        }
        /*
            Note, array order MATTERS, because we're using this array test logic to consider arguments, where order can matter. (e.g., + is commutative, but '-' or 'if' or 'var' are NOT)
          */
        for (var i = 0; i < pattern.length; i += 1) {
          // If any fail, we fail
          if (!jsonLogic.rule_like(rule[i], pattern[i])) {
            return false;
          }
        }
        return true; // If they *all* passed, we pass
      } else {
        return false; // Pattern is array, rule isn't
      }
    }

    // Not logic, not array, not a === match for rule.
    return false;
  };

  return jsonLogic;
};

exports['default'] = logic();

    return exports;
})();

__modules['templates.temporal.plain_time~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlainTime = void 0;
/**
 * This implementation is based on the Temporal PlainTime proposal, but strips the seconds part of the time value,
 * as they are not used in eCOAs and it simplifies the implementation.
 */
class PlainTime {
    constructor(timeString) {
        // In order to properly compare values that have 00 seconds with values that don't include seconds, normalize the
        // value by removing seconds (including decimal parts of seconds).
        this.timeString = timeString.replace(/(\d\d:\d\d):\d\d.*/, '$1');
        // If we ever decide to include seconds, the correct code to normalize the value is:
        // this.dateTimeIsoString = dateTimeIsoString.replace(/(\d\d:\d\d(?!:))/, '$1:00');
    }
    static from(timeString) {
        return new PlainTime(timeString);
    }
    toString() {
        return this.timeString;
    }
}
exports.PlainTime = PlainTime;

    return exports;
})();

__modules['templates.temporal.plain_date_time~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlainDateTime = void 0;
const templates_temporal_plain_time_1_0_1 = require("templates.temporal.plain_time~1_0");
/**
 * This implementation is based on the Temporal PlainDateTime proposal, but strips the seconds part of the time value,
 * as they are not used in eCOAs and it simplifies the implementation.
 */
class PlainDateTime {
    constructor(dateTimeIsoString) {
        this.dateTimeIsoString = dateTimeIsoString
            // Only keep the date, hour and minutes. Remove seconds to ensure the date string is in ISO format
            // (YYYY-MM-DDTHH:mm). Also removes the timezone.
            .replace(/^(\d\d\d\d-\d\d-\d\d(T\d\d:\d\d)?).*$/, '$1')
            // If the date string doesn't have a time component, default it to midnight.
            .replace(/^(\d\d\d\d-\d\d-\d\d)$/, '$1T00:00');
    }
    static from(dateTimeIsoString) {
        return new PlainDateTime(dateTimeIsoString);
    }
    toString() {
        return this.dateTimeIsoString;
    }
    add({ days, hours }) {
        // Add 'Z' to pretend the time is in UTC so Date() doesn't adjust it to the local timezone. We'll remove it later.
        const date = new Date(`${this.dateTimeIsoString}Z`);
        // Use UTC functions to avoid daylight savings time changes.
        date.setUTCDate(date.getUTCDate() + (days || 0));
        date.setUTCHours(date.getUTCHours() + (hours || 0));
        // Because we're creating the date from an ISO string and converting it back after adding, timezone doesn't matter.
        return new PlainDateTime(date.toISOString().replace(/(T\d\d:\d\d).*Z/, '$1'));
    }
    withPlainTime(plainTime) {
        if (typeof plainTime === 'object') {
            throw new Error('withPlainTime() with object argument is not supported');
        }
        return new PlainDateTime(`${this.dateTimeIsoString.replace(/T\d\d:\d\d/, `T${plainTime !== null && plainTime !== void 0 ? plainTime : '00:00'}`)}`);
    }
    toPlainTime() {
        return templates_temporal_plain_time_1_0_1.PlainTime.from(this.dateTimeIsoString.replace(/.*T(\d\d:\d\d).*/, '$1'));
    }
    static compare(one, two) {
        return one.dateTimeIsoString < two.dateTimeIsoString ? -1 : one.dateTimeIsoString > two.dateTimeIsoString ? 1 : 0;
    }
}
exports.PlainDateTime = PlainDateTime;

    return exports;
})();

__modules['templates.temporal.plain_date~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlainDate = void 0;
class PlainDate {
    constructor(dateIsoString) {
        // Remove time component to ensure the date string is in ISO format (YYYY-MM-DD). Also removes the timezone.
        this.dateIsoString = dateIsoString.replace(/(\d\d\d\d-\d\d-\d\d).*$/, '$1');
    }
    static from(dateIsoString) {
        return new PlainDate(dateIsoString);
    }
    toString() {
        return this.dateIsoString;
    }
    add({ days }) {
        const date = new Date(this.dateIsoString);
        // Use UTC functions to avoid daylight savings time changes.
        date.setUTCDate(date.getUTCDate() + (days || 0));
        // Because we're creating the date from an ISO string and converting it back after adding, timezone doesn't matter.
        return new PlainDate(date.toISOString().split('T')[0]);
    }
    static compare(one, two) {
        return one.dateIsoString < two.dateIsoString ? -1 : one.dateIsoString > two.dateIsoString ? 1 : 0;
    }
}
exports.PlainDate = PlainDate;

    return exports;
})();

__modules['templates.instruments.framework.formatters.date_time~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDateFormatter = getDateFormatter;
exports.getDateTimeFormatter = getDateTimeFormatter;
function getDateFormatter(locale) {
    const { format } = Intl.DateTimeFormat(locale || 'en-US', {
        timeZone: 'UTC',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        calendar: 'gregory',
        numberingSystem: 'latn',
    });
    return (plainDate) => format(new Date(plainDate.toString()));
}
function getDateTimeFormatter(locale) {
    const { format } = Intl.DateTimeFormat(locale || 'en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        timeZoneName: 'short',
        calendar: 'gregory',
        numberingSystem: 'latn',
    });
    return (plainDateTime) => format(new Date(plainDateTime.toString()));
}

    return exports;
})();

__modules['templates.instruments.framework.formatters.number~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNumberFormatter = getNumberFormatter;
exports.getDecimalSeparator = getDecimalSeparator;
function getNumberFormatter(locale) {
    const decimalSeparator = getDecimalSeparator(locale);
    return (num) => num
        .toString()
        .replace(/[^0-9.,-]/g, '')
        .replace(/[.,]/g, decimalSeparator);
}
function getDecimalSeparator(locale) {
    return (1.1)
        .toLocaleString(locale || 'en-US', { numberingSystem: 'latn' })
        .replace(/1/g, '');
}

    return exports;
})();

__modules['templates.instruments.framework.variables~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSingleVariable = isSingleVariable;
exports.isVariableArray = isVariableArray;
function isSingleVariable(variable) {
    return variable !== undefined && !Array.isArray(variable);
}
function isVariableArray(variable) {
    return variable !== undefined && Array.isArray(variable);
}

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_customization_data~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useCustomizationData = useCustomizationData;
exports.getLocalizedVariable = getLocalizedVariable;
exports.getLocalizedVariableList = getLocalizedVariableList;
const react_1 = require("react");
const strings_product_list_separator_r0_1 = __importDefault(require("strings.product.list_separator~r0"));
const templates_instruments_framework_formatters_date_time_1_0_1 = require("templates.instruments.framework.formatters.date_time~1_0");
const templates_instruments_framework_formatters_number_1_0_1 = require("templates.instruments.framework.formatters.number~1_0");
const templates_temporal_plain_date_time_1_0_1 = require("templates.temporal.plain_date_time~1_0");
const templates_temporal_plain_date_1_0_1 = require("templates.temporal.plain_date~1_0");
function isSingleVariableData(variable) {
    return !Array.isArray(variable);
}
function useCustomizationData(configuration, api) {
    // If there's no configuration, we don't need to fetch customization data, it can be initialized to an empty object.
    const [customizationData, setCustomizationData] = (0, react_1.useState)(configuration ? undefined : {});
    (0, react_1.useEffect)(() => {
        var _a;
        if (configuration) {
            const metadata = (_a = api.getMetadata()) !== null && _a !== void 0 ? _a : {};
            api.callApi(`routes/ecoa/customization`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: Object.assign({ metadata }, configuration),
            })
                .then((response) => { var _a; return setCustomizationData((_a = response.data) !== null && _a !== void 0 ? _a : {}); })
                .catch(() => setCustomizationData({}));
        }
    }, []);
    // Use useMemo so that any useEffects that depend on these objects don't rerun unnecessarily (because even if the
    // object contents don't change, the object reference would change and trigger the useEffect).
    const displayLogicData = (0, react_1.useMemo)(() => {
        var _a;
        // If configuration has display logic: if customization data is available, return its display logic data or {}, but
        // if customization data isn't available yet then return undefined because we're waiting for it. If there's no
        // display logic in the configuration, return {} regardless of whether customization data is available yet.
        return (configuration === null || configuration === void 0 ? void 0 : configuration.display_logic) && Object.keys(configuration.display_logic).length > 0
            ? customizationData !== undefined
                ? ((_a = customizationData.displayLogic) !== null && _a !== void 0 ? _a : {})
                : undefined
            : {};
    }, [configuration, customizationData]);
    const variablesData = (0, react_1.useMemo)(() => {
        var _a, _b;
        // If configuration has variables: if customization data is available, return its variables data or {}, but if
        // customization data isn't available yet then return undefined because we're waiting for it. If there are no
        // variables in the configuration, return {} regardless of whether customization data is available yet.
        return ((_a = configuration === null || configuration === void 0 ? void 0 : configuration.variables_config) === null || _a === void 0 ? void 0 : _a.variable_screen_map) &&
            Object.keys(configuration.variables_config.variable_screen_map).length > 0
            ? customizationData !== undefined
                ? getLocalizedVariables((_b = customizationData.variables) !== null && _b !== void 0 ? _b : {}, configuration.variables_config)
                : undefined
            : {};
    }, [configuration, customizationData]);
    return { displayLogicData, variablesData };
}
/** Returns a map of variable data that includes the localized value of those variables. */
function getLocalizedVariables(variables, configuration) {
    return Object.entries(variables).reduce((acc, [varName, varData]) => {
        var _a;
        const localizationConfig = (_a = configuration === null || configuration === void 0 ? void 0 : configuration.variable_localization) === null || _a === void 0 ? void 0 : _a[varName];
        return Object.assign(Object.assign({}, acc), { [varName]: isSingleVariableData(varData)
                ? getLocalizedVariable(varData, localizationConfig)
                : getLocalizedVariableList(varData, configuration, `${varName}_`) });
    }, {});
}
/**
 * Returns a single variable with its display and value, and a localized version of the display if available. Also
 * converts any timezoned date/time value to the local timezone.
 */
function getLocalizedVariable(variable, localizationConfig) {
    var _a;
    const { display, value, localizationKey = '' } = variable;
    const isStringLocalization = (localizationConfig === null || localizationConfig === void 0 ? void 0 : localizationConfig.localization_strategy) === 'string';
    const isDateTimeLocalization = (localizationConfig === null || localizationConfig === void 0 ? void 0 : localizationConfig.localization_strategy) === 'date_time';
    const isDateLocalization = (localizationConfig === null || localizationConfig === void 0 ? void 0 : localizationConfig.localization_strategy) === 'date';
    const isNumberLocalization = (localizationConfig === null || localizationConfig === void 0 ? void 0 : localizationConfig.localization_strategy) === 'number';
    const formatDateTime = (0, templates_instruments_framework_formatters_date_time_1_0_1.getDateTimeFormatter)(document.documentElement.lang || 'en-US');
    const formatDate = (0, templates_instruments_framework_formatters_date_time_1_0_1.getDateFormatter)(document.documentElement.lang || 'en-US');
    const formatNumber = (0, templates_instruments_framework_formatters_number_1_0_1.getNumberFormatter)(document.documentElement.lang || 'en-US');
    let fixedValue = value;
    if (isDateTimeLocalization || isDateLocalization) {
        // If date/time has a timezone offset, convert it to local time.
        if (/(Z|[+-]\d\d:\d\d)$/.test(value.toString())) {
            const dateTime = new Date(value.toString());
            const localDateTime = new Date(dateTime.getTime() - dateTime.getTimezoneOffset() * 60 * 1000);
            const localIsoString = localDateTime.toISOString().replace(/Z$/, '');
            fixedValue = (isDateLocalization ? templates_temporal_plain_date_1_0_1.PlainDate : templates_temporal_plain_date_time_1_0_1.PlainDateTime).from(localIsoString).toString();
        }
        else {
            // If date/time has no timezone offset, just fix the value to be a proper date or date+time.
            fixedValue = (isDateLocalization ? templates_temporal_plain_date_1_0_1.PlainDate : templates_temporal_plain_date_time_1_0_1.PlainDateTime).from(value.toString()).toString();
        }
    }
    return {
        display,
        value: fixedValue,
        localizedDisplay: 
        // TODO: Add cases for other localization strategies (number, date, etc).
        isStringLocalization
            ? (_a = localizationConfig === null || localizationConfig === void 0 ? void 0 : localizationConfig.localized_labels) === null || _a === void 0 ? void 0 : _a[localizationKey]
            : isDateTimeLocalization
                ? formatDateTime(templates_temporal_plain_date_time_1_0_1.PlainDateTime.from(fixedValue.toString()))
                : isDateLocalization
                    ? formatDate(templates_temporal_plain_date_1_0_1.PlainDate.from(fixedValue.toString()))
                    : isNumberLocalization
                        ? formatNumber(fixedValue)
                        : undefined,
    };
}
/**
 * Returns an array of variables representing objects. Each variable's localized display is a comma-separated list of
 * its localized fields. Also populates the `fieldValues` property of each variable with the values of its fields (used
 * for uniqueness check) and the `associatedEventVariables` property of each variable (used for the associated events
 * dialog).
 */
function getLocalizedVariableList(varDataList, configuration, fieldPrefix) {
    return varDataList.map((varData) => {
        // For each field in the variable, get its localized variable data, including time values in the local timezone.
        const localizedFieldVariables = Object.entries(varData.labels).reduce((acc, [fieldName, fieldVarData]) => {
            var _a;
            return (Object.assign(Object.assign({}, acc), { [fieldName]: getLocalizedVariable(fieldVarData, (_a = configuration === null || configuration === void 0 ? void 0 : configuration.variable_localization) === null || _a === void 0 ? void 0 : _a[fieldName]) }));
        }, {});
        const localizedDisplay = Object.values(localizedFieldVariables)
            .map((localizedField) => localizedField.localizedDisplay || localizedField.display)
            .join((0, strings_product_list_separator_r0_1.default)());
        return {
            display: localizedDisplay,
            value: varData.value,
            localizedDisplay,
            // Include the fields for uniqueness check. Strip off the field prefix from the field names so they match the
            // question ids that they will be compared to.
            fieldValues: Object.entries(localizedFieldVariables).reduce((acc, [name, variable]) => (Object.assign(Object.assign({}, acc), { [name.replace(fieldPrefix, '')]: variable.value })), {}),
            associatedEventVariables: varData.subList
                ? getLocalizedVariableList(varData.subList, configuration, fieldPrefix)
                : undefined,
        };
    });
}

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_all_variables~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useAllVariables = useAllVariables;
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
function useAllVariables(answers, serverVariables, variablesConfig) {
    const selfReferentialVariables = variablesConfig === null || variablesConfig === void 0 ? void 0 : variablesConfig.variables.filter((variableConfig) => variableConfig.type === 'self_referential').reduce((acc, variableConfig) => {
        var _a;
        if (Array.isArray(variableConfig.question_id)) {
            // Self-ref var refers to a list of question ids, so get a list of only the answered questions and convert them
            // to variables.
            const variableList = variableConfig.question_id
                .map((questionId) => answers[questionId])
                .filter(templates_instruments_framework_step_api_2_0_1.isAnswered)
                .map(getVariableFromAnswer);
            return Object.assign(Object.assign({}, acc), (variableList.length === 0
                ? {}
                : {
                    [variableConfig.name]: {
                        display: variableList.map((variable) => variable.display).join(', '),
                        value: variableList.map((variable) => variable.value).join(', '),
                        localizedDisplay: variableList.map((variable) => variable.localizedDisplay).join(', '),
                    },
                }));
        }
        // else, question_id is a single id.
        const answer = answers[(_a = variableConfig.question_id) !== null && _a !== void 0 ? _a : ''];
        return Object.assign(Object.assign({}, acc), ((0, templates_instruments_framework_step_api_2_0_1.isAnswered)(answer)
            ? {
                [variableConfig.name]: getVariableFromAnswer(answer),
            }
            : {}));
    }, {});
    const allVariables = Object.assign(Object.assign({}, serverVariables), selfReferentialVariables);
    return { serverVariables, selfReferentialVariables, allVariables };
}
function getVariableFromAnswer(answer) {
    var _a;
    return {
        display: (_a = answer.originalText) !== null && _a !== void 0 ? _a : answer.text,
        // If answer.value is an array, e.g. for multiple choice VRS, this will be useless, but for now we don't
        // have any use cases for using the value of a self-referential multiple choice VRS. The only current
        // use case is for a single choice VRS that defines the unit used in a subsequent NDE step.
        value: typeof answer.value === 'number' ? answer.value : answer.value.toString(),
        localizedDisplay: answer.text,
    };
}

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_answers~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useAnswers = void 0;
const react_1 = require("react");
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
/**
 * Custom hook for managing an instrument's answers.
 *
 * @param currentStepId Id of the current step.
 * @param api API object for tracking step events. Using as a parameter for now until we have a real singleton API
 *     object.
 */
const useAnswers = (currentStepId, api) => {
    const [answers, setAnswers] = (0, react_1.useState)({});
    function updateAnswer(answer) {
        const oldAnswer = answers[currentStepId];
        if (answer === answers[currentStepId] ||
            ((0, templates_instruments_framework_step_api_2_0_1.isAnswered)(answer) &&
                (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(oldAnswer) &&
                (answer.value === oldAnswer.value ||
                    // Since two NaN values are never equal, we need to check if both are NaN to avoid an infinite loop.
                    ((0, templates_instruments_framework_step_api_2_0_1.isNumericAnswer)(oldAnswer) && isNaN(oldAnswer.value) && (0, templates_instruments_framework_step_api_2_0_1.isNumericAnswer)(answer) && isNaN(answer.value))) &&
                answer.unit === oldAnswer.unit &&
                answer.text === oldAnswer.text)) {
            // Don't update if the value is the same, or else the step component will re-render infinitely.
            return;
        }
        api.trackStepEvent('update', currentStepId, { [currentStepId]: answer });
        setAnswers(Object.assign(Object.assign({}, answers), { [currentStepId]: answer }));
    }
    function updateAnswers(newAnswers) {
        const updatedAnswers = Object.entries(newAnswers).reduce((acc, [questionId, newAnswer]) => {
            const oldAnswer = answers[questionId];
            if (
            // If answer is being cleared...
            (!(0, templates_instruments_framework_step_api_2_0_1.isAnswered)(newAnswer) && newAnswer !== oldAnswer) ||
                // ...or if answer is being changed.
                ((0, templates_instruments_framework_step_api_2_0_1.isAnswered)(newAnswer) &&
                    (!(0, templates_instruments_framework_step_api_2_0_1.isAnswered)(oldAnswer) ||
                        (newAnswer.value !== oldAnswer.value &&
                            // Since two NaN values are never equal, we need to check if both are NaN to avoid unneccesarily updating
                            // (which causes an infinite render loop).
                            !(typeof oldAnswer.value === 'number' &&
                                isNaN(oldAnswer.value) &&
                                typeof newAnswer.value === 'number' &&
                                isNaN(newAnswer.value))) ||
                        newAnswer.text !== oldAnswer.text ||
                        newAnswer.unit !== oldAnswer.unit))) {
                return Object.assign(Object.assign({}, acc), { [questionId]: newAnswer });
            }
            return acc;
        }, {});
        if (Object.keys(updatedAnswers).length > 0) {
            api.trackStepEvent('update', currentStepId, updatedAnswers);
            setAnswers(Object.assign(Object.assign({}, answers), updatedAnswers));
        }
    }
    return {
        /**
         * A map with the latest answer recorded for each question.
         */
        answers,
        /**
         * The answer of the current step.
         * @deprecated Use `answers` instead.
         */
        currentAnswer: answers[currentStepId],
        /**
         * A function to update the answer for the current step.
         * @deprecated Use `updateAnswers` instead.
         */
        updateAnswer,
        /**
         * A function to update several answers.
         */
        updateAnswers,
    };
};
exports.useAnswers = useAnswers;

    return exports;
})();

__modules['strings.product.button_change_response~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Change Response";

    return exports;
})();

__modules['strings.product.duplicate_dialog.error_heading~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"You selected:";

    return exports;
})();

__modules['strings.product.duplicate_dialog.error_message~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"You already have an entry with these responses. Please go back and change your responses or select cancel.";

    return exports;
})();

__modules['strings.product.duplicate_dialog.title~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Duplicate entry";

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_event~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useEvent = useEvent;
const jsx_runtime_1 = require("react/jsx-runtime");
const strings_product_button_change_response_r0_1 = __importDefault(require("strings.product.button_change_response~r0"));
const strings_product_duplicate_dialog_error_heading_r0_1 = __importDefault(require("strings.product.duplicate_dialog.error_heading~r0"));
const strings_product_duplicate_dialog_error_message_r0_1 = __importDefault(require("strings.product.duplicate_dialog.error_message~r0"));
const strings_product_duplicate_dialog_title_r0_1 = __importDefault(require("strings.product.duplicate_dialog.title~r0"));
const strings_product_list_separator_r0_1 = __importDefault(require("strings.product.list_separator~r0"));
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
const templates_instruments_framework_variables_1_0_1 = require("templates.instruments.framework.variables~1_0");
function useEvent(config, answers, variables, currentStepId, isFinalStep) {
    const event_config = config === null || config === void 0 ? void 0 : config.event_config;
    const eventFields = (event_config === null || event_config === void 0 ? void 0 : event_config.fields) || [];
    /**
     * Performs a uiniqueness check if appropriate and if so returns true if the event composed from teh current answers
     * is a duplicate of an existing event.
     */
    function isDuplicateEvent() {
        var _a;
        if (!event_config || eventFields.length === 0) {
            // No fields to check for uniqueness, so no duplicate event.
            return false;
        }
        if (isFinalStep || ((_a = event_config.uniqueness_check_screen_ids) === null || _a === void 0 ? void 0 : _a.includes(currentStepId))) {
            // Only perform the uniqueness check if this is the final step or if the current step is one of the ones requested
            // in the instrument configuration.
            const existingEventsVariable = event_config.existing_events_variable
                ? variables === null || variables === void 0 ? void 0 : variables[event_config.existing_events_variable]
                : undefined;
            return ((0, templates_instruments_framework_variables_1_0_1.isVariableArray)(existingEventsVariable) &&
                // If there is an existing event for which all fields match the current answers, it's a duplicate.
                existingEventsVariable.some((existingEvent) => eventFields.every((field) => {
                    var _a;
                    const fieldAnswer = answers[field];
                    const fieldAnswerValue = (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(fieldAnswer) ? fieldAnswer.value : undefined;
                    const existingFieldValue = (_a = existingEvent.fieldValues) === null || _a === void 0 ? void 0 : _a[field];
                    return fieldAnswerValue === existingFieldValue;
                })));
        }
        return false;
    }
    const eventDisplay = eventFields
        .map((field) => {
        const fieldAnswer = answers[field];
        return (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(fieldAnswer) ? fieldAnswer.text : undefined;
    })
        .filter(Boolean)
        .join((0, strings_product_list_separator_r0_1.default)());
    const duplicateEventDialogOptions = {
        title: (0, strings_product_duplicate_dialog_title_r0_1.default)(),
        content: ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)("p", { children: [(0, strings_product_duplicate_dialog_error_heading_r0_1.default)(), (0, jsx_runtime_1.jsx)("br", {}), eventDisplay] }), (0, jsx_runtime_1.jsx)("p", { children: (0, strings_product_duplicate_dialog_error_message_r0_1.default)() })] })),
        yesLabel: '',
        noLabel: (0, strings_product_button_change_response_r0_1.default)(),
    };
    return { isDuplicateEvent, duplicateEventDialogOptions };
}

    return exports;
})();

__modules['templates.instruments.framework.json_logic~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extendJsonLogic = extendJsonLogic;
const json_logic_js_1 = __importDefault(require("json-logic-js"));
function toArray(value) {
    return value === undefined ? [] : Array.isArray(value) ? value : [value];
}
/**
 * Extends jsonLogic with custom operations used by the instrument framework for handling branching logic.
 */
function extendJsonLogic() {
    /**
     * Custom operation for returning default.
     */
    json_logic_js_1.default.add_operation('any', () => true);
    /**
     * Custom operation for checking if an array includes any of the elements in another array.
     */
    json_logic_js_1.default.add_operation('includes_any', (a, b) => toArray(b).some((item) => toArray(a).includes(item)));
    /**
     * Custom operation for checking if an array includes all of the elements in another array.
     */
    json_logic_js_1.default.add_operation('includes_all', (a, b) => toArray(b).every((item) => toArray(a).includes(item)));
    /**
     * Custom operation for checking if an array does not include any of the items in another array.
     */
    json_logic_js_1.default.add_operation('includes_none_of', (a, b) => toArray(b).every((item) => !toArray(a).includes(item)));
}

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_navigation~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useNavigation = exports.Position = void 0;
const json_logic_js_1 = __importDefault(require("json-logic-js"));
const react_1 = require("react");
const templates_instruments_framework_json_logic_1_0_1 = require("templates.instruments.framework.json_logic~1_0");
/** Alternative to Promise.withResolvers() since that is only available in es2024. */
function promiseWithResolvers() {
    let res = () => { };
    let rej = () => { };
    const promise = new Promise((resolve, reject) => {
        res = resolve;
        rej = reject;
    });
    return { promise, resolve: res, reject: rej };
}
var Position;
(function (Position) {
    Position[Position["start"] = 0] = "start";
    Position[Position["middle"] = 1] = "middle";
    Position[Position["end"] = 2] = "end";
})(Position || (exports.Position = Position = {}));
// Add custom operations to jsonLogic for use in branching logic.
(0, templates_instruments_framework_json_logic_1_0_1.extendJsonLogic)();
/**
 * Custom hook for managing navigation between steps.
 *
 * @param steps - Object containing all steps in the instrument.
 * @param api - API object for tracking step events. Using as a parameter for now until we have a real singleton API
 *     object.
 * @param initialStep - Optional initial step ID to start at.
 * @param displayLogicData - Object containing display logic data for the instrument, or undefined if that object is not
 *     yet available.
 * @param displayLogicConfig - Object containing display logic configuration for the instrument.
 */
const useNavigation = (steps, api, initialStep, displayLogicData, displayLogicConfig, variablesData, variablesConfig) => {
    var _a;
    // The order of steps in the instrument definition.
    const originalStepOrder = Object.keys(steps);
    // The order of steps in the instrument definition, but filtered to exclude any steps that should be hidden due to
    // display logic. Initially it will be the same as originalStepOrder, but will be updated if/when displayLogicData
    // becomes available.
    const stepOrder = (0, react_1.useMemo)(() => displayLogicData ? originalStepOrder.filter((stepId) => { var _a; return !((_a = displayLogicData[stepId]) === null || _a === void 0 ? void 0 : _a.hide); }) : Object.keys(steps), [steps, displayLogicData]);
    // A map of step IDs to whether they are configured with display logic, meaning they to wait for displayLogicData to
    // be available before they can be navigated to.
    const stepsWithDisplayLogicConfig = (0, react_1.useMemo)(() => displayLogicConfig
        ? Object.keys(steps).reduce((acc, stepId) => {
            var _a;
            return (Object.assign(Object.assign({}, acc), {
                [stepId]: (_a = displayLogicConfig.sub_configurations) === null || _a === void 0 ? void 0 : _a.some((subconfig) => { var _a; return (_a = subconfig.dependent_screens) === null || _a === void 0 ? void 0 : _a.includes(stepId); }),
            }));
        }, {})
        : {}, [displayLogicConfig]);
    const getInitiallyDisplayedStep = (0, react_1.useCallback)((defaultInitialStep) => {
        var _a;
        if (displayLogicData === undefined) {
            // If display logic is not available, we need to show the initial step, it doesn't matter whether we're waiting
            // for the display logic to become available or if we already know from the config that the initial step can't
            // be hidden.
            return defaultInitialStep;
        }
        if ((_a = displayLogicData[defaultInitialStep]) === null || _a === void 0 ? void 0 : _a.hide) {
            // The initial step is supposed to be hidden by display logic, we need to display the next displayable step.
            return getNextDisplayableStep(defaultInitialStep, stepOrder);
        }
        // Turns out the initial step wasn't supposed to be hidden.
        return defaultInitialStep;
    }, [stepOrder]);
    // Id of the currently rendered step. This is the main state of the hook.
    const [currentStepId, setCurrentStepId] = (0, react_1.useState)(getInitiallyDisplayedStep(initialStep !== null && initialStep !== void 0 ? initialStep : stepOrder[0]));
    // Index of the currently rendered step in the stepOrder array.
    const currentStepIndex = Math.max(stepOrder.indexOf(currentStepId), 0);
    // Whether the navigation is currently transitioning between steps and the UI should be blocked, including if the
    // initial step might be hidden and we're waiting for display logic to be available. This has to be a state instead of
    // just calculated every time because it can also be changed when none of its dependencies change, i.e. when we try to
    // navigate to a new step and display logic isn't available yet.
    const [isTransitioning, setIsTransitioning] = (0, react_1.useState)(
    // If the initial step needs display logic and it's not available yet, we need to be in a transition state.
    (stepsWithDisplayLogicConfig[initialStep !== null && initialStep !== void 0 ? initialStep : stepOrder[0]] && displayLogicData === undefined) ||
        // If the initial step needs variables and they're not available yet, we need to be in a transition state.
        ((initialStep !== null && initialStep !== void 0 ? initialStep : stepOrder[0]) in ((_a = variablesConfig === null || variablesConfig === void 0 ? void 0 : variablesConfig.variable_screen_map) !== null && _a !== void 0 ? _a : {}) && variablesData === undefined));
    // Array representing the current history stack. Doesn't include the initial step if we started in a transition state.
    const history = (0, react_1.useRef)(isTransitioning ? [] : [currentStepId]);
    // When display logic and variables data becomes available:
    (0, react_1.useEffect)(() => {
        var _a;
        if (displayLogicData === undefined || variablesData === undefined) {
            return;
        }
        if (history.current.length === 0) {
            // History is empty, meaning we were waiting to unblock the initial screen.
            const newInitialStepId = getInitiallyDisplayedStep(currentStepId);
            setCurrentStepId(newInitialStepId);
            history.current.push(newInitialStepId);
            setIsTransitioning(false);
        }
        // Complete any pending navigation request. Need to pass in the new stepOrder because when the callback was created,
        // displayLogicData wasn't available yet, meaning that closure's stepOrder included steps that should be hidden now.
        (_a = resolveNavigationRef.current) === null || _a === void 0 ? void 0 : _a.call(resolveNavigationRef, stepOrder);
    }, [displayLogicData, variablesData]);
    /**
     * @param stepId Id of the step to start checking at.
     * @param newStepOrder The step order with only displayable steps.
     * @param backwards Whether to look for the previous displayable step instead of the next one.
     * @returns The given step id if it's displayable, or the next displayable step id if it isn't.
     */
    function getNextDisplayableStep(stepId, newStepOrder, backwards = false) {
        let newStepIndex = newStepOrder.indexOf(stepId);
        if (newStepIndex === -1) {
            const newStepOriginalIndex = originalStepOrder.indexOf(stepId);
            if (newStepOriginalIndex !== -1) {
                // The step we're trying to get isn't in the stepOrder because it got removed by display logic. Check
                // originalStepOrder to see what the next displayable step is.
                const stepsToCheck = backwards
                    ? originalStepOrder.slice(0, newStepOriginalIndex + 1).reverse()
                    : originalStepOrder.slice(newStepOriginalIndex);
                const newStepId = stepsToCheck.find((id) => newStepOrder.includes(id));
                newStepIndex = newStepId ? newStepOrder.indexOf(newStepId) : -1;
            }
        }
        if (newStepIndex === -1) {
            throw new Error(`Can't find a displayable step at or after ${stepId}`);
        }
        return newStepOrder[newStepIndex];
    }
    // Ref to a callback to complete navigation after display logic becomes available. The new stepOrder (with only
    // displayable steps) needs to be passed in because the callback gets created before display logic was available,
    // meaninig that closure's stepOrder included steps that should be hidden.
    const resolveNavigationRef = (0, react_1.useRef)(null);
    /**
     * Navigate to a specific step.
     *
     * @param stepId - The ID of the step to navigate to.
     * @throws An error if the specified step ID is not found in `stepOrder`.
     */
    const navigate = (stepId) => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        if ((displayLogicData !== undefined || !stepsWithDisplayLogicConfig[stepId]) &&
            (variablesData !== undefined || !((_a = variablesConfig === null || variablesConfig === void 0 ? void 0 : variablesConfig.variable_screen_map) === null || _a === void 0 ? void 0 : _a[stepId]))) {
            // If display logic and variable data are available or not needed for the target step, navigate immediately.
            const newStepId = getNextDisplayableStep(stepId, stepOrder);
            history.current.push(newStepId); // Add next screen to the stack
            setCurrentStepId(newStepId);
        }
        else {
            // If display logic or variable data are not available, we need to wait for them to become available before we can
            // navigate.
            setIsTransitioning(true);
            const { promise, resolve } = promiseWithResolvers();
            resolveNavigationRef.current = resolve;
            promise.then((newStepOrder) => {
                const newStepId = getNextDisplayableStep(stepId, newStepOrder);
                history.current.push(newStepId); // Add next screen to the stack
                setCurrentStepId(newStepId);
                resolveNavigationRef.current = null;
                setIsTransitioning(false);
            });
        }
    });
    /**
     * Navigate to the next step in the `stepOrder` array.
     * Also tracks a "next" step event using the provided `api` object.
     */
    const next = () => {
        const newStepIndex = currentStepIndex + 1;
        navigate(stepOrder[newStepIndex]);
        api.trackStepEvent('next', currentStepId);
    };
    /**
     * Creates a function that navigates to the next step according to the branching rules.
     *
     * @param stepId - Id of the step from which we're navigating and the branching rules are being evaluated.
     * @param answers - Answers object for evaluating branching conditions.
     * TODO: Revert answers' type to Answers once multi-question step changes are merged from custom to product.
     */
    const createNextCallback = ({ stepId = currentStepId, answers, variables, }) => () => {
        var _a;
        const { transition } = steps[stepId].definition;
        if ((_a = transition === null || transition === void 0 ? void 0 : transition.conditions) === null || _a === void 0 ? void 0 : _a.length) {
            const match = transition.conditions.find(({ condition }) => json_logic_js_1.default.apply(condition, { answers, variables }));
            if (match) {
                if (match.destination === '_NEXT_') {
                    return next();
                }
                if (match.destination === '_EXIT_') {
                    return api.cancel('branching');
                }
                navigate(match.destination);
                api.trackStepEvent('next', currentStepId);
                return;
            }
        }
        if (transition === null || transition === void 0 ? void 0 : transition.default) {
            if (transition.default === '_NEXT_') {
                return next();
            }
            if (transition.default === '_EXIT_') {
                return api.cancel('branching');
            }
            navigate(transition.default);
            api.trackStepEvent('next', currentStepId);
            return;
        }
        next();
    };
    /**
     * Navigate to the previous step in the `stepOrder` array.
     * Also tracks a "back" step event using the provided `api` object.
     * @throws An error if there are no previous steps in the navigation history.
     */
    const back = () => {
        // If there's nothing in the history, we should just go back to the previous step in the stepOrder and reset history.
        // If there's no step before the current one, then we should throw an error.
        if (history.current.length > 1) {
            history.current.pop(); // Remove current screen from stack
            const previousScreen = history.current[history.current.length - 1];
            const newStepIndex = stepOrder.indexOf(previousScreen);
            if (newStepIndex === -1) {
                throw new Error(`Can't find step ${previousScreen}`);
            }
            setCurrentStepId(previousScreen);
            api.trackStepEvent('back', currentStepId);
            return;
        }
        const newStepIndex = currentStepIndex - 1;
        if (newStepIndex < 0) {
            throw new Error("Can't navigate before the first step");
        }
        // Normally there's no back button if you're on the first step (meaning the history is length 1). You only reach
        // this code if the initial step isn't the first step in the instrument (e.g. live preview). Since this isn't a
        // patient flow, there won't be any display logic data anyway, so we don't bother with the transition state.
        const newStepId = getNextDisplayableStep(stepOrder[newStepIndex], stepOrder, /* backwards = */ true);
        setCurrentStepId(newStepId);
        history.current = [newStepId];
        api.trackStepEvent('back', currentStepId);
    };
    /**
     * Edit a specific step in history. Goes back in history to that step rather than navigating to it, which adds that
     * step to the history stack.
     *
     * @param stepId - The ID of the step to edit.
     * @throws An error if the specified step ID is not found in history.
     */
    const edit = (stepId) => {
        const historyIndex = history.current.indexOf(stepId);
        if (historyIndex === -1) {
            throw new Error(`Can't find step ${stepId} to edit in history`);
        }
        history.current.splice(historyIndex + 1); // Remove from stack all screens that came after this one
        setCurrentStepId(stepId);
        api.trackStepEvent('edit', stepId);
    };
    return {
        /**
         * The position of the current step in the navigation flow.
         * Can be "start", "middle", or "end".
         */
        position: currentStepIndex === 0
            ? Position.start
            : currentStepIndex === stepOrder.length - 1
                ? Position.end
                : Position.middle,
        /**
         * The ID of the current step.
         */
        currentStepId,
        /**
         * The sequence of step ids visited so far.
         */
        history: history.current,
        /**
         * Function for navigating to a specific step.
         */
        edit,
        /**
         * Function for creating the next function with branching logic.
         */
        createNextCallback,
        /**
         * Function for navigating to the previous step.
         */
        back,
        /**
         * Whether the navigation is currently transitioning between steps and the UI should be blocked.
         */
        isTransitioning,
    };
};
exports.useNavigation = useNavigation;

    return exports;
})();

__modules['strings.product.events.no_events~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"No event(s) reported";

    return exports;
})();

__modules['templates.placeholder~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.replacePlaceholders = replacePlaceholders;
function replacePlaceholders(template, getPlaceholderValue) {
    var _a;
    return (_a = template === null || template === void 0 ? void 0 : template.replace(/\{([^}]+)\}/g, (_, key) => getPlaceholderValue(key))) !== null && _a !== void 0 ? _a : '';
}

    return exports;
})();

__modules['templates.instruments.framework.hooks.use_placeholders~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usePlaceholders = usePlaceholders;
const strings_product_events_no_events_r0_1 = __importDefault(require("strings.product.events.no_events~r0"));
const templates_instruments_framework_variables_1_0_1 = require("templates.instruments.framework.variables~1_0");
const templates_placeholder_1_0_1 = require("templates.placeholder~1_0");
function usePlaceholders(variables) {
    function replaceWithVariables(content) {
        return (0, templates_placeholder_1_0_1.replacePlaceholders)(content, (name) => {
            var _a, _b;
            const variable = variables[name];
            return (0, templates_instruments_framework_variables_1_0_1.isSingleVariable)(variable)
                ? ((_b = (_a = variable.localizedDisplay) !== null && _a !== void 0 ? _a : variable.display) !== null && _b !== void 0 ? _b : `{${name}}`)
                : (0, templates_instruments_framework_variables_1_0_1.isVariableArray)(variable)
                    ? getVariableArrayLocalizedDisplay(variable)
                    : `{${name}}`;
        });
    }
    return { replacePlaceholders: replaceWithVariables };
}
function getVariableArrayLocalizedDisplay(variableArray) {
    const displays = variableArray
        .map((variable) => { var _a; return (_a = variable.localizedDisplay) !== null && _a !== void 0 ? _a : variable.display; })
        .filter((display) => !!display);
    return displays.length === 0
        ? (0, strings_product_events_no_events_r0_1.default)()
        : `<ul>` + displays.map((display) => `<li>${display}</li>`).join('') + `</ul>`;
}

    return exports;
})();

__modules['templates.instruments.framework.app~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const strings_product_button_back_r0_1 = __importDefault(require("strings.product.button_back~r0"));
const strings_product_button_next_r0_1 = __importDefault(require("strings.product.button_next~r0"));
const strings_product_button_submit_r0_1 = __importDefault(require("strings.product.button_submit~r0"));
const strings_product_cancel_dialog_content_r0_1 = __importDefault(require("strings.product.cancel_dialog.content~r0"));
const strings_product_cancel_dialog_no_label_r0_1 = __importDefault(require("strings.product.cancel_dialog.no_label~r0"));
const strings_product_cancel_dialog_title_r0_1 = __importDefault(require("strings.product.cancel_dialog.title~r0"));
const strings_product_cancel_dialog_yes_label_r0_1 = __importDefault(require("strings.product.cancel_dialog.yes_label~r0"));
const strings_product_hint_scroll_down_r0_1 = __importDefault(require("strings.product.hint.scroll_down~r0"));
const strings_product_link_cancel_r0_1 = __importDefault(require("strings.product.link_cancel~r0"));
const strings_product_skip_dialog_content_r0_1 = __importDefault(require("strings.product.skip_dialog.content~r0"));
const strings_product_skip_dialog_no_label_r0_1 = __importDefault(require("strings.product.skip_dialog.no_label~r0"));
const strings_product_skip_dialog_title_r0_1 = __importDefault(require("strings.product.skip_dialog.title~r0"));
const strings_product_skip_dialog_yes_label_r0_1 = __importDefault(require("strings.product.skip_dialog.yes_label~r0"));
const styled_components_1 = __importDefault(require("styled-components"));
const templates_debounce_1_0_1 = require("templates.debounce~1_0");
const templates_instruments_framework_client_api_1_0_1 = __importDefault(require("templates.instruments.framework.client_api~1_0"));
const templates_instruments_framework_components_button_1_0_1 = __importDefault(require("templates.instruments.framework.components.button~1_0"));
const templates_instruments_framework_components_colors_1_0_1 = require("templates.instruments.framework.components.colors~1_0");
const templates_instruments_framework_components_confirm_dialog_2_0_1 = __importDefault(require("templates.instruments.framework.components.confirm_dialog~2_0"));
const templates_instruments_framework_components_link_1_0_1 = __importDefault(require("templates.instruments.framework.components.link~1_0"));
const templates_instruments_framework_components_spinner_1_0_1 = __importDefault(require("templates.instruments.framework.components.spinner~1_0"));
const templates_instruments_framework_hooks_use_all_variables_1_0_1 = require("templates.instruments.framework.hooks.use_all_variables~1_0");
const templates_instruments_framework_hooks_use_answers_2_0_1 = require("templates.instruments.framework.hooks.use_answers~2_0");
const templates_instruments_framework_hooks_use_customization_data_1_0_1 = require("templates.instruments.framework.hooks.use_customization_data~1_0");
const templates_instruments_framework_hooks_use_event_1_0_1 = require("templates.instruments.framework.hooks.use_event~1_0");
const templates_instruments_framework_hooks_use_navigation_1_0_1 = require("templates.instruments.framework.hooks.use_navigation~1_0");
const templates_instruments_framework_hooks_use_placeholders_1_0_1 = require("templates.instruments.framework.hooks.use_placeholders~1_0");
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
const ContainerDiv = styled_components_1.default.div `
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  font:
    16px Arial,
    Helvetica,
    sans-serif;
  line-height: normal;
`;
const Header = styled_components_1.default.div `
  display: flex;
  justify-content: end;
  align-items: center;
  height: 48px;
  flex-shrink: 0;
  padding: 0 16px;
`;
const Body = styled_components_1.default.main `
  display: flex;
  flex-grow: 1;
  padding: 16px;
  outline: 0;
  margin: 0 auto;
  ${({ $wide }) => ($wide ? '' : 'max-width: 600px;')}
  width: 100%;
  box-sizing: border-box;
  ${({ $compactMode }) => ($compactMode ? 'font-size: 12px;' : '')}

  & > * {
    flex-grow: 1; // Children should take up the whole width...
    max-width: 100%; // ...but not exceed the whole width.
  }
`;
const Footer = styled_components_1.default.div `
  display: flex;
  flex-direction: row;
  border-top: 1px solid ${templates_instruments_framework_components_colors_1_0_1.Colors.border};
  padding: 8px;
  justify-content: center;

  & > :only-child {
    max-width: 500px; // One button
  }

  & > :not(:only-child) {
    max-width: 400px; // Two buttons
  }
`;
const ScrollHintContainer = styled_components_1.default.div `
  position: fixed;
  bottom: 0;
  display: flex;
  width: 100%;
  background: linear-gradient(180deg, #fff0 0%, #fffffff5 38.31%, #fff 100%);
  pointer-events: none;
  ${({ $show }) => $show
    ? `
        visibility: visible;
        opacity: 1;
        transition: opacity .2s linear;
      `
    : `
        visibility: hidden;
        opacity: 0;
        transition: visibility 0s .2s, opacity .2s linear;
  `}
`;
const ScrollHint = styled_components_1.default.div `
  font-size: 12px;
  line-height: 18px;
  padding: 7px 16px;
  border-radius: 20px;
  margin: 20px auto;
  background: #f1f2f3;
  box-shadow: 0px 4px 6px -1px #0000001a;
`;
const api = new templates_instruments_framework_client_api_1_0_1.default();
function getScrollTop(appContainer) {
    var _a, _b, _c;
    // App's parent is react root, react root's parent is body. In an instrument loaded on the test server, the body is
    // the element whose content scrolls. But in live preview it's gonna be different and might not work. So we check
    // the app container and it's two direct ancestors to see if any are scrolled.
    // TODO: Need to try this in patient app.
    return (appContainer.scrollTop ||
        ((_a = appContainer.parentElement) === null || _a === void 0 ? void 0 : _a.scrollTop) ||
        ((_c = (_b = appContainer.parentElement) === null || _b === void 0 ? void 0 : _b.parentElement) === null || _c === void 0 ? void 0 : _c.scrollTop) ||
        0);
}
function setScrollTopToZero(appContainer) {
    var _a;
    // App's parent is react root, react root's parent is body. In an instrument loaded on the test server, the body is
    // the element whose content scrolls. But in live preview it's gonna be different and might not work. So we check
    // the app container and it's two direct ancestors to see if any are scrolled.
    // TODO: Need to try this in patient app.
    if (appContainer.scrollTop !== 0) {
        appContainer.scrollTop = 0;
    }
    else if (appContainer.parentElement && appContainer.parentElement.scrollTop !== 0) {
        appContainer.parentElement.scrollTop = 0;
    }
    else if (((_a = appContainer.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement) && appContainer.parentElement.parentElement.scrollTop !== 0) {
        appContainer.parentElement.parentElement.scrollTop = 0;
    }
}
// TODO: extract this to its own template or local class
const FocusManager = ({ stepId, children: renderChildren }) => {
    const initialFocusRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(() => {
        var _a;
        const appContainer = initialFocusRef.current.parentElement;
        setScrollTopToZero(appContainer);
        (_a = initialFocusRef.current) === null || _a === void 0 ? void 0 : _a.focus({ preventScroll: true });
        api.trackStepEvent('enter', stepId);
    }, [stepId]);
    return renderChildren(initialFocusRef);
};
// TODO: extract this to libs.react.utils
const If = ({ condition, children }) => {
    return condition ? children : null;
};
// TODO: extract this to libs.react.utils
const With = ({ expression, children }) => {
    return children(expression);
};
const CancelLink = ({ appContainerRef }) => {
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = (0, react_1.useState)(false);
    const handleClick = () => setIsConfirmDialogOpen(true);
    const handleClose = (isConfirmed) => isConfirmed && api.cancel();
    const closeDialog = () => setIsConfirmDialogOpen(false);
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(templates_instruments_framework_components_link_1_0_1.default, { label: (0, strings_product_link_cancel_r0_1.default)(), onClick: handleClick }), (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_confirm_dialog_2_0_1.default, { isOpen: isConfirmDialogOpen, title: (0, strings_product_cancel_dialog_title_r0_1.default)(), content: (0, strings_product_cancel_dialog_content_r0_1.default)(), yesLabel: (0, strings_product_cancel_dialog_yes_label_r0_1.default)(), noLabel: (0, strings_product_cancel_dialog_no_label_r0_1.default)(), onClose: handleClose, closeDialog: closeDialog, containerRef: appContainerRef })] }));
};
const NextButton = ({ currentStepId, currentStep, currentAnswer, answers, onClick, position, disabled, appContainerRef, }) => {
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = (0, react_1.useState)(false);
    const isComplete = currentStep.isComplete
        ? currentStep.isComplete(answers)
        : currentAnswer !== undefined || answers[currentStepId] === 'unable_to_answer';
    const handleClick = () => {
        if ((0, templates_instruments_framework_step_api_2_0_1.isQuestionStep)(currentStep.definition) && currentStep.definition.skippable && !isComplete) {
            setIsConfirmDialogOpen(true);
        }
        else {
            onClick();
        }
    };
    const handleConfirmationClose = (isConfirmed) => {
        if (isConfirmed) {
            api.trackStepEvent('skip', currentStepId);
            onClick();
        }
    };
    const closeDialog = () => setIsConfirmDialogOpen(false);
    const buttonLabel = position !== templates_instruments_framework_hooks_use_navigation_1_0_1.Position.end ? (0, strings_product_button_next_r0_1.default)() : (0, strings_product_button_submit_r0_1.default)();
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.primary, { label: buttonLabel, disabled: disabled, onClick: handleClick }), (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_confirm_dialog_2_0_1.default, { isOpen: isConfirmDialogOpen, title: (0, strings_product_skip_dialog_title_r0_1.default)(), content: (0, strings_product_skip_dialog_content_r0_1.default)(), yesLabel: (0, strings_product_skip_dialog_yes_label_r0_1.default)(), noLabel: (0, strings_product_skip_dialog_no_label_r0_1.default)(), onClose: handleConfirmationClose, closeDialog: closeDialog, containerRef: appContainerRef })] }));
};
function getUrlParam(name) {
    if (typeof window !== 'undefined' && window.INSTRUMENT_STEP) {
        return window.INSTRUMENT_STEP;
    }
    return new URLSearchParams(window.location.search).getAll(name).pop();
}
function submitAnswers(steps, historicAnswers) {
    // historicAnswers excludes screens not reached due to branching and ensures the correct order. Any screens with an
    // undefined answer must have been skipped by the user, and any screens not in historicAnswers at all must have been
    // skipped due to branching.
    const createTaskResponse = (id) => {
        const oldAnswer = historicAnswers[id];
        return !oldAnswer
            ? { stepId: id, status: id in historicAnswers ? 'skipped' : 'branched' }
            : (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(oldAnswer)
                ? (0, templates_instruments_framework_step_api_2_0_1.isNumericAnswer)(oldAnswer)
                    ? Object.assign({ stepId: id, status: 'answered', value: oldAnswer.value, original_value: oldAnswer.text }, (oldAnswer.unit ? { unit: oldAnswer.unit, metadata: { original_unit: oldAnswer.localizedUnit } } : {})) : {
                    stepId: id,
                    status: 'answered',
                    value: oldAnswer.value,
                    original_value: oldAnswer.text,
                }
                : oldAnswer === 'unable_to_answer'
                    ? { stepId: id, status: oldAnswer, reason: steps[id].definition.unable_to_answer_value }
                    : { stepId: id, status: oldAnswer };
    };
    const responses = Object.keys(steps)
        // Only include question steps in the sbmitted data.
        .filter((stepId) => (0, templates_instruments_framework_step_api_2_0_1.isQuestionStep)(steps[stepId].definition))
        .flatMap((stepId) => steps[stepId].getQuestionIds
        ? steps[stepId].getQuestionIds().map((questionId) => createTaskResponse(questionId))
        : createTaskResponse(stepId));
    api.submit(responses);
}
const Instrument = ({ steps: stepFactories, step = getUrlParam('step'), configuration }) => {
    var _a;
    const steps = (0, react_1.useMemo)(() => Object.entries(stepFactories).reduce((acc, [stepId, stepFactory]) => (Object.assign(Object.assign({}, acc), { 
        // Adds the stepId to the definition so that the step can know its own ID.
        [stepId]: stepFactory.getStepBuilder(stepId) })), {}), [stepFactories]);
    const { displayLogicData, variablesData } = (0, templates_instruments_framework_hooks_use_customization_data_1_0_1.useCustomizationData)(configuration, api);
    const { currentStepId, edit, back, createNextCallback, position, history, isTransitioning } = (0, templates_instruments_framework_hooks_use_navigation_1_0_1.useNavigation)(steps, api, step, displayLogicData, configuration === null || configuration === void 0 ? void 0 : configuration.display_logic, variablesData, configuration === null || configuration === void 0 ? void 0 : configuration.variables_config);
    const { answers, currentAnswer, updateAnswer, updateAnswers } = (0, templates_instruments_framework_hooks_use_answers_2_0_1.useAnswers)(currentStepId, api);
    const [disableNavigation, setDisableNavigation] = (0, react_1.useState)(false);
    const [showScrollHint, setShowScrollHint] = (0, react_1.useState)(false);
    const [compactMode, setCompactMode] = (0, react_1.useState)(false);
    // Object with all steps in current history stack.
    const historicSteps = (0, react_1.useMemo)(() => history.reduce((acc, stepId) => (Object.assign(Object.assign({}, acc), { [stepId]: steps[stepId] })), {}), 
    // Simply naming history as a dependency here doesn't work because the array is always the same array, just the
    // elements inside it change. Checking the length is sufficient because whenever the history tree changes it's
    // always from adding or removing, never from changing an item in place.
    [history.length]);
    // Object with all answers in current history stack.
    const historicAnswers = (0, react_1.useMemo)(() => {
        // Iterating through the history avoids screens that weren't asked due to not matching branching rules, even
        // if at first they matched and the user answered them, but then they went back and changed something that
        // caused those screens to no longer match. Also, it ensures the answers are in the right order.
        return history.reduce((acc, stepId) => (Object.assign(Object.assign({}, acc), ((0, templates_instruments_framework_step_api_2_0_1.isQuestionStep)(steps[stepId].definition)
            ? steps[stepId].getQuestionIds
                ? steps[stepId].getQuestionIds().reduce((acc, questionId) => (Object.assign(Object.assign({}, acc), (questionId in answers ? { [questionId]: answers[questionId] } : {}))), {})
                : { [stepId]: answers[stepId] }
            : {}))), {});
    }, 
    // Simply naming history as a dependency here doesn't work because the array is always the same array, just the
    // elements inside it change. Checking the length is sufficient because whenever the history tree changes it's
    // always from adding or removing, never from changing an item in place.
    [answers, history.length]);
    const { allVariables } = (0, templates_instruments_framework_hooks_use_all_variables_1_0_1.useAllVariables)(historicAnswers, variablesData, configuration === null || configuration === void 0 ? void 0 : configuration.variables_config);
    const handleDone = () => submitAnswers(steps, historicAnswers);
    const { replacePlaceholders } = (0, templates_instruments_framework_hooks_use_placeholders_1_0_1.usePlaceholders)(allVariables);
    const currentStep = steps[currentStepId];
    const isComplete = currentStep.isComplete ? currentStep.isComplete(historicAnswers) : currentAnswer !== undefined;
    const isValid = currentStep.isValid ? currentStep.isValid(historicAnswers) : true;
    const disableBack = disableNavigation || !isValid;
    const disableNext = disableNavigation || !isValid || (((_a = currentStep.definition.mandatoryAnswer) !== null && _a !== void 0 ? _a : false) && !isComplete);
    function handleClickOnBack() {
        return __awaiter(this, void 0, void 0, function* () {
            const navigate = currentStep.onBeforeNavigate
                ? yield currentStep.onBeforeNavigate(historicAnswers, openDialog, { variables: allVariables })
                : true;
            if (navigate) {
                back();
            }
        });
    }
    const { isDuplicateEvent, duplicateEventDialogOptions } = (0, templates_instruments_framework_hooks_use_event_1_0_1.useEvent)(configuration, historicAnswers, variablesData, currentStepId, position === templates_instruments_framework_hooks_use_navigation_1_0_1.Position.end);
    function handleClickOnNext() {
        return __awaiter(this, void 0, void 0, function* () {
            const navigate = currentStep.onBeforeNavigate
                ? yield currentStep.onBeforeNavigate(historicAnswers, openDialog, { variables: allVariables })
                : true;
            if (navigate) {
                if (isDuplicateEvent()) {
                    yield openDialog(duplicateEventDialogOptions);
                }
                else {
                    if (position === templates_instruments_framework_hooks_use_navigation_1_0_1.Position.end) {
                        handleDone();
                    }
                    else {
                        createNextCallback({
                            stepId: currentStepId,
                            answers: historicAnswers,
                            variables: allVariables,
                        })();
                    }
                }
            }
        });
    }
    const appContainerRef = (0, react_1.useRef)(null);
    // Use refs for values that area accessed during event handling so that the handler functions that are bound during
    // initial render can get the latest values when they are triggered.
    const compactModeRef = (0, react_1.useRef)(compactMode);
    const originalScrollHeightRef = (0, react_1.useRef)(0);
    const isNoScrollRef = (0, react_1.useRef)(!!currentStep.definition.no_scroll);
    (0, react_1.useEffect)(() => {
        // Reset compact mode, scroll height and no scroll whenever you navigate to a new step.
        setCompactMode(false);
        compactModeRef.current = false;
        originalScrollHeightRef.current = 0;
        isNoScrollRef.current = !!currentStep.definition.no_scroll;
    }, 
    // For this to work on live preview, also trigger whenever the user edits the step definition.
    [currentStepId, currentStep.definition]);
    (0, react_1.useEffect)(() => {
        // Check if compact mode needed when rendering a new step (or after rendering a new step in compact mode and then
        // resetting compact mode in the useEffect above). (It will also be checked on resize via event handlers below.)
        checkIfNeedsCompactMode();
        // Check if scroll hint needed whenever navigating to a new step or changing compact mode. (It will also be checked
        // on resize and scroll via event handlers below.)
        checkIfNeedsScrollHint();
    }, 
    // For this to work on live preview, also trigger whenever the user edits the step definition.
    [currentStepId, compactMode, currentStep.definition]);
    (0, react_1.useEffect)(() => {
        // Register the resize and scroll handlers only on initial render.
        const resizeOrLoadHandler = (0, templates_debounce_1_0_1.debounce)(() => {
            checkIfNeedsCompactMode();
            checkIfNeedsScrollHint();
        }, 100);
        const scrollHandler = (0, templates_debounce_1_0_1.debounce)(checkIfNeedsScrollHint, 50);
        // These won't trigger on live preview since the instrument is not directly in the window. For scroll we can listen
        // on the app container's parent, but for resize the live preview component will have to be rerendered.
        window.addEventListener('resize', resizeOrLoadHandler);
        window.addEventListener('scroll', scrollHandler);
        appContainerRef.current.addEventListener('load', resizeOrLoadHandler, { capture: true });
        // In live preview, scroll events happen on the parent element. In the real instrument this will never trigger.
        const scrollParent = appContainerRef.current.parentElement;
        scrollParent.addEventListener('scroll', scrollHandler);
        return () => {
            var _a;
            window.removeEventListener('resize', resizeOrLoadHandler);
            window.removeEventListener('scroll', scrollHandler);
            (_a = appContainerRef.current) === null || _a === void 0 ? void 0 : _a.removeEventListener('load', resizeOrLoadHandler, { capture: true });
            scrollParent.removeEventListener('scroll', scrollHandler);
            resizeOrLoadHandler.cancel();
            scrollHandler.cancel();
        };
    }, []);
    function checkIfNeedsCompactMode() {
        // Re-measure scroll height only if in normal mode. When in compact mode we "remember" the last height measured in
        // normal mode.
        if (!compactModeRef.current) {
            originalScrollHeightRef.current = appContainerRef.current.scrollHeight;
        }
        const appContainer = appContainerRef.current;
        const isOriginalContentOverflowing = originalScrollHeightRef.current > appContainer.offsetHeight;
        // Use a ref here because when this function is called as a result of a resize event, we need to get the latest
        // value of no scroll, i.e. for the current step, not the step we were on when the event handler was registgered.
        setCompactMode(isNoScrollRef.current && isOriginalContentOverflowing);
        compactModeRef.current = isNoScrollRef.current && isOriginalContentOverflowing;
    }
    function checkIfNeedsScrollHint() {
        const appContainer = appContainerRef.current;
        const scrollTop = getScrollTop(appContainer);
        const isOverflowing = appContainer.scrollHeight > appContainer.offsetHeight;
        const overflowAmount = appContainer.scrollHeight - appContainer.offsetHeight;
        // Even though you've scrolled as far down as you can, sometimes scrollTop doesn't quite get to the same amount as
        // overflowAmount (e.g. 44.5 instead of 45). So we give it a 3px margin of error, meaning the hint disappears about
        // 3px before you get to the bottom. It's just empty margin that you're missing out on.
        setShowScrollHint(isOverflowing && scrollTop < overflowAmount - 3);
    }
    const [dialogPortal, setDialogPortal] = (0, react_1.useState)(null);
    function openDialog({ title, content, yesLabel, noLabel, }) {
        return new Promise((resolve) => {
            const onClose = (answer) => resolve(answer);
            const closeDialog = () => setDialogPortal(null);
            setDialogPortal(((0, jsx_runtime_1.jsx)(templates_instruments_framework_components_confirm_dialog_2_0_1.default, { isOpen: true, title: title, content: content, yesLabel: yesLabel, noLabel: noLabel, onClose: onClose, closeDialog: closeDialog, containerRef: appContainerRef, fullWidth: !!currentStep.definition.full_width })));
        });
    }
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(FocusManager, { stepId: currentStepId, children: (initialFocusRef) => ((0, jsx_runtime_1.jsx)(With, { expression: steps[currentStepId], children: (currentStep) => ((0, jsx_runtime_1.jsxs)(ContainerDiv, { ref: appContainerRef, "aria-busy": isTransitioning, inert: isTransitioning ? '' : undefined, children: [(0, jsx_runtime_1.jsx)(Header, { children: (0, jsx_runtime_1.jsx)(CancelLink, { appContainerRef: appContainerRef }) }), (0, jsx_runtime_1.jsx)(Body, { ref: initialFocusRef, tabIndex: -1, "$compactMode": compactMode, "$wide": !!currentStep.definition.full_width, children: currentStep.build({
                                    id: currentStepId,
                                    steps: historicSteps, // Only used by review step.
                                    answer: (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(currentAnswer) ? currentAnswer : undefined,
                                    answers: historicAnswers,
                                    updateAnswer,
                                    updateAnswers,
                                    updateDisableNavigation: setDisableNavigation,
                                    edit,
                                    variables: allVariables,
                                    replacePlaceholders,
                                    compactMode,
                                }) }, currentStepId), (0, jsx_runtime_1.jsxs)(Footer, { children: [(0, jsx_runtime_1.jsx)(If, { condition: position !== templates_instruments_framework_hooks_use_navigation_1_0_1.Position.start, children: (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_button_1_0_1.default.secondary, { label: (0, strings_product_button_back_r0_1.default)(), disabled: disableBack, onClick: handleClickOnBack }) }), (0, jsx_runtime_1.jsx)(NextButton, { currentStepId: currentStepId, currentStep: currentStep, currentAnswer: (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(currentAnswer) ? currentAnswer : undefined, answers: historicAnswers, onClick: handleClickOnNext, position: position, disabled: disableNext, appContainerRef: appContainerRef })] }), (0, jsx_runtime_1.jsx)(ScrollHintContainer, { "$show": showScrollHint, children: (0, jsx_runtime_1.jsx)(ScrollHint, { "aria-hidden": true, children: (0, strings_product_hint_scroll_down_r0_1.default)() }) })] })) })) }), dialogPortal, isTransitioning && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_spinner_1_0_1.default, {})] }));
};
const Wrapper = (props) => (0, jsx_runtime_1.jsx)(Instrument, Object.assign({}, props));
exports.default = Wrapper;

    return exports;
})();

__modules['templates.instruments.framework.components.html_string~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const HtmlString = ({ value, tag: Tag = 'span', className, htmlFor, }) => {
    return ((0, jsx_runtime_1.jsx)(Tag, { className: className, htmlFor: htmlFor, dangerouslySetInnerHTML: {
            __html: value,
        } }));
};
exports.default = HtmlString;

    return exports;
})();

__modules['templates.instruments.framework.components.rich_content~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getContentAsRich = getContentAsRich;
const jsx_runtime_1 = require("react/jsx-runtime");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_html_string_1_0_1 = __importDefault(require("templates.instruments.framework.components.html_string~1_0"));
const StyledHtmlString = (0, styled_components_1.default)(templates_instruments_framework_components_html_string_1_0_1.default) `
  ${({ $alignment, $size }) => `
    text-align: ${$alignment === 'left' ? 'start' : $alignment === 'right' ? 'end' : 'center'};
    font-size: ${$size === 'small' ? '0.875em' : $size === 'large' ? '1.875em' : '1em'};
  `}
  width: 100%;

  & p {
    margin: 1.143em 0;

    &:first-child {
      margin-top: 0;
    }

    &:last-child {
      margin-bottom: 0;
    }
  }

  & img {
    display: block;
    margin: auto;
    max-width: 100%;
  }
`;
/**
 * Renders a block of rich content with a specific alignment and size. The content may contain text, images, and lists
 * as html tags.
 */
const RichContent = ({ content, alignment = 'left', size = 'regular', className }) => {
    return (content && (0, jsx_runtime_1.jsx)(StyledHtmlString, { className: className, tag: 'div', "$alignment": alignment, "$size": size, value: content }));
};
exports.default = RichContent;
/**
 * Takes in either a string or a RichContentProps object and returns a RichContentProps. If variables are provided, the
 * content will be interpolated with the referenced variable's display text.
 */
function getContentAsRich(content, replacePlaceholders) {
    if (content === undefined) {
        return undefined;
    }
    return (typeof content === 'string'
        ? { content: replacePlaceholders(content) }
        : {
            content: replacePlaceholders(content.content),
            alignment: content.alignment,
            size: content.size,
        });
}

    return exports;
})();

__modules['templates.instruments.framework.components.question_layout~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_rich_content_1_0_1 = __importDefault(require("templates.instruments.framework.components.rich_content~1_0"));
const Container = styled_components_1.default.div `
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  row-gap: 16px;
`;
const ChildrenContainer = styled_components_1.default.div `
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  row-gap: 16px;
`;
const QuestionLayout = ({ instruction, item_stem, item_specific_text, children, copyright }) => {
    return ((0, jsx_runtime_1.jsxs)(Container, { children: [instruction && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_rich_content_1_0_1.default, Object.assign({}, instruction)), (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_rich_content_1_0_1.default, Object.assign({}, item_stem)), item_specific_text && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_rich_content_1_0_1.default, Object.assign({}, item_specific_text)), (0, jsx_runtime_1.jsx)(ChildrenContainer, { children: children }), copyright && (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_rich_content_1_0_1.default, Object.assign({}, copyright))] }));
};
exports.default = QuestionLayout;

    return exports;
})();

__modules['templates.instruments.framework.components.select_item~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Variant = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_colors_1_0_1 = require("templates.instruments.framework.components.colors~1_0");
const templates_instruments_framework_components_html_string_1_0_1 = __importDefault(require("templates.instruments.framework.components.html_string~1_0"));
const SelectionItemInput = styled_components_1.default.input.attrs(({ $multiple }) => ({
    type: $multiple ? 'checkbox' : 'radio',
})) `
  -webkit-appearance: none;
  appearance: none;
  outline: none;
  position: absolute; // To allow margins of its neighbors to collapse.
`;
const SelectionItemLabel = styled_components_1.default.label `
  ${({ $horizontal, $centered, $topAligned, $selected, $disabled, $compactMode }) => `
    display: flex;
    ${$horizontal || $centered ? `justify-content: center;` : ''}
    ${$horizontal ? `flex: 1 1 0;` : ''}
    ${$horizontal ? `width: 0;` : ''}
    align-items: ${$topAligned ? 'flex-start' : 'center'};
    ${!$horizontal && $centered ? `text-align: center;` : ''}
    min-height: ${$compactMode ? 48 : 56}px;
    box-sizing: border-box;
    border: 1px solid ${templates_instruments_framework_components_colors_1_0_1.Colors.border};
    padding: 8px;
    border-radius: 4px;
    background-color: ${$selected ? templates_instruments_framework_components_colors_1_0_1.Colors.primary : templates_instruments_framework_components_colors_1_0_1.Colors.secondary};
    color: ${$selected ? 'white' : templates_instruments_framework_components_colors_1_0_1.Colors.text};

    ${$disabled
    ? `opacity: 0.5;`
    : `
          cursor: pointer;

          :focus-visible + & {
            outline-color: ${$selected ? 'black' : '-webkit-focus-ring-color'};
            outline-style: auto;
          }

          &:hover {
            background-color: ${$selected ? templates_instruments_framework_components_colors_1_0_1.Colors.primary_hover : templates_instruments_framework_components_colors_1_0_1.Colors.secondary_hover};
          }
        
          &:active {
            background-color: ${$selected ? templates_instruments_framework_components_colors_1_0_1.Colors.primary_active : templates_instruments_framework_components_colors_1_0_1.Colors.secondary_active};
          }
    `}

  `}
`;
const SelectionItemsContainer = styled_components_1.default.div `
  ${({ $horizontal, $compactMode, $wrap }) => `
    display: flex;
    ${$horizontal ? '' : 'flex-direction: column;'}
    ${$horizontal ? `column-gap: ${$wrap ? 8 : 2}px;` : `row-gap: ${$compactMode ? 4 : 16}px;`}
    ${$horizontal && $wrap ? 'row-gap: 8px;' : ''}
    ${$wrap ? 'flex-wrap: wrap;' : ''}
  `}
`;
var Variant;
(function (Variant) {
    Variant["horizontal"] = "horizontal";
    Variant["vertical"] = "vertical";
    Variant["horizontalWrapping"] = "horizontalWrapping";
})(Variant || (exports.Variant = Variant = {}));
const SelectItem = ({ variant, choices, areChoicesEqual, renderChoice, deselectable, centerLabels, topAlignLabels, disabled = false, multiple, value, onClick, compactMode, className, }) => {
    const inputName = `SSI-${(0, react_1.useId)()}`;
    return ((0, jsx_runtime_1.jsx)(SelectionItemsContainer, { className: className, "$horizontal": variant === Variant.horizontal || variant === Variant.horizontalWrapping, "$compactMode": !!compactMode, "$wrap": variant === Variant.horizontalWrapping, children: choices.map((choice, index) => {
            var _a, _b;
            const isSelected = multiple
                ? ((_a = value === null || value === void 0 ? void 0 : value.some((t) => { var _a; return (_a = areChoicesEqual === null || areChoicesEqual === void 0 ? void 0 : areChoicesEqual(t, choice)) !== null && _a !== void 0 ? _a : t === choice; })) !== null && _a !== void 0 ? _a : false)
                : value !== undefined && ((_b = areChoicesEqual === null || areChoicesEqual === void 0 ? void 0 : areChoicesEqual(choice, value)) !== null && _b !== void 0 ? _b : choice === value);
            // Single-select is implemented with radio buttons (as opposed to multi-select with checkboxes). Radio buttons
            // can't be deselected, but we're implementing an option to let them be deselected in order to support clearing
            // a VRS question when it's skippable. Normally since a radio can't be deselected, when you click on a selected
            // one it doesn't fire an onChange, so we have to check onClick and onKeyUp, but only if that radio is
            // deselectable and already selected.
            const isDeselectableRadio = !multiple && deselectable && isSelected;
            // Some browsers fire a click event when a selected radio is clicked, others don't. So we might get a click, we
            // might get a keyup, or we might get both. Use a flag to make sure we only call onClick once.
            let isDeselectOnClickCalled = false;
            const handleDeselectionEvent = (choice, index) => {
                if (!isDeselectOnClickCalled) {
                    isDeselectOnClickCalled = true;
                    // Calling onClick directly here can break things because if the parent component changes the state such
                    // that this radio gets deselected, that can happen before the browser translates the spacebar keyup into
                    // a click event. In that case the click event will then see the radio is deselected and reselect it. Using
                    // setTimeout lets the browser finish processing the keyup while the radio is still selected, not triggering
                    // a reselection.
                    setTimeout(() => onClick(choice, index));
                }
            };
            const choiceContent = renderChoice ? renderChoice(choice) : `${choice}`;
            return [
                (0, jsx_runtime_1.jsx)(SelectionItemInput, Object.assign({ "$multiple": multiple, name: inputName, id: `${inputName}-${index}`, checked: isSelected, disabled: disabled, onChange: () => onClick(choice, index) }, (isDeselectableRadio && {
                    onClick: () => handleDeselectionEvent(choice, index),
                    onKeyUp: (event) => event.key === ' ' && handleDeselectionEvent(choice, index),
                })), `input-${index}`),
                (0, jsx_runtime_1.jsx)(SelectionItemLabel, { htmlFor: `${inputName}-${index}`, "$selected": isSelected, "$disabled": disabled, "$horizontal": variant === Variant.horizontal, "$centered": variant === Variant.vertical && !!centerLabels, "$topAligned": !!topAlignLabels, "$compactMode": !!compactMode, children: typeof choiceContent === 'string' ? (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_html_string_1_0_1.default, { value: choiceContent }) : choiceContent }, `label-${index}`),
            ];
        }) }));
};
SelectItem.horizontal = (props) => props.multiple
    ? SelectItem(Object.assign(Object.assign({}, props), { multiple: true, value: props.value, variant: Variant.horizontal }))
    : SelectItem(Object.assign(Object.assign({}, props), { multiple: false, value: props.value, variant: Variant.horizontal, areChoicesEqual: undefined }));
SelectItem.horizontalWrapping = (props) => props.multiple
    ? SelectItem(Object.assign(Object.assign({}, props), { multiple: true, value: props.value, variant: Variant.horizontalWrapping }))
    : SelectItem(Object.assign(Object.assign({}, props), { multiple: false, value: props.value, variant: Variant.horizontalWrapping, areChoicesEqual: undefined }));
SelectItem.vertical = (props) => props.multiple
    ? SelectItem(Object.assign(Object.assign({}, props), { multiple: true, value: props.value, variant: Variant.vertical }))
    : SelectItem(Object.assign(Object.assign({}, props), { multiple: false, value: props.value, variant: Variant.vertical, areChoicesEqual: undefined }));
exports.default = SelectItem;

    return exports;
})();

__modules['templates.instruments.framework.steps.base_choice_selection~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseChoiceSelectionStepComponent = void 0;
exports.getReviewAnswerRenderer = getReviewAnswerRenderer;
exports.getChoiceFromValueAndChoices = getChoiceFromValueAndChoices;
const jsx_runtime_1 = require("react/jsx-runtime");
const templates_instruments_framework_components_question_layout_1_0_1 = __importDefault(require("templates.instruments.framework.components.question_layout~1_0"));
const templates_instruments_framework_components_rich_content_1_0_1 = require("templates.instruments.framework.components.rich_content~1_0");
const templates_instruments_framework_components_select_item_1_0_1 = __importDefault(require("templates.instruments.framework.components.select_item~1_0"));
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
/**
 * A base component to be called by a step that allows the user to select one or more options from a list.
 */
const BaseChoiceSelectionStepComponent = ({ instruction, item_stem, item_specific_text, copyright, choices, choices_layout = 'vertical', renderChoice, allow_multiples, exclusive, center_labels, top_align_labels, no_choices_message, skippable, updateAnswer, answer, compactMode, replacePlaceholders, }) => {
    const appliedChoices = choices;
    function getChoiceFromValue(value) {
        return getChoiceFromValueAndChoices(value, appliedChoices);
    }
    // When the allow_multiples prop is toggled, React rerenders the live preview of this step using the current answer.
    // However, the answer's type depends on the value of allow_multiples. We have to convert the answer's value to the
    // correct type.
    // Additionally, that type must match the type of the arguments to updateAnswer. We group the corrected value along
    // with updateAnswer and allow_multiples in an object to help TS do static type checking properly.
    // TODO: Revert this logic (see !647) if/when we implement handling this conversion in live preview.
    const correctedProps = allow_multiples
        ? (() => {
            const value = Array.isArray(answer === null || answer === void 0 ? void 0 : answer.value)
                ? answer.value
                : (answer === null || answer === void 0 ? void 0 : answer.value) !== undefined
                    ? [answer.value]
                    : undefined;
            const choice = value === null || value === void 0 ? void 0 : value.map(getChoiceFromValue);
            return {
                allow_multiples,
                value,
                choice,
                updateAnswer,
            };
        })()
        : (() => {
            const value = typeof (answer === null || answer === void 0 ? void 0 : answer.value) === 'string'
                ? answer.value
                : Array.isArray(answer === null || answer === void 0 ? void 0 : answer.value) && answer.value.length > 0
                    ? answer.value[0]
                    : undefined;
            const choice = value === undefined ? undefined : getChoiceFromValue(value);
            return {
                allow_multiples,
                value,
                choice,
                updateAnswer,
            };
        })();
    const handleClick = correctedProps.allow_multiples
        ? (choice, index) => {
            var _a, _b, _c;
            let newValue = ((_a = correctedProps.value) === null || _a === void 0 ? void 0 : _a.includes(choice.value))
                ? correctedProps.value.filter((value) => value !== choice.value)
                : [...((_b = correctedProps.value) !== null && _b !== void 0 ? _b : []), choice.value];
            if (exclusive && newValue.length > 1) {
                const exclusiveIndex = appliedChoices.length - 1;
                if (index === exclusiveIndex) {
                    newValue = [appliedChoices[exclusiveIndex].value];
                }
                else if (newValue.includes(appliedChoices[exclusiveIndex].value)) {
                    newValue.splice(newValue.indexOf(appliedChoices[exclusiveIndex].value), 1);
                }
            }
            const newText = newValue
                .map((v) => getPlainTextFromHtml(replacePlaceholders(getChoiceFromValue(v).display)))
                .join(', ');
            const newOriginalText = newValue
                .map((v) => { var _a; return getPlainTextFromHtml(replacePlaceholders((_a = getChoiceFromValue(v).original_display) !== null && _a !== void 0 ? _a : '')); })
                .filter(Boolean)
                .join(', ');
            (_c = correctedProps.updateAnswer) === null || _c === void 0 ? void 0 : _c.call(correctedProps, newValue.length === 0
                ? undefined
                : Object.assign({ value: newValue, text: newText }, (newOriginalText ? { originalText: newOriginalText } : {})));
        }
        : (choice) => {
            var _a;
            return (_a = correctedProps.updateAnswer) === null || _a === void 0 ? void 0 : _a.call(correctedProps, skippable && correctedProps.choice === choice
                ? undefined
                : Object.assign({ value: choice.value, text: getPlainTextFromHtml(replacePlaceholders(choice.display)) }, (choice.original_display
                    ? { originalText: getPlainTextFromHtml(replacePlaceholders(choice.original_display)) }
                    : {})));
        };
    const richInstruction = (0, templates_instruments_framework_components_rich_content_1_0_1.getContentAsRich)(instruction, replacePlaceholders);
    const richItemStem = (0, templates_instruments_framework_components_rich_content_1_0_1.getContentAsRich)(item_stem, replacePlaceholders);
    const richItemSpecificText = (0, templates_instruments_framework_components_rich_content_1_0_1.getContentAsRich)(item_specific_text, replacePlaceholders);
    const richCopyright = (0, templates_instruments_framework_components_rich_content_1_0_1.getContentAsRich)(copyright, replacePlaceholders);
    const actualRenderChoice = renderChoice !== null && renderChoice !== void 0 ? renderChoice : ((choice) => replacePlaceholders(choice.display));
    const SelectItemVariant = choices_layout === 'vertical'
        ? templates_instruments_framework_components_select_item_1_0_1.default.vertical
        : choices_layout === 'horizontal_wrapping'
            ? templates_instruments_framework_components_select_item_1_0_1.default.horizontalWrapping
            : templates_instruments_framework_components_select_item_1_0_1.default.horizontal;
    return ((0, jsx_runtime_1.jsxs)(templates_instruments_framework_components_question_layout_1_0_1.default, { instruction: richInstruction, item_stem: richItemStem, item_specific_text: richItemSpecificText, copyright: richCopyright, children: [appliedChoices.length > 0 && ((0, jsx_runtime_1.jsx)(SelectItemVariant, { choices: appliedChoices, areChoicesEqual: (a, b) => a.value === b.value, renderChoice: actualRenderChoice, multiple: allow_multiples, deselectable: skippable, centerLabels: center_labels, topAlignLabels: top_align_labels, value: correctedProps.choice, onClick: handleClick, compactMode: compactMode })), appliedChoices.length === 0 && no_choices_message && (0, jsx_runtime_1.jsx)("div", { children: no_choices_message })] }));
};
exports.BaseChoiceSelectionStepComponent = BaseChoiceSelectionStepComponent;
/**
 * @param id Step id for the step whose answer is being rendered.
 * @param getChoices A function that returns the choices for the step. It takes the same params as reviewAnswerRenderer:
 *   the answers object and a data object containing the variables object and replacePlaceholders function.
 * @returns A function that renders the answer for this step in the review screen.
 */
function getReviewAnswerRenderer(id, getChoices) {
    const reviewAnswerRenderer = (answers, data) => {
        var _a;
        const replace = (_a = data === null || data === void 0 ? void 0 : data.replacePlaceholders) !== null && _a !== void 0 ? _a : ((s) => s);
        const answer = answers[id];
        if ((0, templates_instruments_framework_step_api_2_0_1.isAnswered)(answer) && Array.isArray(answer.value) && answer.value.length > 1) {
            const choices = getChoices(answers, data);
            const displays = answer.value.map((value) => getPlainTextFromHtml(replace(getChoiceFromValueAndChoices(value, choices).display)));
            if (displays.some((display) => display.includes(', '))) {
                // If any display contains a comma, we render it as an html list instead of comma-separated list.
                return ((0, jsx_runtime_1.jsx)("ul", { children: displays.map((display) => ((0, jsx_runtime_1.jsx)("li", { children: display }, display))) }));
            }
        }
        return undefined;
    };
    return reviewAnswerRenderer;
}
function getPlainTextFromHtml(html) {
    return html.replace(/<[^>]+>/g, '');
}
function getChoiceFromValueAndChoices(value, choices) {
    return choices.find((choice) => choice.value === value);
}

    return exports;
})();

__modules['templates.instruments.framework.steps.vrs~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VrsStepComponent = void 0;
exports.default = VrsStep;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const strings_product_button_change_response_r0_1 = __importDefault(require("strings.product.button_change_response~r0"));
const strings_product_button_next_r0_1 = __importDefault(require("strings.product.button_next~r0"));
const strings_product_events_no_events_r0_1 = __importDefault(require("strings.product.events.no_events~r0"));
const templates_instruments_framework_step_api_2_0_1 = require("templates.instruments.framework.step_api~2_0");
const templates_instruments_framework_steps_base_choice_selection_1_0_1 = require("templates.instruments.framework.steps.base_choice_selection~1_0");
const templates_instruments_framework_variables_1_0_1 = require("templates.instruments.framework.variables~1_0");
const VrsStepComponent = (props) => {
    const { choices = [], choices_variable = '', variables } = props;
    const appliedChoices = (0, react_1.useMemo)(() => getAppliedChoices(choices, choices_variable, variables), [choices, choices_variable, variables]);
    return ((0, jsx_runtime_1.jsx)(templates_instruments_framework_steps_base_choice_selection_1_0_1.BaseChoiceSelectionStepComponent, Object.assign({}, props, { choices: appliedChoices,
        no_choices_message: (0, strings_product_events_no_events_r0_1.default)() })));
};
exports.VrsStepComponent = VrsStepComponent;
function VrsStep(defProps) {
    const definition = Object.assign(Object.assign({}, defProps), { mandatoryAnswer: !defProps.skippable });
    if (defProps.allow_multiples) {
        function getStepBuilder(id) {
            return {
                definition: Object.assign({ id }, definition),
                build: (stepProps) => {
                    return (0, jsx_runtime_1.jsx)(exports.VrsStepComponent, Object.assign({}, stepProps, definition, { allow_multiples: true }));
                },
                onBeforeNavigate: createOnBeforeNavigate(id, definition),
                reviewAnswerRenderer: (0, templates_instruments_framework_steps_base_choice_selection_1_0_1.getReviewAnswerRenderer)(id, (answers, data) => { var _a, _b, _c; return getAppliedChoices((_a = definition.choices) !== null && _a !== void 0 ? _a : [], (_b = definition.choices_variable) !== null && _b !== void 0 ? _b : '', (_c = data === null || data === void 0 ? void 0 : data.variables) !== null && _c !== void 0 ? _c : {}); }),
            };
        }
        return { getStepBuilder };
    }
    function getStepBuilder(id) {
        return {
            definition: Object.assign({ id }, definition),
            build: (stepProps) => {
                return (0, jsx_runtime_1.jsx)(exports.VrsStepComponent, Object.assign({}, stepProps, definition, { allow_multiples: false }));
            },
            onBeforeNavigate: createOnBeforeNavigate(id, definition),
        };
    }
    return { getStepBuilder };
}
/**
 * Returns the choices extracted from the appropriate variable, otherwise returns the choices passed in the definition
 * (which will be empty if configured for variables but the variable is not available yet).
 * @param choices The choices from the definition.
 * @param choicesVariable The name of the variable to get the choices from.
 * @param variables The variables object to look for the variable in.
 * @returns The choices with the display and value properties.
 */
function getAppliedChoices(choices, choicesVariable, variables) {
    const choicesVariableValue = variables[choicesVariable];
    if ((0, templates_instruments_framework_variables_1_0_1.isVariableArray)(choicesVariableValue)) {
        return choicesVariableValue.map((choice) => {
            var _a;
            return ({
                display: (_a = choice.localizedDisplay) !== null && _a !== void 0 ? _a : choice.display,
                value: choice.value.toString(),
            });
        });
    }
    return choices;
}
function getChoiceFromValueAndChoices(value, choices) {
    return choices.find((choice) => choice.value === value);
}
/**
 * Creates a function that shows the associated events dialog before navigating away from the step.
 * @param stepId The ID of the step.
 * @param definition The definition params of the step.
 * @returns A function that will be called before navigating away from the step.
 */
function createOnBeforeNavigate(stepId, definition) {
    return function onBeforeNavigate(answers_1, openDialog_1) {
        return __awaiter(this, arguments, void 0, function* (answers, openDialog, { variables = {} } = {}) {
            var _a, _b, _c;
            const choicesVariable = variables[(_a = definition.choices_variable) !== null && _a !== void 0 ? _a : ''];
            if (definition.review_modal_config && (0, templates_instruments_framework_variables_1_0_1.isVariableArray)(choicesVariable)) {
                const choices = getAppliedChoices((_b = definition.choices) !== null && _b !== void 0 ? _b : [], (_c = definition.choices_variable) !== null && _c !== void 0 ? _c : '', variables);
                const answer = answers[stepId];
                const answerValue = (0, templates_instruments_framework_step_api_2_0_1.isAnswered)(answer) ? answer.value : undefined;
                const eventIds = Array.isArray(answerValue)
                    ? answerValue
                    : answerValue !== undefined
                        ? [answerValue]
                        : [];
                const numAssociatedEvents = eventIds.reduce((count, eventId) => {
                    var _a, _b;
                    const choiceVariable = choicesVariable.find((choiceVariable) => choiceVariable.value === eventId);
                    return count + ((_b = (_a = choiceVariable === null || choiceVariable === void 0 ? void 0 : choiceVariable.associatedEventVariables) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0);
                }, 0);
                const eventParagraphs = numAssociatedEvents === 0
                    ? []
                    : eventIds.map((eventId) => {
                        // For each event ID, return JSX displaying the event and its associated events. If the event doesn't have an
                        // associatedEventVariables array, skip it entirely, but if it has an empty array, still display the event but
                        // without any associated events.
                        const choice = getChoiceFromValueAndChoices(eventId, choices);
                        const choiceVariable = choicesVariable.find((choiceVariable) => choiceVariable.value === eventId);
                        if (!(choiceVariable === null || choiceVariable === void 0 ? void 0 : choiceVariable.associatedEventVariables)) {
                            return null;
                        }
                        const associatedEventLines = choiceVariable.associatedEventVariables.map((associatedEventVariable, index) => {
                            var _a;
                            // For each associated value, return JSX displaying the associated event.
                            return (
                            // Playwright breaks when a Fragment or <> is passed as a prop, so use a <span> here even though it's not
                            // necessary for the DOM structure.
                            (0, jsx_runtime_1.jsxs)("span", { children: [index > 0 && (0, jsx_runtime_1.jsx)("br", {}), (_a = associatedEventVariable === null || associatedEventVariable === void 0 ? void 0 : associatedEventVariable.localizedDisplay) !== null && _a !== void 0 ? _a : associatedEventVariable === null || associatedEventVariable === void 0 ? void 0 : associatedEventVariable.display] }, associatedEventVariable.value));
                        });
                        return ((0, jsx_runtime_1.jsxs)("div", { children: [definition.review_modal_config.event_title, (0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsx)("span", { style: { fontWeight: 'bold' }, children: choice.display }), associatedEventLines.length > 0 && ((0, jsx_runtime_1.jsxs)("span", { children: [(0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsx)("br", {}), definition.review_modal_config.associated_event_title, (0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsx)("span", { style: { fontWeight: 'bold' }, children: associatedEventLines })] }))] }, eventId));
                    });
                const filteredEventParagraphs = eventParagraphs.filter(Boolean);
                if (filteredEventParagraphs.length > 0) {
                    const separatedEventParagraphs = filteredEventParagraphs.flatMap((paragraph, index) => 
                    // eslint-disable-next-line react/no-array-index-key
                    index > 0 ? [(0, jsx_runtime_1.jsx)("br", {}, `br-${index}`), (0, jsx_runtime_1.jsx)("hr", {}, `hr-${index}`), paragraph] : paragraph);
                    const confirmed = yield openDialog({
                        title: definition.review_modal_config.header,
                        content: separatedEventParagraphs,
                        yesLabel: (0, strings_product_button_next_r0_1.default)(),
                        noLabel: (0, strings_product_button_change_response_r0_1.default)(),
                    });
                    if (!confirmed) {
                        return false;
                    }
                }
                else {
                    // If there are no events to show, skip the dialog and allow navigation.
                    return true;
                }
            }
            // Associated events weren't configured, allow navigation.
            return true;
        });
    };
}

    return exports;
})();

__modules['./completion.png?url'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = 'assets/completion.png';

    return exports;
})();

__modules['strings.instrument.completion.title~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"Ready to submit?";

    return exports;
})();

__modules['strings.instrument.completion.subtitle~r0'] = (() => {
    const exports = {};
    const module = {exports};
    Object.defineProperty(exports, "__esModule", { value: true });exports.default = ()=>"If you wish to review or change anything, please go back before you submit.";

    return exports;
})();

__modules['templates.instruments.framework.components.image~1_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
require("react");
const styled_components_1 = __importDefault(require("styled-components"));
// TODO: add style or clean up when components are finalized
const Wrapper = styled_components_1.default.div ``;
function Image({ url, alt }) {
    return ((0, jsx_runtime_1.jsx)(Wrapper, { children: (0, jsx_runtime_1.jsx)("img", { src: url, alt: alt, width: '100%' }) }));
}
exports.default = Image;

    return exports;
})();

__modules['templates.instruments.framework.steps.completion~2_0'] = (() => {
    const exports = {};
    const module = {exports};
    "use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompletionStepComponent = void 0;
exports.default = CompletionStep;
const jsx_runtime_1 = require("react/jsx-runtime");
const strings_instrument_completion_subtitle_r0_1 = __importDefault(require("strings.instrument.completion.subtitle~r0"));
const strings_instrument_completion_title_r0_1 = __importDefault(require("strings.instrument.completion.title~r0"));
const styled_components_1 = __importDefault(require("styled-components"));
const templates_instruments_framework_components_image_1_0_1 = __importDefault(require("templates.instruments.framework.components.image~1_0"));
const completion_png_url_1 = __importDefault(require("./completion.png?url"));
const Container = styled_components_1.default.div `
  display: flex;
  flex-direction: column;
  flex: 1;
  row-gap: 48px;
`;
const Title = styled_components_1.default.h1 `
  font-size: 30px;
  font-weight: 400;
  margin: 0;
`;
const Subtitle = styled_components_1.default.div ``;
const ImageContainer = styled_components_1.default.div `
  display: flex;
  flex: 1;
  justify-content: center;
  align-items: center;
`;
const CompletionStepComponent = () => {
    return ((0, jsx_runtime_1.jsxs)(Container, { children: [(0, jsx_runtime_1.jsx)(Title, { children: (0, strings_instrument_completion_title_r0_1.default)() }), (0, jsx_runtime_1.jsx)(Subtitle, { children: (0, strings_instrument_completion_subtitle_r0_1.default)() }), (0, jsx_runtime_1.jsx)(ImageContainer, { children: (0, jsx_runtime_1.jsx)(templates_instruments_framework_components_image_1_0_1.default, { url: completion_png_url_1.default, alt: 'Completion image' }) })] }));
};
exports.CompletionStepComponent = CompletionStepComponent;
function CompletionStep() {
    function getStepBuilder(id) {
        const definition = {
            id,
            mandatoryAnswer: false,
        };
        return {
            definition,
            build: () => (0, jsx_runtime_1.jsx)(exports.CompletionStepComponent, {}),
        };
    }
    return { getStepBuilder };
}

    return exports;
})();

__modules['instrument'] = (() => {
    const exports = {};
    const module = {exports};
    const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_0 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.0~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_1 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.1~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_2 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.2~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_3 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.choices.3~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_item_stem = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example0.item_stem~1_0");
const templates_instruments_framework_steps_vrs = require("templates.instruments.framework.steps.vrs~2_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_0 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.0~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_1 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.1~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_2 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.2~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_3 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.choices.3~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_item_stem = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example1.item_stem~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_0 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.0~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_1 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.1~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_2 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.2~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_3 = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.choices.3~1_0");
const strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_item_stem = require("strings.instruments.rafael_feb_20_local_dev.ef7e6627_1da1_41fa_9fb1_165b839da2b0.vrs_example2.item_stem~1_0");
const templates_instruments_framework_steps_completion = require("templates.instruments.framework.steps.completion~2_0");
const templates_instruments_framework_app = require("templates.instruments.framework.app~2_0");
exports.default = () => (templates_instruments_framework_app.default({"steps":{"vrs_example0":templates_instruments_framework_steps_vrs.default({"order":0,"choices":[{"key":"f67c0925-47af-45d7-9996-59b9d3a62a5f","order":0,"value":"all","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_0.default({}),"original_display":"All of the time"},{"key":"28e9fe5e-0651-48d2-a630-43cacbe6d2df","order":1,"value":"most","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_1.default({}),"original_display":"Most of the time"},{"key":"b58e7a36-5983-4969-ab78-868ac9ddb946","order":2,"value":"little","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_2.default({}),"original_display":"A little of the time"},{"key":"270ba1f5-af6e-432c-be6d-ffc7ed02b3f6","order":3,"value":"none","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_choices_3.default({}),"original_display":"None of the time"}],"item_stem":{"content":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example0_item_stem.default({}),"size":"regular","alignment":"left"},"screen_data_mappings":{"TEST":"In the past week, how often did you feel","TESTCD":"VRS Scre"}}),"vrs_example1":templates_instruments_framework_steps_vrs.default({"order":1,"choices":[{"key":"f67c0925-47af-45d7-9996-59b9d3a62a5f","order":0,"value":"all","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_0.default({}),"original_display":"All of the time"},{"key":"28e9fe5e-0651-48d2-a630-43cacbe6d2df","order":1,"value":"most","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_1.default({}),"original_display":"Most of the time"},{"key":"b58e7a36-5983-4969-ab78-868ac9ddb946","order":2,"value":"little","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_2.default({}),"original_display":"A little of the time"},{"key":"270ba1f5-af6e-432c-be6d-ffc7ed02b3f6","order":3,"value":"none","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_choices_3.default({}),"original_display":"None of the time"}],"item_stem":{"content":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example1_item_stem.default({}),"size":"regular","alignment":"left"},"screen_data_mappings":{"TEST":"In the past week, how often did you feel","TESTCD":"VRS Scre"}}),"vrs_example2":templates_instruments_framework_steps_vrs.default({"order":2,"choices":[{"key":"f67c0925-47af-45d7-9996-59b9d3a62a5f","order":0,"value":"all","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_0.default({}),"original_display":"All of the time"},{"key":"28e9fe5e-0651-48d2-a630-43cacbe6d2df","order":1,"value":"most","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_1.default({}),"original_display":"Most of the time"},{"key":"b58e7a36-5983-4969-ab78-868ac9ddb946","order":2,"value":"little","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_2.default({}),"original_display":"A little of the time"},{"key":"270ba1f5-af6e-432c-be6d-ffc7ed02b3f6","order":3,"value":"none","display":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_choices_3.default({}),"original_display":"None of the time"}],"item_stem":{"content":strings_instruments_rafael_feb_20_local_dev_ef7e6627_1da1_41fa_9fb1_165b839da2b0_vrs_example2_item_stem.default({}),"size":"regular","alignment":"left"},"screen_data_mappings":{"TEST":"In the past week, how often did you feel","TESTCD":"VRS Scre"}}),"vrs_example3":templates_instruments_framework_steps_completion.default({"order":3})}}));
    return exports;
})();

const rootElement = document.getElementById('root');
if (rootElement === null) throw new Error('Cannot find root with id [root].');
const root = require('react-dom').createRoot(rootElement);
root.render(require('instrument').default());
