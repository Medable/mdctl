"use strict";
/**
 * hooks.js stub implementation.
 */
function submit({ responses, events }) {
    // ==========  STUB ========
    // Must be replaced by the client API implementation
    console.log('submit', responses, events);
}
function track(event) {
    // ==========  STUB ========
    // Must be replaced by the client API implementation
    console.log('track', event);
}
function cancel() {
    // ==========  STUB ========
    // Must be replaced by the client API implementation
    console.log('cancel');
}
function callApi(path, options) {
    // ==========  STUB ========
    // Must be replaced by the client API implementation
    console.log('callApi', path, options);
    return Promise.resolve({});
}
function getMetadata() {
    // ==========  STUB ========
    // Must be replaced by the client API implementation
    console.log('getMetadata');
    return {};
}
window.submit = submit;
window.track = track;
window.cancel = cancel;
window.callApi = callApi;
window.getMetadata = getMetadata;
